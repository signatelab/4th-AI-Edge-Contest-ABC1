#pragma once

#include <cassert>
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstring>

#if !defined PC_VER
#include <arm_neon.h>
#else
//#include "arm_neon.h"
#include "NEONvsSSE.h"
#endif

template<typename T, int NUM_CLASS>
class Argmax {
  public:
    void operator()(const T *logits, uint8_t *output, int size) const {
        uint8_t *output_end = output + size;
        while(output != output_end) {
            const T *logits_n = logits + NUM_CLASS;
            auto max_ind = std::max_element(logits, logits_n);
            *(output++) = std::distance(logits, max_ind);
            logits = logits_n;
        }
    }
};

template<>
class Argmax<uint16_t, 6> {
    static const int NUM_CLASS = 6;

    // max_val[i] = max(val[0][i], val[1][i], val[2][i])
    // max_idx[i] = maxarg(val[0][i], val[1][i], val[2][i])
    __attribute__((always_inline)) inline void vec_max3(const uint16x8x3_t &val, uint16x8_t &max_val, uint8x8_t &max_idx) const {
#if 0  // reference
        for (int i = 0; i < 8; i++) {
            max_val.val[i] = val.val[0].val[i];
            max_idx.val[i] = 0;
            if (val.val[1].val[i] > max_val.val[i]) {
                max_val.val[i] = val.val[1].val[i];
                max_idx.val[i] = 1;
            }
            if (val.val[2].val[i] > max_val.val[i]) {
                max_val.val[i] = val.val[2].val[i];
                max_idx.val[i] = 2;
            }
        }
#else
        max_val = val.val[0];
        max_idx = vdup_n_u8(0);
        uint16x8_t comp1 = vcgtq_u16(val.val[1], max_val);
        max_val = vbslq_u16(comp1, val.val[1], max_val);
        max_idx = vbsl_u8(vmovn_u16(comp1), vdup_n_u8(1), max_idx);
        uint16x8_t comp2 = vcgtq_u16(val.val[2], max_val);
        max_val = vbslq_u16(comp2, val.val[2], max_val);
        max_idx = vbsl_u8(vmovn_u16(comp2), vdup_n_u8(2), max_idx);
#endif
    }

    // max_idx[i] = (val[1][i] > val[0][i] ? idx[1][i]+3 : idx[0][i])
    __attribute__((always_inline)) inline void vec_max2(const uint16x8x2_t &val, const uint8x8x2_t &idx, uint8x8_t &max_idx) const {
#if 0  // reference
        for (int i = 0; i < 8; i++) {
            if (val.val[1].val[i] > val.val[0].val[i]) {
                max_idx.val[i] = idx.val[1].val[i]+3;
            }
            else {
                max_idx.val[i] = idx.val[0].val[i];
            }
        }
#else
        uint8x8_t comp = vmovn_u16(vcgtq_u16(val.val[1], val.val[0]));
        max_idx = vadd_u8(vbsl_u8(comp, idx.val[1], idx.val[0]),
                          vand_u8(comp, vdup_n_u8(3)));
#endif
    }

  public:
    void operator()(const uint16_t *logits, uint8_t *output, int size) const {
        assert(NUM_CLASS == 6);
        int size0 = (size/8)*8;
        uint16_t work_max[16];
        uint8_t work_idx[16];
        int i = 0;
        for (; i < size0; i+=8) {
            uint16x8x3_t val0 = vld3q_u16(&logits[NUM_CLASS*i]);
            uint16x8x3_t val1 = vld3q_u16(&logits[NUM_CLASS*(i+4)]);
            uint16x8_t max_val0, max_val1;
            uint8x8_t max_idx0, max_idx1;
            vec_max3(val0, max_val0, max_idx0);
            vec_max3(val1, max_val1, max_idx1);
            vst1q_u16(work_max, max_val0);
            vst1q_u16(work_max+8, max_val1);
            vst1_u8(work_idx, max_idx0);
            vst1_u8(work_idx+8, max_idx1);
            uint8x8_t max_idx;
            vec_max2(vld2q_u16(work_max), vld2_u8(work_idx), max_idx);
            vst1_u8(&output[i], max_idx);
        }
        for (; i < size; i++) {
            auto max_ind = std::max_element(&logits[i*NUM_CLASS], &logits[(i+1)*NUM_CLASS]);
            output[i] = std::distance(&logits[i*NUM_CLASS], max_ind);
        }
    }
};

template<>
class Argmax<uint8_t, 6> {
    static const int NUM_CLASS = 6;

    //   max_val[i] = max(val[0][i], val[1][i], val[2][i])
    //   max_idx[i] = maxarg(val[0][i], val[1][i], val[2][i])
    __attribute__((always_inline)) inline void vec_max3(const uint8x16x3_t &val, uint8x16_t &max_val, uint8x16_t &max_idx) const {
#if 0  // reference
        for (int i = 0; i < 16; i++) {
            max_val.val[i] = val.val[0].val[i];
            max_idx.val[i] = 0;
            if (val.val[1].val[i] > max_val.val[i]) {
                max_val.val[i] = val.val[1].val[i];
                max_idx.val[i] = 1;
            }
            if (val.val[2].val[i] > max_val.val[i]) {
                max_val.val[i] = val.val[2].val[i];
                max_idx.val[i] = 2;
            }
        }
#else
        max_val = val.val[0];
        max_idx = vdupq_n_u8(0);
        uint8x16_t comp1 = vcgtq_u8(val.val[1], max_val);
        max_val = vbslq_u8(comp1, val.val[1], max_val);
        max_idx = vbslq_u8(comp1, vdupq_n_u8(1), max_idx);
        uint8x16_t comp2 = vcgtq_u8(val.val[2], max_val);
        max_val = vbslq_u8(comp2, val.val[2], max_val);
        max_idx = vbslq_u8(comp2, vdupq_n_u8(2), max_idx);
#endif
    }

    //   max_idx[i] = (val[1][i] > val[0][i] ? idx[1][i]+3 : idx[0][i])
    __attribute__((always_inline)) inline void vec_max2(const uint8x16x2_t &val, const uint8x16x2_t &idx, uint8x16_t &max_idx) const {
#if 0  // reference
        for (int i = 0; i < 16; i++) {
            if (val.val[1].val[i] > val.val[0].val[i]) {
                max_idx.val[i] = idx.val[1].val[i]+3;
            }
            else {
                max_idx.val[i] = idx.val[0].val[i];
            }
        }
#else
        uint8x16_t comp = vcgtq_u8(val.val[1], val.val[0]);
        max_idx = vaddq_u8(vbslq_u8(comp, idx.val[1], idx.val[0]),
                           vandq_u8(comp, vdupq_n_u8(3)));
#endif
    }

  public:
    void operator()(const uint8_t *logits, uint8_t *output, int size) const {
        assert(NUM_CLASS == 6);
        int size0 = (size/16)*16;
        uint8_t work_max[32];
        uint8_t work_idx[32];
        int i = 0;
        for (; i < size0; i+=16) {
            uint8x16x3_t val0 = vld3q_u8(&logits[NUM_CLASS*i]);
            uint8x16x3_t val1 = vld3q_u8(&logits[NUM_CLASS*(i+8)]);
            uint8x16_t max_val0, max_val1;
            uint8x16_t max_idx0, max_idx1;
            vec_max3(val0, max_val0, max_idx0);
            vec_max3(val1, max_val1, max_idx1);
            vst1q_u8(work_max, max_val0);
            vst1q_u8(work_max+16, max_val1);
            vst1q_u8(work_idx, max_idx0);
            vst1q_u8(work_idx+16, max_idx1);
            uint8x16_t max_idx;
            vec_max2(vld2q_u8(work_max), vld2q_u8(work_idx), max_idx);
            vst1q_u8(&output[i], max_idx);
        }
        for (; i < size; i++) {
            auto max_ind = std::max_element(&logits[i*NUM_CLASS], &logits[(i+1)*NUM_CLASS]);
            output[i] = std::distance(&logits[i*NUM_CLASS], max_ind);
        }
    }
};
