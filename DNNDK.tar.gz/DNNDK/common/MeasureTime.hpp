#pragma once
#include "VCDWriter.hpp"
#include <memory>
#include <mutex>
#include <sstream>
#include <fstream>
#include <limits>
#include <iomanip>
#include <algorithm>
#include <cmath>

/* optional flag */
//#define MEASURE_TIME_DISABLE       // disable time measurement macro
//#define MEASURE_TIME_MODE_FLATTEN  // ignore mesurement hierachy

class MeasureTimeThreadData;

class MeasureTime {
    friend class MeasureTimeThreadData;

    std::mutex mtx;
    int allocate_counter;
    VCDWriter vcd_writer;
    std::map<std::string, std::vector<uint64_t> > durations;
    bool vcd_output_en;
    bool measure_time_hier_output_en;
    bool measure_time_flat_output_en;

    MeasureTime(void)
        : allocate_counter(0), vcd_writer("measure_time"),
          vcd_output_en(true), measure_time_hier_output_en(true), measure_time_flat_output_en(true)
    {}

    ~MeasureTime() {
        if (vcd_output_en) vcd_writer.write_file("measure_time.vcd");
        if (measure_time_hier_output_en) output_summary_csv_hier("measure_time_hier.csv");
        if (measure_time_flat_output_en) output_summary_csv_flat("measure_time_flat.csv");
    }

    void output_summary_csv_hier(const std::string &filename) {
        output_summary_csv(filename, this->durations, true, true);
    }

    void output_summary_csv_flat(const std::string &filename) {
        std::map<std::string, std::vector<uint64_t> > durations_flat;
        for (const auto &p : this->durations) {
            const std::string &name = p.first;
            int depth = std::count(name.begin(), name.end(), '.');
            const std::string base_name = (depth == 0 ? name : name.substr(name.find_last_of(".")+1));
            std::copy(p.second.cbegin(), p.second.cend(), std::back_inserter(durations_flat[base_name]));
        }
        output_summary_csv(filename, durations_flat);
    }

    void output_summary_csv(const std::string &filename, const std::map<std::string, std::vector<uint64_t> > &durs, bool print_depth = false, bool print_total_time_exclude_child = false) {
        std::ofstream ofs(filename);
        if (!ofs) {
            std::cerr << "Error: cannot open " << filename << "!!" << std::endl;
            std::exit(1);
        }
        ofs << "name";
        if (print_depth) {
            ofs << ",depth";
        }
        ofs << ",count"
            << ",total_time(us)";
        if (print_total_time_exclude_child) {
            ofs << ",total_time_exclude_child(us)";
        }
        ofs << ",avg_time(us)"
            << ",max_time(us)"
            << ",min_time(us)"
            << ",std_dev(us)" << std::endl;

        // calc child_total_time
        std::map<std::string, uint64_t> child_total_time;
        if (print_total_time_exclude_child) {
            for (const auto &p : durs) {
                if (!p.second.empty()) {
                    const std::string &name = p.first;
                    int depth = std::count(name.begin(), name.end(), '.');
                    if (depth > 0) {
                        std::string parent = name.substr(0, name.find_last_of("."));
                        uint64_t total_time = 0;
                        for (auto &t : p.second) {
                            total_time += t;
                        }
                        child_total_time[parent] += total_time;
                    }
                }
            }
        }

        // output
        for (const auto &p : durs) {
            if (!p.second.empty()) {
                uint64_t total_time = 0;
                uint64_t max_time = 0;
                uint64_t min_time = std::numeric_limits<uint64_t>::max();
                for (auto &t : p.second) {
                    total_time += t;
                    max_time = std::max(max_time, t);
                    min_time = std::min(min_time, t);
                }
                uint64_t avg_time = total_time / p.second.size();
                double std_var = 0.0;
                for (auto &t : p.second) {
                    std_var += ((double)t - avg_time)*((double)t - avg_time);
                }
                std_var /= p.second.size();

                const std::string &name = p.first;
                int depth = std::count(name.begin(), name.end(), '.');
                ofs << name;
                if (print_depth) {
                    ofs << "," << depth;
                }
                ofs << "," << p.second.size()
                    << "," << total_time;
                if (print_total_time_exclude_child) {
                    ofs << "," << total_time - child_total_time[name];
                }
                ofs << "," << avg_time
                    << "," << max_time
                    << "," << min_time
                    << "," << (uint64_t)sqrt(std_var) << std::endl;
            }
        }
    }

    int allocate(void) {
        mtx.lock();
        int idx = allocate_counter++;
        mtx.unlock();
        return idx;
    }

    void add_time_measure_trace(VCDTrace<bool> &trace) {
        mtx.lock();
        vcd_writer.add(trace);
        durations[trace.name] = trace.extract_durations();
        mtx.unlock();
    }

    template<typename T>
    void add_trace_private(VCDTrace<T> &trace) {
        mtx.lock();
        vcd_writer.add(trace);
        mtx.unlock();
    }

    static MeasureTime &get_instance(void) {
        static MeasureTime instance;
        return instance;
    }

    MeasureTime(const MeasureTime&) = delete;
    MeasureTime& operator=(const MeasureTime&) = delete;
    MeasureTime(MeasureTime&&) = delete;
    MeasureTime& operator=(MeasureTime&&) = delete;

  public:
    template<typename T>
    static void add_trace(VCDTrace<T> &trace) {
        MeasureTime::get_instance().add_trace_private(trace);
    }
    static void enable_vcd_output(void) { MeasureTime::get_instance().vcd_output_en = true; }
    static void disable_vcd_output(void) { MeasureTime::get_instance().vcd_output_en = false; }
    static void enable_measure_time_output(void) { MeasureTime::get_instance().measure_time_hier_output_en = true; }
    static void disable_measure_time_output(void) { MeasureTime::get_instance().measure_time_hier_output_en = false; }
    static void enable_measure_time_flat_output(void) { MeasureTime::get_instance().measure_time_flat_output_en = true; }
    static void disable_measure_time_flat_output(void) { MeasureTime::get_instance().measure_time_flat_output_en = false; }
};

// measurement data for each thread
class MeasureTimeThreadData {
    const int thread_id;
    std::string thread_name;
    std::vector<std::string> scope;
    std::map<std::string, VCDTrace<bool> *> traces;
    std::string last_measure_name;
    std::chrono::system_clock::duration last_duration;

    MeasureTimeThreadData(void) :
        thread_id(MeasureTime::get_instance().allocate())
    {
        std::ostringstream oss; oss << "thread" << thread_id;
        thread_name = oss.str();
        VCDTrace<bool> &tr = get_trace(oss.str());
        tr.add(1);
        enter_scope(oss.str());
    }

    ~MeasureTimeThreadData() {
        exit_scope();
        //assert(scope.empty());  // disable assert for abnormal end such as std::exit()
        VCDTrace<bool> &tr = get_trace(thread_name);
        tr.add(0);

        std::chrono::system_clock::time_point thread_start_time = tr.times[0];
        for (auto &p : traces) {
            // modify initial 0 write time for better looking
            assert(!(p.second->values.empty()));
            assert(p.second->values[0] == false);
            p.second->times[0] = thread_start_time;

            // add trace to global data
            MeasureTime::get_instance().add_time_measure_trace(*(p.second));
            delete p.second;
        }
    }

    void enter_scope(const std::string &scope_name) { scope.push_back(scope_name); }
    void exit_scope(void) { scope.pop_back(); }

    std::string get_full_name(std::string name) {
#ifdef MEASURE_TIME_MODE_FLATTEN
        for (const auto &s : scope) assert(s != name);  // check if name is already used
        return scope[0] + "." + name;
#else
        std::string ret;
        for (const auto &s : scope) ret += (s + ".");
        ret += name;
        return ret;
#endif
    }

    void set_name_private(const std::string &name) {
        // change scope[0]'s thread_name
        assert(!scope.empty());
        assert(scope[0].substr(0, thread_name.size()) == thread_name);
        scope[0] = name + scope[0].substr(thread_name.size());
        // change traces's thread_name
        std::map<std::string, VCDTrace<bool> *> new_traces;
        for (const auto &p : traces) {
            std::string s = p.first;
            assert(s == p.second->get_name());
            assert(s.substr(0, thread_name.size()) == thread_name);
            s = name + s.substr(thread_name.size());
            p.second->set_name(s);
            new_traces[s] = p.second;
        }
        traces = new_traces;
        // last_measure_name's thread_name
        if (!last_measure_name.empty()) {
            assert(last_measure_name.substr(0, thread_name.size()) == thread_name);
            last_measure_name = name + last_measure_name.substr(thread_name.size());
        }
        // change thread_name
        thread_name = name;
    }

  public:
    // add value to VCDTrace at variable scope start/end
    template<typename T>
    struct VCDTraceAutoAdd {
        VCDTrace<T> &trace;
        T end_add_val;

        VCDTraceAutoAdd(const std::string &name, T start_add_val = 1, T end_add_val = 0) :
            trace(MeasureTimeThreadData::get_instance().get_trace(name)),
            end_add_val(end_add_val)
        {
            trace.add(start_add_val);
            MeasureTimeThreadData::get_instance().enter_scope(name);
        }
        ~VCDTraceAutoAdd() {
            MeasureTimeThreadData::get_instance().exit_scope();
            trace.add(end_add_val);
            int tsize = trace.times.size();
            MeasureTimeThreadData::get_instance().last_measure_name = trace.name;
            MeasureTimeThreadData::get_instance().last_duration = trace.times[tsize-1] - trace.times[tsize-2];
        }

        VCDTraceAutoAdd(const VCDTraceAutoAdd<T> &other) = delete;
        VCDTraceAutoAdd<T> &operator = (const VCDTraceAutoAdd<T> &other) = delete;
    };

    static MeasureTimeThreadData &get_instance(void) {
        thread_local MeasureTimeThreadData instance;
        return instance;
    }

    MeasureTimeThreadData(const MeasureTimeThreadData&) = delete;
    MeasureTimeThreadData& operator=(const MeasureTimeThreadData&) = delete;
    MeasureTimeThreadData(MeasureTimeThreadData&&) = delete;
    MeasureTimeThreadData& operator=(MeasureTimeThreadData&&) = delete;

    static void set_name(const std::string &name) {
        MeasureTimeThreadData &m = MeasureTimeThreadData::get_instance();
        m.set_name_private(name);
    }

    VCDTrace<bool> &get_trace(const std::string &name) {
        std::string full_name = get_full_name(name);
        if (traces.find(full_name) == traces.end()) {
            traces[full_name] = new VCDTrace<bool>(full_name);
        }
        return *traces[full_name];
    }

    template<typename TIME_T = std::chrono::microseconds>
    uint64_t get_last_duration(void) {
        return std::chrono::duration_cast<TIME_T>(last_duration).count();
    }

    template<typename TIME_T = std::chrono::microseconds>
    const std::string &get_last_measure_name(void) {
        return last_measure_name;
    }
};

#ifdef DISABLE_MEASURE_TIME
#define MEASURE_TIME_WITH_EN(name, en)
#define MEASURE_TIME(name)
#define PRINT_MEASURE_TIME(name) do {} while(false)
#else
#define MEASURE_TIME_WITH_EN(name, en) \
    for (std::pair<std::unique_ptr<MeasureTimeThreadData::VCDTraceAutoAdd<bool> >, int> __auto_add_##name( \
             (en) ? std::move(std::unique_ptr<MeasureTimeThreadData::VCDTraceAutoAdd<bool> >(new MeasureTimeThreadData::VCDTraceAutoAdd<bool>(#name))) : std::unique_ptr<MeasureTimeThreadData::VCDTraceAutoAdd<bool> >(), 0); \
         __auto_add_##name.second < 1; __auto_add_##name.second++)
#define MEASURE_TIME(name) MEASURE_TIME_WITH_EN(name, true)
#define PRINT_MEASURE_TIME() std::cout << "[MeasureTime] " << std::left << std::setw(30) << MeasureTimeThreadData::get_instance().get_last_measure_name() \
                                       << std::right << std::setw(10) << MeasureTimeThreadData::get_instance().get_last_duration() << " us" << std::endl
#endif
