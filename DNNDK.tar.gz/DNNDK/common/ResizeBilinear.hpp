#pragma once
#include <cstdint>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <limits>
#include <iterator>
#include <algorithm>

#include "ResizeOpenCV.hpp"
#include "JudgeCutTop.hpp"

#if !defined PC_VER
#include <arm_neon.h>
#else
//#include "arm_neon.h"
#include "NEONvsSSE.h"
#endif

// quantization for bilinear coefficient
template<typename T> struct ResizeBilinearCoefQuantizer {};
template<> struct ResizeBilinearCoefQuantizer<float>{
    static float quantize(int64_t n, int64_t d, bool &overflow) {
        overflow = false;
        return (float)n/d;
    }

    static float dequantize(float val) { return val; }
};

template<typename T> struct ResizeBilinearCoefQuantizerUint{
    static const int Q = sizeof(T)*8;
    static const T max_val = std::numeric_limits<T>::max();
    static T quantize(int64_t n, int64_t d, bool &overflow) {
        assert(0 <= n && n < d);
        int64_t qval = ((n<<Q)+d/2)/d;
        overflow = (qval > (int64_t)max_val);
        if (overflow) {
            qval = max_val;
        }
        return (T)qval;
    }

    static float dequantize(T val) {
        return (float)val / (1<<Q);
    };
};

template<> struct ResizeBilinearCoefQuantizer<uint16_t> : public ResizeBilinearCoefQuantizerUint<uint16_t>{};
template<> struct ResizeBilinearCoefQuantizer<uint8_t> : public ResizeBilinearCoefQuantizerUint<uint8_t>{};

template<typename T, int CH>
class ResizeBilinearPrecompute {
  protected:
    int sh; // src height
    int sw; // src width
    int dh; // dst height
    int dw; // dst width
    int out_size;

    std::vector<int> xposes;
    std::vector<int> xposes_add;
    std::vector<int> xposes_rep;
    std::vector<int> yposes;
    std::vector<int> yposes_add;
    std::vector<int> yposes_rep;
    std::vector<T> ycoefs;
    std::vector<T> xcoefs;

    void compute(double nearest_th_y = 0.0, double nearest_th_x = 0.0) {
        assert(0.0 <= nearest_th_y && nearest_th_y <= 0.5);
        assert(0.0 <= nearest_th_x && nearest_th_x <= 0.5);

        xposes.clear();
        xposes_add.clear();
        xposes_rep.clear();
        yposes.clear();
        yposes_add.clear();
        yposes_rep.clear();
        ycoefs.clear();
        xcoefs.clear();

        ResizeBilinearCoefQuantizer<T> q;

        // precompute
        bool is_upsample_y = (dh >= sh);
        bool is_upsample_x = (dw >= sw);
        assert(is_upsample_y == is_upsample_x);
        int denom_y = 2*dh;
        int denom_x = 2*dw;
        int th_y = (int)(nearest_th_y * denom_y);
        int th_x = (int)(nearest_th_x * denom_x);
        for (int y = 0; y < dh; y++) {
            int cy = (2*y+1)*sh-dh;
            if (is_upsample_y) {
                if (cy < 0) cy = 0;
                if (cy > (sh-1)*denom_y) cy = (sh-1)*denom_y;
            }
            int ly = cy / denom_y;
            int uy = std::min(ly+1, sh-1);
            int rem_y = cy % denom_y;
            bool overflow;
            if (std::min<int>(rem_y, denom_y-rem_y) <= th_y) {  // nearest neighbor mode
                int ty = (cy + denom_y/2) / denom_y;
                yposes.push_back(ty);
                yposes_add.push_back(0);
                ycoefs.push_back(q.quantize(1, 2, overflow));
            }
            else if (rem_y == 0 || ly == uy) {  // just y0
                yposes.push_back(ly);
                yposes_add.push_back(0);
                ycoefs.push_back(q.quantize(1, 2, overflow));
            }
            else {
                T ply = q.quantize(denom_y-rem_y, denom_y, overflow);
                if (overflow) { // just y0
                    yposes.push_back(ly);
                    yposes_add.push_back(0);
                    ycoefs.push_back(q.quantize(1, 2, overflow));
                }
                else if (ply == 0) { // just y1
                    yposes.push_back(uy);
                    yposes_add.push_back(0);
                    ycoefs.push_back(q.quantize(1, 2, overflow));
                }
                else {
                    yposes.push_back(ly);
                    yposes_add.push_back(sw*CH);
                    ycoefs.push_back(ply);
                }
            }
            assert(!overflow);
        }

        for (int x = 0; x < dw; x++) {
            int cx = (2*x+1)*sw-dw;
            if (is_upsample_x) {
                if (cx < 0) cx = 0;
                if (cx > (sw-1)*denom_x) cx = (sw-1)*denom_x;
            }
            int lx = cx / denom_x;
            int ux = std::min(lx+1, sw-1);
            int rem_x = cx % denom_x;
            bool overflow;
            if (std::min<int>(rem_x, denom_x-rem_x) <= th_x) {  // nearest neighbor mode
                int tx = (cx + denom_x/2) / denom_x;
                xposes.push_back(tx);
                xposes_add.push_back(0);
                xcoefs.push_back(q.quantize(1, 2, overflow));
            }
            else if (rem_x == 0 || lx == ux) {  // just x0
                xposes.push_back(lx);
                xposes_add.push_back(0);
                xcoefs.push_back(q.quantize(1, 2, overflow));
            }
            else {
                T plx = q.quantize(denom_x-rem_x, denom_x, overflow);
                if (overflow) { // just x0
                    xposes.push_back(lx);
                    xposes_add.push_back(0);
                    xcoefs.push_back(q.quantize(1, 2, overflow));
                }
                else if (plx == 0) { // just x1
                    xposes.push_back(ux);
                    xposes_add.push_back(0);
                    xcoefs.push_back(q.quantize(1, 2, overflow));
                }
                else {
                    xposes.push_back(lx);
                    xposes_add.push_back(CH);
                    xcoefs.push_back(plx);
                }
            }
            assert(!overflow);
        }

        int rep = 1;
        for (int x = 1; x < dw; x++) {
            if (xposes[x] == xposes[x-1] && xposes_add[x] == xposes_add[x-1]) {
                rep++;
            }
            else {
                xposes_rep.push_back(rep);
                rep = 1;
            }
        }
        xposes_rep.push_back(rep);

        rep = 1;
        for (int y = 1; y < dh; y++) {
            if (yposes[y] == yposes[y-1] && yposes_add[y] == yposes_add[y-1]) {
                rep++;
            }
            else {
                yposes_rep.push_back(rep);
                rep = 1;
            }
        }
        yposes_rep.push_back(rep);
    }

  public:
    ResizeBilinearPrecompute(int src_height, int src_width, int dst_height, int dst_width,
                             double nearest_th_y = 0.0, double nearest_th_x = 0.0)
        : sh(src_height), sw(src_width), dh(dst_height), dw(dst_width), out_size(dh*dw)
    {
        compute(nearest_th_y, nearest_th_x);
    }
};

template<typename T, int CH, int USE_OPENCV=0>
class ResizeBilinear{};

// opencv
template<int CH> class ResizeBilinear<uint8_t, CH, 1> : public ResizeOpenCV<uint8_t, CH, cv::INTER_LINEAR> {
  public:
    ResizeBilinear(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeOpenCV<uint8_t, CH, cv::INTER_LINEAR>(src_height, src_width, dst_height, dst_width) {}
};
template<int CH> class ResizeBilinear<uint16_t, CH, 1> : public ResizeOpenCV<uint16_t, CH, cv::INTER_LINEAR> {
  public:
    ResizeBilinear(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeOpenCV<uint16_t, CH, cv::INTER_LINEAR>(src_height, src_width, dst_height, dst_width) {}
};
template<int CH> class ResizeBilinear<float, CH, 1> : public ResizeOpenCV<float, CH, cv::INTER_LINEAR> {
  public:
    ResizeBilinear(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeOpenCV<float, CH, cv::INTER_LINEAR>(src_height, src_width, dst_height, dst_width) {}
};

template<int CH>
class ResizeBilinear<float, CH, 0> : public ResizeBilinearPrecompute<float, CH> {
    typedef ResizeBilinearPrecompute<float, CH> inherited;

  public:
    ResizeBilinear(int src_height, int src_width, int dst_height, int dst_width,
                   double nearest_th_y = 0.0, double nearest_th_x = 0.0)
        : inherited(src_height, src_width, dst_height, dst_width, nearest_th_y, nearest_th_x) {}

    template<int LSHIFT=0, int RSHIFT=0, bool TRANSPOSE=false, int DH=-1 /* optimize for TRANSPOSE (not implemented) */,
             typename JUDGE_CUT_TOP_T=JudgeCutTop<4> >
    void operator()(const float *src, float *dst, JUDGE_CUT_TOP_T *jct = nullptr) const {
        static_assert(LSHIFT == 0 || RSHIFT == 0, "LSHIFT or RSHIFT must be 0");
        assert(!TRANSPOSE);  // not implemented yet
        assert(!jct);  // not implemented yet
        for (int y = 0; y < inherited::dh; y++) {
            int ly = inherited::yposes[y];
            int ay = inherited::yposes_add[y];
            float ply = inherited::ycoefs[y];
            float puy = 1.0-ply;
            for (int x = 0; x < inherited::dw; x++) {
                int lx = inherited::xposes[x];
                int ax = inherited::xposes_add[x];
                float plx = inherited::xcoefs[x];
                float pux = 1.0-plx;
                int pos0 = (ly*inherited::sw+lx)*CH;
                int pos1 = pos0 + ax;
                int pos2 = pos0 + ay;
                int pos3 = pos2 + ax;
                for (int c = 0; c < CH; c++) {
                    float val0 = ply*src[pos0+c] + puy*src[pos2+c];
                    float val1 = ply*src[pos1+c] + puy*src[pos3+c];
                    *(dst++) = (plx*val0 + pux*val1)*(1<<LSHIFT)/(1<<RSHIFT);
                }
            }
        }
    }
};

template<typename T>
class RowDecoderInterface {
  public:
    virtual const T *getRow(unsigned int y) = 0;
    virtual ~RowDecoderInterface() {}
};

template<typename T>
class RowDecoderRawImage : public RowDecoderInterface<T> {
  public:
    const T * const data;
    const int row_size;
    RowDecoderRawImage(const T *data, int row_size) : data(data), row_size(row_size) {}
    const T *getRow(unsigned int y) { return &data[y*row_size]; }
    ~RowDecoderRawImage() {}
};

template<typename T, int OFFSET_Y>
class RowDecoderOffsetYWrapper : public RowDecoderInterface<T> {
  public:
    RowDecoderInterface<T> &row_decoder;
    RowDecoderOffsetYWrapper(RowDecoderInterface<T> &row_decoder) : row_decoder(row_decoder) {}
    const T *getRow(unsigned int y) { return row_decoder.getRow(y + OFFSET_Y); }
    ~RowDecoderOffsetYWrapper() {}
};

template<int CH>
class ResizeBilinear<uint8_t, CH, 0> : public ResizeBilinearPrecompute<uint8_t, CH> {
    typedef ResizeBilinearPrecompute<uint8_t, CH> inherited;
    mutable std::vector<uint8_t> work_line;
    mutable std::vector<uint8_t> work_line0;
    mutable std::vector<uint8_t> work_line1;

  public:
    ResizeBilinear(int src_height, int src_width, int dst_height, int dst_width,
                   double nearest_th_y = 0.0, double nearest_th_x = 0.0)
        : inherited(src_height, src_width, dst_height, dst_width, nearest_th_y, nearest_th_x),
          work_line(src_width*CH),
          work_line0(dst_width*CH + 8 /* 8 for simd */),
          work_line1(dst_width*CH + 8 /* 8 for simd */)
    {
    }

    template<int SHIFT=8>
    __attribute__((always_inline)) inline uint8_t dot2(uint8_t a0, uint8_t a1, uint8_t b0, uint8_t b1) const {
        static_assert(SHIFT >= 0, "SHIFT must be greater of equal to zero");
        if (SHIFT > 8) {
            static const int DSHIFT = (SHIFT <= 8 ? 0 : SHIFT-8);
            static const uint8_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
            static uint8_t overflow_th = 255 - ADD_FOR_ROUND;
            static uint8_t max_val = (255>>DSHIFT);
            uint16_t acc = a0*b0;
            acc += a1*b1;
            uint8_t acc_u8 = (uint8_t)(acc >> 8);
            uint8_t ret = (acc_u8 > overflow_th ? max_val : ((acc_u8+ADD_FOR_ROUND)>>DSHIFT));
            return ret;
        }
        else {
            uint16_t acc = (SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
            acc += a0*b0;
            acc += a1*b1;
            uint8_t ret = (acc>>SHIFT);
            return ret;
        }
    }

    template<int SHIFT=8, bool TRANSPOSE=false, int DH=-1, bool DO_JUDGE=false, typename JUDGE_CUT_TOP_T=JudgeCutTop<4> >
    void vec_dot2_ch3(const uint8_t *a0, const uint8_t *a1, uint8_t b0, uint8_t b1, int size, uint8_t *out, JUDGE_CUT_TOP_T *jct = nullptr) const {
        static_assert(SHIFT >= 0, "SHIFT must be greater of equal to zero");
        assert(CH == 3);
        assert(!TRANSPOSE || DH == inherited::dh); // DH must be specified if TRANSPOSE = true
        assert(!DO_JUDGE || jct);
        static const int JCT_LSHIFT = ((SHIFT-8) > 0 ? (SHIFT-8) : 0);
        int i = 0;
#if 1
        int size0 = ((size/(8*CH))*(8*CH));
        uint8x8_t vb0 = vdup_n_u8(b0);
        uint8x8_t vb1 = vdup_n_u8(b1);
        for (; i < size0; i += 8*CH) {
            uint8x8x3_t va0 = vld3_u8(&a0[i]);
            uint8x8x3_t va1 = vld3_u8(&a1[i]);
            uint8x8x3_t out_val;
            if (SHIFT > 8) {
                static const int DSHIFT = (SHIFT <= 8 ? 0 : SHIFT-8);
                static const uint8_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
                uint16x8_t accum0 = vmull_u8(va0.val[0], vb0);
                uint16x8_t accum1 = vmull_u8(va0.val[1], vb0);
                uint16x8_t accum2 = vmull_u8(va0.val[2], vb0);
                accum0 = vmlal_u8(accum0, va1.val[0], vb1);
                accum1 = vmlal_u8(accum1, va1.val[1], vb1);
                accum2 = vmlal_u8(accum2, va1.val[2], vb1);
                uint8x8_t accum0_u8 = vshrn_n_u16(accum0, 8);
                uint8x8_t accum1_u8 = vshrn_n_u16(accum1, 8);
                uint8x8_t accum2_u8 = vshrn_n_u16(accum2, 8);
                out_val.val[0] = vshr_n_u8(vqadd_u8(accum0_u8, vdup_n_u8(ADD_FOR_ROUND)), DSHIFT);
                out_val.val[1] = vshr_n_u8(vqadd_u8(accum1_u8, vdup_n_u8(ADD_FOR_ROUND)), DSHIFT);
                out_val.val[2] = vshr_n_u8(vqadd_u8(accum2_u8, vdup_n_u8(ADD_FOR_ROUND)), DSHIFT);
            }
            else {
                uint16x8_t accum0 = vdupq_n_u16(SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
                uint16x8_t accum1 = vdupq_n_u16(SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
                uint16x8_t accum2 = vdupq_n_u16(SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
                accum0 = vmlal_u8(accum0, va0.val[0], vb0);
                accum1 = vmlal_u8(accum1, va0.val[1], vb0);
                accum2 = vmlal_u8(accum2, va0.val[2], vb0);
                accum0 = vmlal_u8(accum0, va1.val[0], vb1);
                accum1 = vmlal_u8(accum1, va1.val[1], vb1);
                accum2 = vmlal_u8(accum2, va1.val[2], vb1);
                out_val.val[0] = vshrn_n_u16(accum0, SHIFT);
                out_val.val[1] = vshrn_n_u16(accum1, SHIFT);
                out_val.val[2] = vshrn_n_u16(accum2, SHIFT);
            }
            if (DO_JUDGE) {
                jct->template process_pixel8<JCT_LSHIFT>(out_val);
            }
            if (TRANSPOSE) {
                uint8_t *out_b = &out[i*inherited::dh];
#if 0
                uint8_t tmp_buf[8*CH];
                vst3_u8(tmp_buf, out_val);
                for (int i = 0; i < 8; i++) {
                    out_b[i*(CH*DH)+0] = tmp_buf[i*CH+0];
                    out_b[i*(CH*DH)+1] = tmp_buf[i*CH+1];
                    out_b[i*(CH*DH)+2] = tmp_buf[i*CH+2];
                }
#else
                out_b[0*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 0);
                out_b[0*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 0);
                out_b[0*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 0);
                out_b[1*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 1);
                out_b[1*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 1);
                out_b[1*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 1);
                out_b[2*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 2);
                out_b[2*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 2);
                out_b[2*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 2);
                out_b[3*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 3);
                out_b[3*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 3);
                out_b[3*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 3);
                out_b[4*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 4);
                out_b[4*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 4);
                out_b[4*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 4);
                out_b[5*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 5);
                out_b[5*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 5);
                out_b[5*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 5);
                out_b[6*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 6);
                out_b[6*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 6);
                out_b[6*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 6);
                out_b[7*(CH*DH)+0] = vget_lane_u8(out_val.val[0], 7);
                out_b[7*(CH*DH)+1] = vget_lane_u8(out_val.val[1], 7);
                out_b[7*(CH*DH)+2] = vget_lane_u8(out_val.val[2], 7);
#endif
            }
            else {
                vst3_u8(&out[i], out_val);
            }
        }
#endif
        for (; i < size; i+=CH) {
            uint8_t val0 = dot2<SHIFT>(a0[i+0], a1[i+0], b0, b1);
            uint8_t val1 = dot2<SHIFT>(a0[i+1], a1[i+1], b0, b1);
            uint8_t val2 = dot2<SHIFT>(a0[i+2], a1[i+2], b0, b1);
            if (DO_JUDGE) {
                jct->template process_pixel<JCT_LSHIFT>(val0, val1, val2);
            }
            if (TRANSPOSE) {
                out[i*inherited::dh+0] = val0;
                out[i*inherited::dh+1] = val1;
                out[i*inherited::dh+2] = val2;
            }
            else {
                out[i+0] = val0;
                out[i+1] = val1;
                out[i+2] = val2;
            }
        }
    }

    template<int SHIFT=8>
    void vec_dot2(const uint8_t *a0, const uint8_t *a1, uint8_t b0, uint8_t b1, int size, uint8_t *out) const {
        static_assert(SHIFT >= 0, "SHIFT must be greater of equal to zero");
        if (CH == 3) { vec_dot2_ch3<SHIFT>(a0, a1, b0, b1, size, out); return; }
        int i = 0;
#if 1
        int size0 = ((size/8)*8);
        uint8x8_t vb0 = vdup_n_u8(b0);
        uint8x8_t vb1 = vdup_n_u8(b1);
        for (; i < size0; i += 8) {
            uint8x8_t va0 = vld1_u8(&a0[i]);
            uint8x8_t va1 = vld1_u8(&a1[i]);
            if (SHIFT > 8) {
                static const int DSHIFT = (SHIFT <= 8 ? 0 : SHIFT-8);
                static const uint8_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
                uint16x8_t accum = vmull_u8(va0, vb0);
                accum = vmlal_u8(accum, va1, vb1);
                uint8x8_t accum_u8 = vshrn_n_u16(accum, 8);
                vst1_u8(&out[i], vshr_n_u8(vqadd_u8(accum_u8, vdup_n_u8(ADD_FOR_ROUND)), DSHIFT));
            }
            else {
                uint16x8_t accum = vdupq_n_u16(SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
                accum = vmlal_u8(accum, va0, vb0);
                accum = vmlal_u8(accum, va1, vb1);
                vst1_u8(&out[i], vshrn_n_u16(accum, SHIFT));
            }
        }
#endif
        for (; i < size; i++) {
            out[i] = dot2<SHIFT>(a0[i], a1[i], b0, b1);
        }
    }

    template<int SHIFT>
    void vec_lshift(const uint8_t *src, uint8_t *dst, int size) const {
        int i = 0;
#if 1
        int size0 = ((size/16)*16);
        for (; i < size0; i += 16) {
            vst1q_u8(&dst[i], vshlq_n_u8(vld1q_u8(&src[i]), SHIFT));
        }
#endif
        for (; i < size; i++) {
            dst[i] = (src[i]<<SHIFT);
        }
    }

    template<int LSHIFT=0, int RSHIFT=0, bool TRANSPOSE=false, int DH=-1 /* optimize for TRANSPOSE */,
             typename JUDGE_CUT_TOP_T=JudgeCutTop<4> >
    void operator()(RowDecoderInterface<uint8_t> &row_decoder, uint8_t *dst, JUDGE_CUT_TOP_T *jct = nullptr) const {
        static_assert(LSHIFT == 0 || RSHIFT == 0, "LSHIFT or RSHIFT must be 0");
        assert(DH == -1 || inherited::dh == DH);
        bool is_upsample_y = (inherited::dh >= inherited::sh);
        bool is_upsample_x = (inherited::dw >= inherited::sw);
        bool is_upsample_ge_2x = (inherited::dw >= 2*inherited::sw);
        assert(is_upsample_y == is_upsample_x);
        if (is_upsample_ge_2x) {
            assert(is_upsample_x);
            assert(!TRANSPOSE); // not implemented yet
            assert(!jct);  // not implemented yet
            for (int y = 0; y < inherited::dh; y++) {
                int ly = inherited::yposes[y];
                int ay = inherited::yposes_add[y];
                uint8_t ply = inherited::ycoefs[y];
                assert(ply > 0);
                uint8_t puy = (1<<8)-ply;
                const uint8_t *row0 = row_decoder.getRow(ly);
                const uint8_t *row1 = (ay == 0 ? row0 : row_decoder.getRow(ly+1));
                const uint8_t *work;
                if (ay == 0) {
                    if (LSHIFT == 0) {
                        work = row0;
                    }
                    else {
                        vec_lshift<LSHIFT>(row0, work_line.data(), inherited::sw*CH);
                        work = work_line.data();
                    }
                }
                else {
                    vec_dot2<8-LSHIFT>(row0, row1, ply, puy, inherited::sw*CH, work_line.data());
                    work = work_line.data();
                }
                int x_b = 0;
                if (y < inherited::dh-1) { // not use simd at last line to avoid array out of range
                    assert(inherited::dw*CH >= 8);
                    assert(CH <= 8);
                    for (int i = 0; i < (int)inherited::xposes_rep.size(); i++) {
                        int rep = inherited::xposes_rep[i];
                        int lx = inherited::xposes[x_b];
                        int ax = inherited::xposes_add[x_b];
                        const uint8_t *src0 = work + (lx*CH);
                        const uint8_t *src1 = src0 + ax;
                        uint8x8_t vsrc0 = vld1_u8(src0);
                        uint8x8_t vsrc1 = vld1_u8(src1);
                        for (int dx = 0; dx < rep; dx++) {
                            int x = x_b + dx;
                            uint8_t plx = inherited::xcoefs[x];
                            assert(plx > 0);
                            uint8_t pux = (1<<8)-plx;
                            uint8x8_t vplx = vdup_n_u8(plx);
                            uint8x8_t vpux = vdup_n_u8(pux);
                            static const int SHIFT = 8+RSHIFT;
                            if (SHIFT > 8) {
                                static const int DSHIFT = (SHIFT <= 8 ? 0 : SHIFT-8);
                                static const uint8_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
                                uint16x8_t accum = vmull_u8(vsrc0, vplx);
                                accum = vmlal_u8(accum, vsrc1, vpux);
                                uint8x8_t accum_u8 = vshrn_n_u16(accum, 8);
                                vst1_u8(dst, vshr_n_u8(vqadd_u8(accum_u8, vdup_n_u8(ADD_FOR_ROUND)), DSHIFT));
                            }
                            else {
                                uint16x8_t accum = vdupq_n_u16((1<<(SHIFT-1)));
                                accum = vmlal_u8(accum, vsrc0, vplx);
                                accum = vmlal_u8(accum, vsrc1, vpux);
                                vst1_u8(dst, vshrn_n_u16(accum, SHIFT));
                            }
                            dst += CH;
                        }
                        x_b += rep;
                    }
                }
                else {
                    for (int i = 0; i < (int)inherited::xposes_rep.size(); i++) {
                        int rep = inherited::xposes_rep[i];
                        int lx = inherited::xposes[x_b];
                        int ax = inherited::xposes_add[x_b];
                        const uint8_t *src0 = work + (lx*CH);
                        const uint8_t *src1 = src0 + ax;
                        for (int dx = 0; dx < rep; dx++) {
                            int x = x_b + dx;
                            uint8_t plx = inherited::xcoefs[x];
                            assert(plx > 0);
                            uint8_t pux = (1<<8)-plx;
                            for (int c = 0; c < CH; c++) {
                                uint8_t val0 = src0[c];
                                uint8_t val1 = src1[c];
                                *(dst++) = dot2<8+RSHIFT>(val0, val1, plx, pux);
                            }
                        }
                        x_b += rep;
                    }
                }
            }
        }
        else {
            uint8_t * const dst_start = dst;
            if (jct) {
                jct->init();
                assert(CH == 3);
                assert(LSHIFT == 0);
            }
            bool do_judge_top_cut = (bool)jct;
            for (int y = 0; y < inherited::dh; y++) {
                if (do_judge_top_cut && y == inherited::dh/4) {
                    if (jct->judge()) {
                        return;
                    }
                    do_judge_top_cut = false;
                }
                int ly = inherited::yposes[y];
                int ay = inherited::yposes_add[y];
                uint8_t ply = inherited::ycoefs[y];
                assert(ply > 0);
                uint8_t puy = (1<<8)-ply;
                const uint8_t *row0 = row_decoder.getRow(ly);
                const uint8_t *row1 = (ay == 0 ? row0 : row_decoder.getRow(ly+1));
                if (TRANSPOSE) {
                    dst = dst_start + y*CH;
                }
                if (ay == 0) {
                    for (int x = 0; x < inherited::dw; x++) {
                        int lx = inherited::xposes[x];
                        int ax = inherited::xposes_add[x];
                        uint8_t plx = inherited::xcoefs[x];
                        assert(plx > 0);
                        uint8_t pux = (1<<8)-plx;
                        const uint8_t *src0 = row0 + (lx*CH);
                        for (int c = 0; c < CH; c++) {
                            uint8_t val0 = src0[0];
                            uint8_t val1 = src0[ax];
                            *(dst++) = dot2<8-LSHIFT+RSHIFT>(val0, val1, plx, pux);
                            ++src0;
                        }
                        if (TRANSPOSE) {
                            if (do_judge_top_cut) {
                                jct->template process_pixel<RSHIFT>(dst-CH);
                            }
                            dst += (inherited::dh*CH-CH);
                        }
                    }
                    if (!TRANSPOSE) {
                        if (do_judge_top_cut) {
                            jct->template process<RSHIFT>(dst-(inherited::dw*CH), inherited::dw);
                        }
                    }
                }
                else {
                    uint8_t *work0 = work_line0.data();
                    uint8_t *work1 = work_line1.data();
                    for (int x = 0; x < inherited::dw; x++) {
                        int lx = inherited::xposes[x];
                        int ax = inherited::xposes_add[x];
                        uint8_t plx = inherited::xcoefs[x];
                        assert(plx > 0);
                        uint8_t pux = (1<<8)-plx;
                        const uint8_t *src0 = row0 + (lx*CH);
                        const uint8_t *src1 = row1 + (lx*CH);
                        if (3 <= CH && CH <= 8) {
                            static const int SHIFT1 = 8-LSHIFT;
                            uint8x8_t vplx = vdup_n_u8(plx);
                            uint8x8_t vpux = vdup_n_u8(pux);
                            uint8x8_t vsrc0_0 = vld1_u8(src0);
                            uint8x8_t vsrc1_0 = vld1_u8(src1);
                            uint8x8_t vsrc0_1 = vld1_u8(&src0[ax]);
                            uint8x8_t vsrc1_1 = vld1_u8(&src1[ax]);
                            uint16x8_t accum0 = vdupq_n_u16((1<<(SHIFT1-1)));
                            accum0 = vmlal_u8(accum0, vsrc0_0, vplx);
                            accum0 = vmlal_u8(accum0, vsrc0_1, vpux);
                            uint8x8_t val0 = vshrn_n_u16(accum0, SHIFT1);
                            uint16x8_t accum1 = vdupq_n_u16((1<<(SHIFT1-1)));
                            accum1 = vmlal_u8(accum1, vsrc1_0, vplx);
                            accum1 = vmlal_u8(accum1, vsrc1_1, vpux);
                            uint8x8_t val1 = vshrn_n_u16(accum1, SHIFT1);
                            vst1_u8(&work0[x*CH], val0);
                            vst1_u8(&work1[x*CH], val1);
                        }
                        else {
                            for (int c = 0; c < CH; c++) {
                                uint8_t val0 = dot2<8-LSHIFT>(src0[c], src0[ax+c], plx, pux);
                                uint8_t val1 = dot2<8-LSHIFT>(src1[c], src1[ax+c], plx, pux);
                                work0[x*CH+c] = val0;
                                work1[x*CH+c] = val1;
                            }
                        }
                    }
                    if (TRANSPOSE) {
                        if (CH == 3 && DH != -1) {
                            if (do_judge_top_cut) {
                                vec_dot2_ch3<8+RSHIFT, true, DH, true>(work0, work1, ply, puy, inherited::dw*CH, dst, jct);
                            }
                            else {
                                vec_dot2_ch3<8+RSHIFT, true, DH>(work0, work1, ply, puy, inherited::dw*CH, dst);
                            }
                        }
                        else {
                            vec_dot2<8+RSHIFT>(work0, work1, ply, puy, inherited::dw*CH, work0);
                            if (do_judge_top_cut) {
                                jct->template process<RSHIFT>(work0, inherited::dw);
                            }
                            if (3 <= CH && CH <= 8 && y+((8+CH-1)/CH) <= inherited::dh) { // use simd8
                                for (int x = 0; x < inherited::dw; x++) {
                                    vst1_u8(dst, vld1_u8(work0));
                                    dst += (inherited::dh*CH);
                                    work0 += CH;
                                }
                            }
                            else {
                                for (int x = 0; x < inherited::dw; x++) {
                                    for (int c = 0; c < CH; c++) {
                                        dst[c] = work0[c];
                                    }
                                    dst += (inherited::dh*CH);
                                    work0 += CH;
                                }
                            }
                        }
                    }
                    else {
                        if (do_judge_top_cut) {
                            assert(CH == 3);
                            vec_dot2_ch3<8+RSHIFT, false, -1, true>(work0, work1, ply, puy, inherited::dw*CH, dst, jct);
                        }
                        else {
                            vec_dot2<8+RSHIFT>(work0, work1, ply, puy, inherited::dw*CH, dst);
                        }
                        dst += inherited::dw*CH;
                    }
                }
                if (do_judge_top_cut) {
                    if (!jct->judge()) {
                        do_judge_top_cut = false;
                    }
                }
            }
        }
    }

    template<int LSHIFT=0, int RSHIFT=0, bool TRANSPOSE=false, int DH=-1 /* optimize for TRANSPOSE */,
             typename JUDGE_CUT_TOP_T=JudgeCutTop<4> >
    void operator()(const uint8_t *src, uint8_t *dst, JUDGE_CUT_TOP_T *jct = nullptr) const {
        RowDecoderRawImage<uint8_t> row_decoder(src, inherited::sw*CH);
        this->template operator()<LSHIFT, RSHIFT, TRANSPOSE, DH, JUDGE_CUT_TOP_T>(row_decoder, dst, jct);
    }
};

template<int CH>
class ResizeBilinear<uint16_t, CH, 0> : public ResizeBilinearPrecompute<uint16_t, CH> {
    typedef ResizeBilinearPrecompute<uint16_t, CH> inherited;
    mutable std::vector<uint16_t> work_line;
    mutable std::vector<uint16_t> work_line0;
    mutable std::vector<uint16_t> work_line1;

  public:
    ResizeBilinear(int src_height, int src_width, int dst_height, int dst_width,
                   double nearest_th_y = 0.0, double nearest_th_x = 0.0)
        : inherited(src_height, src_width, dst_height, dst_width, nearest_th_y, nearest_th_x),
          work_line(src_width*CH),
          work_line0(dst_width*CH + 4 /* 4 for simd */),
          work_line1(dst_width*CH + 4 /* 4 for simd */)
    {
    }

    template<int SHIFT=16>
    __attribute__((always_inline)) inline uint16_t dot2(uint16_t a0, uint16_t a1, uint16_t b0, uint16_t b1) const {
        static_assert(SHIFT >= 0, "SHIFT must be greater of equal to zero");
        if (SHIFT > 16) {
            static const int DSHIFT = (SHIFT <= 16 ? 0 : SHIFT-16);
            static const uint16_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
            static uint16_t overflow_th = 65535 - ADD_FOR_ROUND;
            static uint16_t max_val = (65535>>DSHIFT);
            uint32_t acc = a0*b0;
            acc += a1*b1;
            uint16_t acc_u16 = (uint16_t)(acc >> 16);
            uint16_t ret = (acc_u16 > overflow_th ? max_val : ((acc_u16+ADD_FOR_ROUND)>>DSHIFT));
            return ret;
        }
        else {
            uint32_t acc = (SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
            acc += a0*b0;
            acc += a1*b1;
            uint16_t ret = (acc>>SHIFT);
            return ret;
        }
    }

    template<int SHIFT=16>
    void vec_dot2(const uint16_t *a0, const uint16_t *a1, uint16_t b0, uint16_t b1, int size, uint16_t *out) const {
        int i = 0;
        static_assert(SHIFT >= 0, "SHIFT must be greater of equal to zero");
#if 1
        int size0 = ((size/4)*4);
        uint16x4_t vb0 = vdup_n_u16(b0);
        uint16x4_t vb1 = vdup_n_u16(b1);
        for (; i < size0; i += 4) {
            uint16x4_t va0 = vld1_u16(&a0[i]);
            uint16x4_t va1 = vld1_u16(&a1[i]);
            if (SHIFT > 16) {
                static const int DSHIFT = (SHIFT <= 16 ? 0 : SHIFT-16);
                static const uint16_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
                uint32x4_t accum = vmull_u16(va0, vb0);
                accum = vmlal_u16(accum, va1, vb1);
                uint16x4_t accum_u16 = vshrn_n_u32(accum, 16);
                vst1_u16(&out[i], vshr_n_u16(vqadd_u16(accum_u16, vdup_n_u16(ADD_FOR_ROUND)), DSHIFT));
            }
            else {
                uint32x4_t accum = vdupq_n_u32(SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
                accum = vmlal_u16(accum, va0, vb0);
                accum = vmlal_u16(accum, va1, vb1);
                vst1_u16(&out[i], vshrn_n_u32(accum, SHIFT));
            }
        }
#endif
        for (; i < size; i++) {
            out[i] = dot2<SHIFT>(a0[i], a1[i], b0, b1);
        }
    }

    template<int SHIFT>
    void vec_lshift(const uint16_t *src, uint16_t *dst, int size) const {
        int i = 0;
#if 1
        int size0 = ((size/8)*8);
        for (; i < size0; i += 8) {
            vst1q_u16(&dst[i], vshlq_n_u16(vld1q_u16(&src[i]), SHIFT));
        }
#endif
        for (; i < size; i++) {
            dst[i] = (src[i]<<SHIFT);
        }
    }

    template<int LSHIFT=0, int RSHIFT=0, bool TRANSPOSE=false, int DH=-1 /* optimize for TRANSPOSE (not implemented) */,
             typename JUDGE_CUT_TOP_T=JudgeCutTop<4> >
    void operator()(const uint16_t *src, uint16_t *dst, JUDGE_CUT_TOP_T *jct = nullptr) const {
        static_assert(LSHIFT == 0 || RSHIFT == 0, "LSHIFT or RSHIFT must be 0");
        assert(!jct);  // not implemented yet
        bool is_upsample_y = (inherited::dh >= inherited::sh);
        bool is_upsample_x = (inherited::dw >= inherited::sw);
        bool is_upsample_ge_2x = (inherited::dw >= 2*inherited::sw);
        assert(is_upsample_y == is_upsample_x);
        if (is_upsample_ge_2x) {
            assert(is_upsample_x);
            assert(!TRANSPOSE); // not implemented yet
            for (int y = 0; y < inherited::dh; y++) {
                int ly = inherited::yposes[y];
                int ay = inherited::yposes_add[y];
                uint16_t ply = inherited::ycoefs[y];
                assert(ply > 0);
                uint16_t puy = (1<<16)-ply;
                int pos0_b = (ly*inherited::sw*CH);
                int pos1_b = pos0_b + ay;
                const uint16_t *row0 = &src[pos0_b];
                const uint16_t *row1 = &src[pos1_b];
                const uint16_t *work;
                if (ay == 0) {
                    if (LSHIFT == 0) {
                        work = row0;
                    }
                    else {
                        vec_lshift<LSHIFT>(row0, work_line.data(), inherited::sw*CH);
                        work = work_line.data();
                    }
                }
                else {
                    vec_dot2<16-LSHIFT>(row0, row1, ply, puy, inherited::sw*CH, work_line.data());
                    work = work_line.data();
                }
                int x_b = 0;
                if (y < inherited::dh-1) { // not use simd at last line to avoid array out of range
                    assert(inherited::dw*CH >= 8);
                    assert(CH <= 8);
                    if (CH <= 4) {
                        for (int i = 0; i < (int)inherited::xposes_rep.size(); i++) {
                            int rep = inherited::xposes_rep[i];
                            int lx = inherited::xposes[x_b];
                            int ax = inherited::xposes_add[x_b];
                            const uint16_t *src0 = work + (lx*CH);
                            const uint16_t *src1 = src0 + ax;
                            uint16x4_t vsrc0 = vld1_u16(src0);
                            uint16x4_t vsrc1 = vld1_u16(src1);
                            for (int dx = 0; dx < rep; dx++) {
                                int x = x_b + dx;
                                uint16_t plx = inherited::xcoefs[x];
                                assert(plx > 0);
                                uint16_t pux = (1<<16)-plx;
                                uint16x4_t vplx = vdup_n_u16(plx);
                                uint16x4_t vpux = vdup_n_u16(pux);
                                static const int SHIFT = 16+RSHIFT;
                                if (SHIFT > 16) {
                                    static const int DSHIFT = (SHIFT <= 16 ? 0 : SHIFT-16);
                                    static const uint16_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
                                    uint32x4_t accum = vmull_u16(vsrc0, vplx);
                                    accum = vmlal_u16(accum, vsrc1, vpux);
                                    uint16x4_t accum_u16 = vshrn_n_u32(accum, 16);
                                    vst1_u16(dst, vshr_n_u16(vqadd_u16(accum_u16, vdup_n_u16(ADD_FOR_ROUND)), DSHIFT));
                                }
                                else {
                                    uint32x4_t accum = vdupq_n_u32((1<<(SHIFT-1)));
                                    accum = vmlal_u16(accum, vsrc0, vplx);
                                    accum = vmlal_u16(accum, vsrc1, vpux);
                                    vst1_u16(dst, vshrn_n_u32(accum, SHIFT));
                                }
                                dst += CH;
                            }
                            x_b += rep;
                        }
                    }
                    else {
                        for (int i = 0; i < (int)inherited::xposes_rep.size(); i++) {
                            int rep = inherited::xposes_rep[i];
                            int lx = inherited::xposes[x_b];
                            int ax = inherited::xposes_add[x_b];
                            const uint16_t *src0 = work + (lx*CH);
                            const uint16_t *src1 = src0 + ax;
                            uint16x4_t vsrc0_0 = vld1_u16(src0);
                            uint16x4_t vsrc1_0 = vld1_u16(src1);
                            uint16x4_t vsrc0_1 = vld1_u16(src0+4);
                            uint16x4_t vsrc1_1 = vld1_u16(src1+4);
                            for (int dx = 0; dx < rep; dx++) {
                                int x = x_b + dx;
                                uint16_t plx = inherited::xcoefs[x];
                                assert(plx > 0);
                                uint16_t pux = (1<<16)-plx;
                                uint16x4_t vplx = vdup_n_u16(plx);
                                uint16x4_t vpux = vdup_n_u16(pux);
                                static const int SHIFT = 16+RSHIFT;
                                if (SHIFT > 16) {
                                    static const int DSHIFT = (SHIFT <= 16 ? 0 : SHIFT-16);
                                    static const uint16_t ADD_FOR_ROUND = (DSHIFT == 0 ? 0 : (1<<(DSHIFT-1)));
                                    uint32x4_t accum0 = vmull_u16(vsrc0_0, vplx);
                                    accum0 = vmlal_u16(accum0, vsrc1_0, vpux);
                                    uint16x4_t accum0_u16 = vshrn_n_u32(accum0, 16);
                                    uint32x4_t accum1 = vmull_u16(vsrc0_1, vplx);
                                    accum1 = vmlal_u16(accum1, vsrc1_1, vpux);
                                    uint16x4_t accum1_u16 = vshrn_n_u32(accum1, 16);
                                    vst1_u16(dst, vshr_n_u16(vqadd_u16(accum0_u16, vdup_n_u16(ADD_FOR_ROUND)), DSHIFT));
                                    vst1_u16(dst+4, vshr_n_u16(vqadd_u16(accum1_u16, vdup_n_u16(ADD_FOR_ROUND)), DSHIFT));
                                }
                                else {
                                    uint32x4_t accum0 = vdupq_n_u32((1<<(SHIFT-1)));
                                    accum0 = vmlal_u16(accum0, vsrc0_0, vplx);
                                    accum0 = vmlal_u16(accum0, vsrc1_0, vpux);
                                    uint32x4_t accum1 = vdupq_n_u32((1<<(SHIFT-1)));
                                    accum1 = vmlal_u16(accum1, vsrc0_1, vplx);
                                    accum1 = vmlal_u16(accum1, vsrc1_1, vpux);
                                    vst1_u16(dst, vshrn_n_u32(accum0, SHIFT));
                                    vst1_u16(dst+4, vshrn_n_u32(accum1, SHIFT));
                                }
                                dst += CH;
                            }
                            x_b += rep;
                        }
                    }
                }
                else {
                    for (int i = 0; i < (int)inherited::xposes_rep.size(); i++) {
                        int rep = inherited::xposes_rep[i];
                        int lx = inherited::xposes[x_b];
                        int ax = inherited::xposes_add[x_b];
                        const uint16_t *src0 = work + (lx*CH);
                        const uint16_t *src1 = src0 + ax;
                        for (int dx = 0; dx < rep; dx++) {
                            int x = x_b + dx;
                            uint16_t plx = inherited::xcoefs[x];
                            assert(plx > 0);
                            uint16_t pux = (1<<16)-plx;
                            for (int c = 0; c < CH; c++) {
                                uint16_t val0 = src0[c];
                                uint16_t val1 = src1[c];
                                *(dst++) = dot2<16+RSHIFT>(val0, val1, plx, pux);
                            }
                        }
                        x_b += rep;
                    }
                }
            }
        }
        else {
            uint16_t * const dst_start = dst;
            for (int y = 0; y < inherited::dh; y++) {
                int ly = inherited::yposes[y];
                int ay = inherited::yposes_add[y];
                uint16_t ply = inherited::ycoefs[y];
                assert(ply > 0);
                uint16_t puy = (1<<16)-ply;
                int pos0_b = (ly*inherited::sw*CH);
                int pos1_b = pos0_b + ay;
                const uint16_t *row0 = &src[pos0_b];
                const uint16_t *row1 = &src[pos1_b];
                if (TRANSPOSE) {
                    dst = dst_start + y*CH;
                }
                if (ay == 0) {
                    for (int x = 0; x < inherited::dw; x++) {
                        int lx = inherited::xposes[x];
                        int ax = inherited::xposes_add[x];
                        uint16_t plx = inherited::xcoefs[x];
                        assert(plx > 0);
                        uint16_t pux = (1<<16)-plx;
                        const uint16_t *src0 = row0 + (lx*CH);
                        for (int c = 0; c < CH; c++) {
                            uint16_t val0 = src0[0];
                            uint16_t val1 = src0[ax];
                            *(dst++) = dot2<16-LSHIFT+RSHIFT>(val0, val1, plx, pux);
                            ++src0;
                        }
                        if (TRANSPOSE) {
                            dst += (inherited::dh*CH-CH);
                        }
                    }
                }
                else {
                    uint16_t *work0 = work_line0.data();
                    uint16_t *work1 = work_line1.data();
                    for (int x = 0; x < inherited::dw; x++) {
                        int lx = inherited::xposes[x];
                        int ax = inherited::xposes_add[x];
                        uint16_t plx = inherited::xcoefs[x];
                        assert(plx > 0);
                        uint16_t pux = (1<<16)-plx;
                        const uint16_t *src0 = row0 + (lx*CH);
                        const uint16_t *src1 = row1 + (lx*CH);
                        if (3 <= CH && CH <= 4) { // TODO: support simd for CH>4
                            static const int SHIFT1 = 16-LSHIFT;
                            uint16x4_t vplx = vdup_n_u16(plx);
                            uint16x4_t vpux = vdup_n_u16(pux);
                            uint16x4_t vsrc0_0 = vld1_u16(src0);
                            uint16x4_t vsrc1_0 = vld1_u16(src1);
                            uint16x4_t vsrc0_1 = vld1_u16(&src0[ax]);
                            uint16x4_t vsrc1_1 = vld1_u16(&src1[ax]);
                            uint32x4_t accum0 = vdupq_n_u32((1<<(SHIFT1-1)));
                            accum0 = vmlal_u16(accum0, vsrc0_0, vplx);
                            accum0 = vmlal_u16(accum0, vsrc0_1, vpux);
                            uint16x4_t val0 = vshrn_n_u32(accum0, SHIFT1);
                            uint32x4_t accum1 = vdupq_n_u32((1<<(SHIFT1-1)));
                            accum1 = vmlal_u16(accum1, vsrc1_0, vplx);
                            accum1 = vmlal_u16(accum1, vsrc1_1, vpux);
                            uint16x4_t val1 = vshrn_n_u32(accum1, SHIFT1);
                            vst1_u16(&work0[x*CH], val0);
                            vst1_u16(&work1[x*CH], val1);
                        }
                        else {
                            for (int c = 0; c < CH; c++) {
                                uint16_t val0 = dot2<16-LSHIFT>(src0[c], src0[ax+c], plx, pux);
                                uint16_t val1 = dot2<16-LSHIFT>(src1[c], src1[ax+c], plx, pux);
                                work0[x*CH+c] = val0;
                                work1[x*CH+c] = val1;
                            }
                        }
                    }
                    if (TRANSPOSE) {
                        vec_dot2<16+RSHIFT>(work0, work1, ply, puy, inherited::dw*CH, work0);
                        for (int x = 0; x < inherited::dw; x++) {
                            for (int c = 0; c < CH; c++) {
                                dst[c] = work0[c];
                            }
                            dst += (inherited::dh*CH);
                            work0 += CH;
                        }
                    }
                    else {
                        vec_dot2<16+RSHIFT>(work0, work1, ply, puy, inherited::dw*CH, dst);
                        dst += inherited::dw*CH;
                    }
                }
            }
        }
    }
};
