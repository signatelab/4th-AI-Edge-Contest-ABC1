#pragma once

#include "Resize.hpp"
#include "Argmax.hpp"

#ifdef UPSAMPLE_ARGMAX_COPY_LEFT_CLASS
#define UPSAMPLE_ARGMAX_COPY_LEFT_CLASS_CHECK() static_assert(RUN_LENGTH_OUTPUT, "RUN_LENGTH_OUTPUT must be enabled when UPSAMPLE_ARGMAX_COPY_LEFT_CLASS is specified!!")
#else
#define UPSAMPLE_ARGMAX_COPY_LEFT_CLASS_CHECK() do { } while(false)
#endif

// UpsampleArgmax
//  upsampleとargmax処理を同時に行う. upsampleをBilinearで行う場合は最適化したコードが走る
//  template引数でチャネル数、interpolationの指定、
//  コンストラクタでサイズの指定、
//  operator()で処理を実行する
//  BilinearでUpsampleする場合に追加で row_all_same_class を指定すると
//  すべての行が同じクラスの場合に行の処理をスキップする機能がONになり速度向上
//  row_all_same_class はupsample前の画像に対してArgmaxを実行した場合に、
//  各行がすべて同じクラスかを示す配列. 同じ場合はクラス番号、違う場合は-1を設定する

// naive method (upsamle -> argmax)
template<typename T, int CH, int INTER_POLATION=cv::INTER_LINEAR, int USE_OPENCV=0, int MERGE_OP=!USE_OPENCV>
class UpsampleArgmax {
    Resize<T, CH, INTER_POLATION, USE_OPENCV> r;
    Argmax<T, CH> am;
    mutable std::vector<T> work;
    static_assert(MERGE_OP == 0, "MERGE_OP not supported");

  public:
    UpsampleArgmax(int src_height, int src_width, int dst_height, int dst_width)
        : r(src_height, src_width, dst_height, dst_width), work(dst_height*dst_width*CH)
    {}

    template<int LSHIFT=0, bool RUN_LENGTH_OUTPUT=false>
    size_t operator()(const T *src, uint8_t *dst, const int *row_all_same_class = nullptr /* unused */) const {
        static_assert(LSHIFT == 0, "LSHIFT not supported");
        static_assert(!RUN_LENGTH_OUTPUT, "RUN_LENGTH_OUTPUT not supported");
        UPSAMPLE_ARGMAX_COPY_LEFT_CLASS_CHECK();
        r(src, work.data());
        am(work.data(), dst, work.size()/CH);
        return work.size()/CH;
    }
};

// optimize for nearest (argmax -> upsample)
template<typename T, int CH, int USE_OPENCV, int MERGE_OP>
class UpsampleArgmax<T, CH, cv::INTER_NEAREST, USE_OPENCV, MERGE_OP> {
    static_assert(MERGE_OP == 0, "MERGE_OP not supported");
    ResizeNearest<uint8_t, 1, USE_OPENCV> rn;
    Argmax<T, CH> am;
    mutable std::vector<uint8_t> work;
    size_t dst_size;

  public:
    UpsampleArgmax(int src_height, int src_width, int dst_height, int dst_width)
        : rn(src_height, src_width, dst_height, dst_width), work(src_height*src_width), dst_size(dst_height*dst_width)
    {}

    template<int LSHIFT=0, bool RUN_LENGTH_OUTPUT=false>
    size_t operator()(const T *src, uint8_t *dst, const int *row_all_same_class = nullptr /* unused */) const {
        static_assert(LSHIFT == 0, "LSHIFT not supported");
        static_assert(!RUN_LENGTH_OUTPUT, "RUN_LENGTH_OUTPUT not supported");
        UPSAMPLE_ARGMAX_COPY_LEFT_CLASS_CHECK();
        am(src, work.data(), work.size());
        rn(work.data(), dst);
        return dst_size;
    }
};


// for RUN_LENGTH
#define UPSAMPLE_ARGMAX_RUNLENGTH_ENCODE(len, val) (((len)<<3)|(val))
#define UPSAMPLE_ARGMAX_RUNLENGTH_DECODE(len, val, enc) do { uint16_t _e = (enc); val = (_e&0x7); len = (_e>>3); } while(false)
inline void upsample_argmax_runlength_data_to_img(const uint16_t *encdata, uint8_t *image, size_t image_size) {
    uint16_t len;
    uint8_t val;
    size_t cur = 0;
    while (cur != image_size) {
        assert(cur < image_size);
        UPSAMPLE_ARGMAX_RUNLENGTH_DECODE(len, val, *encdata++);
        assert(len > 0);
        memset(&image[cur], val, len*sizeof(uint8_t));
        cur += len;
    }
}

struct UpsampleArgmaxRunLengthEncoder {
    typedef uint16_t* DEST_PTR_T;
    static const uint8_t INVALID_VAL = 0xff;
    DEST_PTR_T &dst;
    uint16_t last_len;
    uint8_t last_val;

    UpsampleArgmaxRunLengthEncoder(DEST_PTR_T &dst) : dst(dst), last_len(0), last_val(INVALID_VAL) {}

    void put(uint16_t len, uint8_t val) {
        if (last_val == INVALID_VAL) {
            last_len = len;
            last_val = val;
        }
        else {
            if (val == last_val
#ifdef UPSAMPLE_ARGMAX_COPY_LEFT_CLASS
                || val == UPSAMPLE_ARGMAX_COPY_LEFT_CLASS
#endif
                ) {
                last_len += len;
            }
            else {
                (*dst++) = UPSAMPLE_ARGMAX_RUNLENGTH_ENCODE(last_len, last_val);
                last_len = len;
                last_val = val;
            }
        }
    }

    ~UpsampleArgmaxRunLengthEncoder() {
        if (last_val != INVALID_VAL) {
            (*dst++) = UPSAMPLE_ARGMAX_RUNLENGTH_ENCODE(last_len, last_val);
        }
    }
};

// check run length data
inline bool UpsampleArgmaxRunLengthCheck(const uint16_t *label_data, int height, int width, int max_val) {
    for (int y = 0; y < height; y++) {
        int x = 0;
        uint8_t last_val = (uint8_t)-1;
        while (x != width) {
            if (x > width) {
                std::cerr << "Error: UpsampleArgmaxRunLengthCheck: run over row." << std::endl;
                return false;
            }
            uint16_t len;
            uint8_t val;
            UPSAMPLE_ARGMAX_RUNLENGTH_DECODE(len, val, *label_data++);
            if (len == 0) {
                std::cerr << "Error: UpsampleArgmaxRunLengthCheck: length is zero." << std::endl;
                return false;
            }
            if (val > max_val) {
                std::cerr << "Error: UpsampleArgmaxRunLengthCheck: val > max_val." << std::endl;
                return false;
            }
            if (last_val == val) {
                std::cerr << "Error: UpsampleArgmaxRunLengthCheck: last_val == val." << std::endl;
                return false;
            }
            last_val = val;
            x += len;
        }
    }
    return true;
}

#define FAST_CALC()                     \
    do {                                \
        int a0 = src0[aval0];           \
        int a1 = src1[aval0];           \
        int b0 = src0[aval1];           \
        int b1 = src1[aval1];           \
        int d = (a0-b0)+(b1-a1);        \
        int q = (a0-b0)*rep;            \
        /*assert(d >= 0);*/             \
        /*assert(q >= 0);*/             \
        int t = (2*q+d)/(2*d);          \
        /*assert(0 <= t && t <= rep);*/ \
        if (RUN_LENGTH_OUTPUT) {        \
            if (t) enc.put(t, aval0); \
            if (t < rep) enc.put(rep-t, aval1);  \
        }                                           \
        else {                                      \
            int s;                                  \
            for (s = 0; s < t; s++) dst[s] = aval0; \
            for (; s < rep; s++) dst[s] = aval1;    \
            dst += rep;                             \
        }                                           \
    } while (false)

// optimize for bilinear (T = uint8_t)
template<int CH>
class UpsampleArgmax<uint8_t, CH, cv::INTER_LINEAR, 0, 1> : public ResizeBilinearPrecompute<uint8_t, CH> {
    typedef ResizeBilinearPrecompute<uint8_t, CH> inherited;
    Argmax<uint8_t, CH> am;
    mutable std::vector<uint8_t> work_line;
    mutable std::vector<uint8_t> work_line_am;

  public:
    UpsampleArgmax(int src_height, int src_width, int dst_height, int dst_width)
        : inherited(src_height, src_width, dst_height, dst_width),
          work_line(src_width*CH),
          work_line_am(src_width)
    {
    }

    template<int SHIFT=8>
    uint8_t dot2(uint8_t a0, uint8_t a1, uint8_t b0, uint8_t b1) const {
        uint16_t acc = (SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
        acc += a0*b0;
        acc += a1*b1;
        uint8_t ret = (acc>>SHIFT);
        return ret;
    }

    template<int SHIFT=8>
    void vec_dot2(const uint8_t *a0, const uint8_t *a1, uint8_t b0, uint8_t b1, int size, uint8_t *out) const {
        int i = 0;
#if 1
        int size0 = ((size/8)*8);
        uint8x8_t vb0 = vdup_n_u8(b0);
        uint8x8_t vb1 = vdup_n_u8(b1);
        for (; i < size0; i += 8) {
            uint8x8_t va0 = vld1_u8(&a0[i]);
            uint8x8_t va1 = vld1_u8(&a1[i]);
            uint16x8_t accum = vdupq_n_u16(SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
            accum = vmlal_u8(accum, va0, vb0);
            accum = vmlal_u8(accum, va1, vb1);
            vst1_u8(&out[i], vshrn_n_u16(accum, SHIFT));
        }
#endif
        for (; i < size; i++) {
            out[i] = dot2<SHIFT>(a0[i], a1[i], b0, b1);
        }
    }

    template<int SHIFT>
    void vec_lshift(const uint8_t *src, uint8_t *dst, int size) const {
        int i = 0;
#if 1
        int size0 = ((size/16)*16);
        for (; i < size0; i += 16) {
            vst1q_u8(&dst[i], vshlq_n_u8(vld1q_u8(&src[i]), SHIFT));
        }
#endif
        for (; i < size; i++) {
            dst[i] = (src[i]<<SHIFT);
        }
    }

    template<int LSHIFT=0, bool RUN_LENGTH_OUTPUT=false>
    size_t operator()(const uint8_t *src, uint8_t *dst, const int *row_all_same_class = nullptr) const {
        assert(!RUN_LENGTH_OUTPUT || (uintptr_t)dst % 2 == 0);
        UPSAMPLE_ARGMAX_COPY_LEFT_CLASS_CHECK();
        uint16_t *dst_u16 = reinterpret_cast<uint16_t *>(dst);
        bool is_upsample_y = (inherited::dh >= inherited::sh);
        bool is_upsample_x = (inherited::dw >= inherited::sw);
        uint8_t * const dst_end = dst + (inherited::dh*inherited::dw);
        assert(is_upsample_y && is_upsample_x);
        int yi = 0;
        int rep_y = 0;
        for (int y = 0; y < inherited::dh; y++) {
            int ly = inherited::yposes[y];
            int ay = inherited::yposes_add[y];
            uint8_t ply = inherited::ycoefs[y];
            assert(ply > 0);
            uint8_t puy = (1<<8)-ply;
            int pos0_b = (ly*inherited::sw*CH);
            int pos1_b = pos0_b + ay;
            const uint8_t *row0 = &src[pos0_b];
            const uint8_t *row1 = &src[pos1_b];
            const uint8_t *work;
            if (row_all_same_class) {
                bool rep_y_start = false;
                if (rep_y == 0) {
                    rep_y = inherited::yposes_rep[yi++];
                    rep_y_start = true;
                }
                --rep_y;
                if (rep_y_start) {
                    int uy = ly + (ay != 0);
                    if (row_all_same_class[ly] >= 0 && row_all_same_class[ly] == row_all_same_class[uy]) {
                        if (RUN_LENGTH_OUTPUT) {
                            for (int dy = 0; dy < rep_y+1; dy++) {
                                *(dst_u16++) = UPSAMPLE_ARGMAX_RUNLENGTH_ENCODE(inherited::dw, row_all_same_class[uy]);
                            }
                        }
                        else {
                            memset(dst, row_all_same_class[ly], (rep_y+1)*inherited::dw);
                            dst += (rep_y+1)*inherited::dw;
                        }
                        y += rep_y;
                        rep_y = 0;
                        continue;
                    }
                }
            }
            if (ay == 0) {
                if (LSHIFT == 0) {
                    work = row0;
                }
                else {
                    vec_lshift<LSHIFT>(row0, work_line.data(), inherited::sw*CH);
                    work = work_line.data();
                }
            }
            else {
                vec_dot2<8-LSHIFT>(row0, row1, ply, puy, inherited::sw*CH, work_line.data());
                work = work_line.data();
            }

            am(work, work_line_am.data(), inherited::sw);
            const uint8_t *work_am = work_line_am.data();

            int x_b = 0;
            UpsampleArgmaxRunLengthEncoder enc(dst_u16);
            if (y < inherited::dh-1) { // not use simd at last line to avoid array out of range
                assert(inherited::dw*CH >= 8);
                assert(CH <= 8);
                for (int i = 0; i < (int)inherited::xposes_rep.size();) {
                    int rep = inherited::xposes_rep[i];
                    int lx = inherited::xposes[x_b];
                    int ax = inherited::xposes_add[x_b];
                    uint8_t aval0 = work_am[lx];
                    uint8_t aval1 = work_am[lx+(ax!=0)];
                    if (aval0 == aval1) {
                        i++;
                        x_b += rep;
                        for (;i < (int)inherited::xposes_rep.size() && work_am[inherited::xposes[x_b]+(inherited::xposes_add[x_b]!=0)] == aval0; i++) {
                            x_b += inherited::xposes_rep[i];
                            rep += inherited::xposes_rep[i];
                        }
                        if (RUN_LENGTH_OUTPUT) {
                            enc.put(rep, aval0);
                        }
                        else {
                            memset(dst, aval0, rep);
                            dst += rep;
                        }
                    }
                    else {
                        const uint8_t *src0 = work + (lx*CH);
                        const uint8_t *src1 = src0 + ax;
#ifdef UPSAMPLE_ARGMAX_USE_FAST_CALC
                        FAST_CALC();
#else
                        uint8x8_t vsrc0 = vld1_u8(src0);
                        uint8x8_t vsrc1 = vld1_u8(src1);
                        for (int dx = 0; dx < rep; dx++) {
                            int x = x_b + dx;
                            uint8_t plx = inherited::xcoefs[x];
                            assert(plx > 0);
                            uint8_t pux = (1<<8)-plx;
                            uint8x8_t vplx = vdup_n_u8(plx);
                            uint8x8_t vpux = vdup_n_u8(pux);
                            uint16x8_t accum = vdupq_n_u16((1<<7));
                            accum = vmlal_u8(accum, vsrc0, vplx);
                            accum = vmlal_u8(accum, vsrc1, vpux);
                            uint8_t tmp_buf[8];
                            vst1_u8(tmp_buf, vshrn_n_u16(accum, 8));
                            uint8_t aval = std::distance(tmp_buf, std::max_element(tmp_buf, tmp_buf+CH));
                            if (RUN_LENGTH_OUTPUT) {
                                enc.put(1, aval);
                            }
                            else {
                                (*dst++) = std::distance(tmp_buf, std::max_element(tmp_buf, tmp_buf+CH));
                            }
                        }
#endif
                        i++;
                        x_b += rep;
                    }
                }
            }
            else {
                for (int i = 0; i < (int)inherited::xposes_rep.size();) {
                    int rep = inherited::xposes_rep[i];
                    int lx = inherited::xposes[x_b];
                    int ax = inherited::xposes_add[x_b];
                    uint8_t aval0 = work_am[lx];
                    uint8_t aval1 = work_am[lx+(ax!=0)];
                    if (aval0 == aval1) {
                        i++;
                        x_b += rep;
                        for (;i < (int)inherited::xposes_rep.size() && work_am[inherited::xposes[x_b]+(inherited::xposes_add[x_b]!=0)] == aval0; i++) {
                            x_b += inherited::xposes_rep[i];
                            rep += inherited::xposes_rep[i];
                        }
                        if (RUN_LENGTH_OUTPUT) {
                            enc.put(rep, aval0);
                        }
                        else {
                            memset(dst, aval0, rep);
                            dst += rep;
                        }
                    }
                    else {
                        const uint8_t *src0 = work + (lx*CH);
                        const uint8_t *src1 = src0 + ax;
#ifdef UPSAMPLE_ARGMAX_USE_FAST_CALC
                        FAST_CALC();
#else
                        for (int dx = 0; dx < rep; dx++) {
                            int x = x_b + dx;
                            uint8_t plx = inherited::xcoefs[x];
                            assert(plx > 0);
                            uint8_t pux = (1<<8)-plx;
                            uint8_t tmp_buf[CH];
                            for (int c = 0; c < CH; c++) {
                                uint8_t val0 = src0[c];
                                uint8_t val1 = src1[c];
                                tmp_buf[c] = dot2(val0, val1, plx, pux);
                            }
                            uint8_t aval = std::distance(tmp_buf, std::max_element(tmp_buf, tmp_buf+CH));
                            if (RUN_LENGTH_OUTPUT) {
                                enc.put(1, aval);
                            }
                            else {
                                *(dst++) = aval;
                            }
                        }
#endif
                        i++;
                        x_b += rep;
                    }
                }
            }
        }
        // return write bytes
        if (RUN_LENGTH_OUTPUT) {
            return (uintptr_t)dst_u16 - (uintptr_t)dst;
        }
        else {
            assert(dst == dst_end);
            return inherited::dw * inherited::dh;
        }
    }
};

// optimize for bilinear (T = uint16_t)
template<int CH>
class UpsampleArgmax<uint16_t, CH, cv::INTER_LINEAR, 0, 1> : public ResizeBilinearPrecompute<uint16_t, CH> {
    typedef ResizeBilinearPrecompute<uint16_t, CH> inherited;
    Argmax<uint16_t, CH> am;
    mutable std::vector<uint16_t> work_line;
    mutable std::vector<uint8_t> work_line_am;

  public:
    UpsampleArgmax(int src_height, int src_width, int dst_height, int dst_width)
        : inherited(src_height, src_width, dst_height, dst_width),
          work_line(src_width*CH),
          work_line_am(src_width)
    {
    }

    template<int SHIFT=16>
    uint16_t dot2(uint16_t a0, uint16_t a1, uint16_t b0, uint16_t b1) const {
        uint32_t acc = (SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
        acc += a0*b0;
        acc += a1*b1;
        uint16_t ret = (acc>>SHIFT);
        return ret;
    }

    template<int SHIFT=16>
    void vec_dot2(const uint16_t *a0, const uint16_t *a1, uint16_t b0, uint16_t b1, int size, uint16_t *out) const {
        int i = 0;
#if 1
        int size0 = ((size/4)*4);
        uint16x4_t vb0 = vdup_n_u16(b0);
        uint16x4_t vb1 = vdup_n_u16(b1);
        for (; i < size0; i += 4) {
            uint16x4_t va0 = vld1_u16(&a0[i]);
            uint16x4_t va1 = vld1_u16(&a1[i]);
            uint32x4_t accum = vdupq_n_u32(SHIFT == 0 ? 0 : (1<<(SHIFT-1)));
            accum = vmlal_u16(accum, va0, vb0);
            accum = vmlal_u16(accum, va1, vb1);
            vst1_u16(&out[i], vshrn_n_u32(accum, SHIFT));
        }
#endif
        for (; i < size; i++) {
            out[i] = dot2<SHIFT>(a0[i], a1[i], b0, b1);
        }
    }

    template<int SHIFT>
    void vec_lshift(const uint16_t *src, uint16_t *dst, int size) const {
        int i = 0;
#if 1
        int size0 = ((size/8)*8);
        for (; i < size0; i += 8) {
            vst1q_u16(&dst[i], vshlq_n_u16(vld1q_u16(&src[i]), SHIFT));
        }
#endif
        for (; i < size; i++) {
            dst[i] = (src[i]<<SHIFT);
        }
    }

    template<int LSHIFT=0, bool RUN_LENGTH_OUTPUT=false>
    size_t operator()(const uint16_t *src, uint8_t *dst, int *row_all_same_class = nullptr) const {
        assert(!RUN_LENGTH_OUTPUT || (uintptr_t)dst % 2 == 0);
        UPSAMPLE_ARGMAX_COPY_LEFT_CLASS_CHECK();
        uint16_t *dst_u16 = reinterpret_cast<uint16_t *>(dst);
        bool is_upsample_y = (inherited::dh >= inherited::sh);
        bool is_upsample_x = (inherited::dw >= inherited::sw);
        uint8_t * const dst_end = dst + (inherited::dh*inherited::dw);
        assert(is_upsample_y && is_upsample_x);
        int yi = 0;
        int rep_y = 0;
        for (int y = 0; y < inherited::dh; y++) {
            int ly = inherited::yposes[y];
            int ay = inherited::yposes_add[y];
            uint16_t ply = inherited::ycoefs[y];
            assert(ply > 0);
            uint16_t puy = (1<<16)-ply;
            int pos0_b = (ly*inherited::sw*CH);
            int pos1_b = pos0_b + ay;
            const uint16_t *row0 = &src[pos0_b];
            const uint16_t *row1 = &src[pos1_b];
            const uint16_t *work;
            if (row_all_same_class) {
                bool rep_y_start = false;
                if (rep_y == 0) {
                    rep_y = inherited::yposes_rep[yi++];
                    rep_y_start = true;
                }
                --rep_y;
                if (rep_y_start) {
                    int uy = ly + (ay != 0);
                    if (row_all_same_class[ly] >= 0 && row_all_same_class[ly] == row_all_same_class[uy]) {
                        if (RUN_LENGTH_OUTPUT) {
                            for (int dy = 0; dy < rep_y+1; dy++) {
                                *(dst_u16++) = UPSAMPLE_ARGMAX_RUNLENGTH_ENCODE(inherited::dw, row_all_same_class[uy]);
                            }
                        }
                        else {
                            memset(dst, row_all_same_class[ly], (rep_y+1)*inherited::dw);
                            dst += (rep_y+1)*inherited::dw;
                        }
                        y += rep_y;
                        rep_y = 0;
                        continue;
                    }
                }
            }
            if (ay == 0) {
                if (LSHIFT == 0) {
                    work = row0;
                }
                else {
                    vec_lshift<LSHIFT>(row0, work_line.data(), inherited::sw*CH);
                    work = work_line.data();
                }
            }
            else {
                vec_dot2<16-LSHIFT>(row0, row1, ply, puy, inherited::sw*CH, work_line.data());
                work = work_line.data();
            }

            am(work, work_line_am.data(), inherited::sw);
            const uint8_t *work_am = work_line_am.data();

            int x_b = 0;
            UpsampleArgmaxRunLengthEncoder enc(dst_u16);
            if (y < inherited::dh-1) { // not use simd at last line to avoid array out of range
                assert(inherited::dw*CH >= 8);
                assert(CH <= 8);
                if (CH <= 4) {
                    for (int i = 0; i < (int)inherited::xposes_rep.size();) {
                        int rep = inherited::xposes_rep[i];
                        int lx = inherited::xposes[x_b];
                        int ax = inherited::xposes_add[x_b];
                        uint8_t aval0 = work_am[lx];
                        uint8_t aval1 = work_am[lx+(ax!=0)];
                        if (aval0 == aval1) {
                            i++;
                            x_b += rep;
                            for (;i < (int)inherited::xposes_rep.size() && work_am[inherited::xposes[x_b]+(inherited::xposes_add[x_b]!=0)] == aval0; i++) {
                                x_b += inherited::xposes_rep[i];
                                rep += inherited::xposes_rep[i];
                            }
                            if (RUN_LENGTH_OUTPUT) {
                                enc.put(rep, aval0);
                            }
                            else {
                                memset(dst, aval0, rep);
                                dst += rep;
                            }
                        }
                        else {
                            const uint16_t *src0 = work + (lx*CH);
                            const uint16_t *src1 = src0 + ax;
#ifdef UPSAMPLE_ARGMAX_USE_FAST_CALC
                            FAST_CALC();
#else
                            uint16x4_t vsrc0 = vld1_u16(src0);
                            uint16x4_t vsrc1 = vld1_u16(src1);
                            for (int dx = 0; dx < rep; dx++) {
                                int x = x_b + dx;
                                uint16_t plx = inherited::xcoefs[x];
                                assert(plx > 0);
                                uint16_t pux = (1<<16)-plx;
                                uint16x4_t vplx = vdup_n_u16(plx);
                                uint16x4_t vpux = vdup_n_u16(pux);
                                uint32x4_t accum = vdupq_n_u32((1<<15));
                                accum = vmlal_u16(accum, vsrc0, vplx);
                                accum = vmlal_u16(accum, vsrc1, vpux);
                                uint16_t tmp_buf[4];
                                vst1_u16(tmp_buf, vshrn_n_u32(accum, 16));
                                uint8_t aval = std::distance(tmp_buf, std::max_element(tmp_buf, tmp_buf+CH));
                                if (RUN_LENGTH_OUTPUT) {
                                    enc.put(1, aval);
                                }
                                else {
                                    (*dst++) = aval;
                                }
                            }
#endif
                            i++;
                            x_b += rep;
                        }
                    }
                }
                else {
                    for (int i = 0; i < (int)inherited::xposes_rep.size();) {
                        int rep = inherited::xposes_rep[i];
                        int lx = inherited::xposes[x_b];
                        int ax = inherited::xposes_add[x_b];
                        uint8_t aval0 = work_am[lx];
                        uint8_t aval1 = work_am[lx+(ax!=0)];
                        if (aval0 == aval1) {
                            i++;
                            x_b += rep;
                            for (;i < (int)inherited::xposes_rep.size() && work_am[inherited::xposes[x_b]+(inherited::xposes_add[x_b]!=0)] == aval0; i++) {
                                x_b += inherited::xposes_rep[i];
                                rep += inherited::xposes_rep[i];
                            }
                            if (RUN_LENGTH_OUTPUT) {
                                enc.put(rep, aval0);
                            }
                            else {
                                memset(dst, aval0, rep);
                                dst += rep;
                            }
                        }
                        else {
                            const uint16_t *src0 = work + (lx*CH);
                            const uint16_t *src1 = src0 + ax;
#ifdef UPSAMPLE_ARGMAX_USE_FAST_CALC
                            FAST_CALC();
#else
                            uint16x4_t vsrc0_0 = vld1_u16(src0);
                            uint16x4_t vsrc1_0 = vld1_u16(src1);
                            uint16x4_t vsrc0_1 = vld1_u16(src0+4);
                            uint16x4_t vsrc1_1 = vld1_u16(src1+4);
                            for (int dx = 0; dx < rep; dx++) {
                                int x = x_b + dx;
                                uint16_t plx = inherited::xcoefs[x];
                                assert(plx > 0);
                                uint16_t pux = (1<<16)-plx;
                                uint16x4_t vplx = vdup_n_u16(plx);
                                uint16x4_t vpux = vdup_n_u16(pux);
                                uint32x4_t accum0 = vdupq_n_u32((1<<15));
                                accum0 = vmlal_u16(accum0, vsrc0_0, vplx);
                                accum0 = vmlal_u16(accum0, vsrc1_0, vpux);
                                uint32x4_t accum1 = vdupq_n_u32((1<<15));
                                accum1 = vmlal_u16(accum1, vsrc0_1, vplx);
                                accum1 = vmlal_u16(accum1, vsrc1_1, vpux);
                                uint16_t tmp_buf[8];
                                vst1_u16(tmp_buf, vshrn_n_u32(accum0, 16));
                                vst1_u16(tmp_buf+4, vshrn_n_u32(accum1, 16));
                                uint8_t aval = std::distance(tmp_buf, std::max_element(tmp_buf, tmp_buf+CH));
                                if (RUN_LENGTH_OUTPUT) {
                                    enc.put(1, aval);
                                }
                                else {
                                    (*dst++) = aval;
                                }
                            }
#endif
                            i++;
                            x_b += rep;
                        }
                    }
                }
            }
            else {
                for (int i = 0; i < (int)inherited::xposes_rep.size();) {
                    int rep = inherited::xposes_rep[i];
                    int lx = inherited::xposes[x_b];
                    int ax = inherited::xposes_add[x_b];
                    uint8_t aval0 = work_am[lx];
                    uint8_t aval1 = work_am[lx+(ax!=0)];
                    if (aval0 == aval1) {
                        i++;
                        x_b += rep;
                        for (;i < (int)inherited::xposes_rep.size() && work_am[inherited::xposes[x_b]+(inherited::xposes_add[x_b]!=0)] == aval0; i++) {
                            x_b += inherited::xposes_rep[i];
                            rep += inherited::xposes_rep[i];
                        }
                        if (RUN_LENGTH_OUTPUT) {
                            enc.put(rep, aval0);
                        }
                        else {
                            memset(dst, aval0, rep);
                            dst += rep;
                        }
                    }
                    else {
                        const uint16_t *src0 = work + (lx*CH);
                        const uint16_t *src1 = src0 + ax;
#ifdef UPSAMPLE_ARGMAX_USE_FAST_CALC
                        FAST_CALC();
#else
                        for (int dx = 0; dx < rep; dx++) {
                            int x = x_b + dx;
                            uint16_t plx = inherited::xcoefs[x];
                            assert(plx > 0);
                            uint16_t pux = (1<<16)-plx;
                            uint16_t tmp_buf[CH];
                            for (int c = 0; c < CH; c++) {
                                uint16_t val0 = src0[c];
                                uint16_t val1 = src1[c];
                                tmp_buf[c] = dot2(val0, val1, plx, pux);
                            }
                            uint8_t aval = std::distance(tmp_buf, std::max_element(tmp_buf, tmp_buf+CH));
                            if (RUN_LENGTH_OUTPUT) {
                                enc.put(1, aval);
                            }
                            else {
                                *(dst++) = aval;
                            }
                        }
#endif
                        i++;
                        x_b += rep;
                    }
                }
            }
        }
        // return write bytes
        if (RUN_LENGTH_OUTPUT) {
            return (uintptr_t)dst_u16 - (uintptr_t)dst;
        }
        else {
            assert(dst == dst_end);
            return inherited::dw * inherited::dh;
        }
    }
};
