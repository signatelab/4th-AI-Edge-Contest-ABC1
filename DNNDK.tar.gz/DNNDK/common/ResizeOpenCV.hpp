#pragma once
#include <opencv2/opencv.hpp>

template<typename T, int CH, int INTER_POLATION>
class ResizeOpenCV {
    int sh, sw, dh, dw;

  public:
    ResizeOpenCV(int src_height, int src_width, int dst_height, int dst_width)
        : sh(src_height), sw(src_width), dh(dst_height), dw(dst_width)
    {}

    void operator()(const T *src, T *dst) const {
        cv::Mat srcMat(cv::Size(sw, sh), CV_MAKE_TYPE(cv::DataType<T>::type, CH), const_cast<T *>(src));
        cv::Mat dstMat(cv::Size(dw, dh), CV_MAKE_TYPE(cv::DataType<T>::type, CH), dst);
        cv::resize(srcMat, dstMat, cv::Size(dw, dh), 0.0, 0.0, INTER_POLATION);
    }
};
