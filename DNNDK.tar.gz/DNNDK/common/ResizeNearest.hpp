#pragma once
#include <cstdint>
#include <iostream>
#include <cstdlib>
#include <cmath>
#include <limits>
#include <iterator>

#include "ResizeOpenCV.hpp"

#if !defined PC_VER
#include <arm_neon.h>
#else
//#include "arm_neon.h"
#include "NEONvsSSE.h"
#endif

template<typename T, int CH>
class ResizeNearestPrecompute {
  protected:
    int sh; // src height
    int sw; // src width
    int dh; // dst height
    int dw; // dst width
    int out_size;

    std::vector<int> xposes;
    std::vector<int> xposes_rep;
    std::vector<int> yposes;
    std::vector<int> yposes_rep;

  public:
    ResizeNearestPrecompute(int src_height, int src_width, int dst_height, int dst_width)
        : sh(src_height), sw(src_width), dh(dst_height), dw(dst_width), out_size(dh*dw)
    {
        // precompute
        bool is_upsample_y = (dh > sh);
        bool is_upsample_x = (dw > sw);
        //assert(is_upsample_y == is_upsample_x);
        int denom_y = 2*dh;
        int denom_x = 2*dw;
        for (int y = 0; y < dh; y++) {
            int cy = (2*y+1)*sh-dh;
            if (is_upsample_y) {
                if (cy < 0) cy = 0;
                if (cy > (sh-1)*denom_y) cy = (sh-1)*denom_y;
            }
            int ly = (cy + denom_y/2) / denom_y;
            assert(0 <= ly && ly < sh);
            yposes.push_back(ly);
        }

        for (int x = 0; x < dw; x++) {
            int cx = (2*x+1)*sw-dw;
            if (is_upsample_x) {
                if (cx < 0) cx = 0;
                if (cx > (sw-1)*denom_x) cx = (sw-1)*denom_x;
            }
            int lx = (cx + denom_x/2) / denom_x;
            assert(0 <= lx && lx < sw);
            xposes.push_back(lx);
        }

        int rep = 1;
        for (int y = 1; y < dh; y++) {
            if (yposes[y] == yposes[y-1]) {
                rep++;
            }
            else {
                yposes_rep.push_back(rep);
                rep = 1;
            }
        }
        yposes_rep.push_back(rep);

        rep = 1;
        for (int x = 1; x < dw; x++) {
            if (xposes[x] == xposes[x-1]) {
                rep++;
            }
            else {
                xposes_rep.push_back(rep);
                rep = 1;
            }
        }
        xposes_rep.push_back(rep);

#if 0
        float scale_x = (float)sw/dw;
        float margin = 0.25;
        if (3.0 - margin <= scale_x && scale_x <= 3.0 + margin) {  // almost 1/3 scale
            for (int x = 0; x < dw;) {
                int nx;
                for (nx = x+1; nx < dw && xposes[nx]-xposes[nx-1] == 3; nx++);
                int seq = nx-x;
                std::cout << seq << std::endl;
                if (nx != dw) {
                    std::cout << "->" << xposes[nx]-xposes[nx-1] << std::endl;
                }
                x = nx;
            }
        }
#endif
    }
};

template<typename T, int CH, int USE_OPENCV=0>
class ResizeNearest{};

// opencv
template<int CH> class ResizeNearest<uint8_t, CH, 1> : public ResizeOpenCV<uint8_t, CH, cv::INTER_NEAREST> {
  public:
    ResizeNearest(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeOpenCV<uint8_t, CH, cv::INTER_NEAREST>(src_height, src_width, dst_height, dst_width) {}
};
template<int CH> class ResizeNearest<uint16_t, CH, 1> : public ResizeOpenCV<uint16_t, CH, cv::INTER_NEAREST> {
  public:
    ResizeNearest(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeOpenCV<uint16_t, CH, cv::INTER_NEAREST>(src_height, src_width, dst_height, dst_width) {}
};
template<int CH> class ResizeNearest<float, CH, 1> : public ResizeOpenCV<float, CH, cv::INTER_NEAREST> {
  public:
    ResizeNearest(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeOpenCV<float, CH, cv::INTER_NEAREST>(src_height, src_width, dst_height, dst_width) {}
};

template<typename T, int CH>
class ResizeNearest<T, CH, 0> : public ResizeNearestPrecompute<T, CH> {
    typedef ResizeNearestPrecompute<T, CH> inherited;

  public:
    ResizeNearest(int src_height, int src_width, int dst_height, int dst_width)
        : inherited(src_height, src_width, dst_height, dst_width) {}

    void resize_x_1936_to_640_u8c1(const uint8_t *__restrict__ src, uint8_t *__restrict__ dst) const {
        src += 1;
        for (int j = 0; j < 19; j++) {
            *(dst++) = *src;
            src += 3;
        }
        *(dst++) = *src;
        src += 4;
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 39; j++) {
                *(dst++) = *src;
                src += 3;
            }
            *(dst++) = *src;
            src += 4;
        }
        for (int j = 0; j < 19; j++) {
            *(dst++) = *src;
            src += 3;
        }
        *(dst++) = *src;
    }

    void resize_x_1936_to_640_u8c3(const uint8_t *__restrict__ src, uint8_t *__restrict__ dst) const {
        src += CH;
        for (int j = 0; j < 19; j++) {
            dst[j*CH+0] = src[j*3*CH+0];
            dst[j*CH+1] = src[j*3*CH+1];
            dst[j*CH+2] = src[j*3*CH+2];
        }
        dst += 19*CH;
        src += 19*3*CH;
        dst[0] = src[0];
        dst[1] = src[1];
        dst[2] = src[2];
        dst += CH;
        src += 4*CH;
        for (int i = 0; i < 15; i++) {
            for (int j = 0; j < 39; j++) {
                dst[j*CH+0] = src[j*3*CH+0];
                dst[j*CH+1] = src[j*3*CH+1];
                dst[j*CH+2] = src[j*3*CH+2];
            }
            dst += 39*CH;
            src += 39*3*CH;
            dst[0] = src[0];
            dst[1] = src[1];
            dst[2] = src[2];
            dst += CH;
            src += 4*CH;
        }
        for (int j = 0; j < 19; j++) {
            dst[j*CH+0] = src[j*3*CH+0];
            dst[j*CH+1] = src[j*3*CH+1];
            dst[j*CH+2] = src[j*3*CH+2];
        }
        dst += 19*CH;
        src += 19*3*CH;
        dst[0] = src[0];
        dst[1] = src[1];
        dst[2] = src[2];
    }

    void operator()(const T *__restrict__ src, T *__restrict__ dst) const {
        bool is_upsample_y = (inherited::dh > inherited::sh);
        if (is_upsample_y) {
            int y = 0;
            const int row_size = inherited::dw*CH;
            for (int yi = 0; yi < (int)inherited::yposes_rep.size(); yi++) {
                int ly = inherited::yposes[y];
                const T *row = &src[ly*inherited::sw*CH];
                for (int ry = 0; ry < inherited::yposes_rep[yi]; ry++) {
                    if (ry == 0) {
                        if (sizeof(T) == 1 && CH == 1) {
                            int x = 0;
                            for (int xi = 0; xi < (int)inherited::xposes_rep.size(); xi++) {
                                int n = inherited::xposes_rep[xi];
                                int lx = inherited::xposes[x];
                                memset(&dst[x], row[lx*CH], n);
                                x += n;
                            }
                            dst += inherited::dw;
                        }
                        else {
                            for (int x = 0; x < inherited::dw; x++) {
                                int lx = inherited::xposes[x];
                                const T *src0 = &row[lx*CH];
                                if (CH == 1) {
                                    dst[0] = src0[0];
                                }
                                else if (CH == 3) {
                                    dst[0] = src0[0];
                                    dst[1] = src0[1];
                                    dst[2] = src0[2];
                                }
                                else {
                                    memcpy(dst, src0, sizeof(T)*CH);
                                }
                                dst += CH;
                            }
                        }
                    }
                    else {
                        memcpy(dst, dst-row_size, sizeof(T)*row_size);
                        dst += row_size;
                    }
                    ++y;
                }
            }
        }
        else {
            if (sizeof(T) == 1 && CH == 3 && inherited::sw == 1936 && inherited::dw == 640) {
                for (int y = 0; y < inherited::dh; y++) {
                    int ly = inherited::yposes[y];
                    const T *row = &src[ly*inherited::sw*CH];
                    resize_x_1936_to_640_u8c3((uint8_t *)row, (uint8_t *)dst);
                    dst += inherited::dw*CH;
                }
            }
            else {
                for (int y = 0; y < inherited::dh; y++) {
                    int ly = inherited::yposes[y];
                    const T *row = &src[ly*inherited::sw*CH];
                    for (int x = 0; x < inherited::dw; x++) {
                        int lx = inherited::xposes[x];
                        const T *src0 = &row[lx*CH];
                        if (CH == 1) {
                            dst[0] = src0[0];
                        }
                        else if (CH == 3) {
                            dst[0] = src0[0];
                            dst[1] = src0[1];
                            dst[2] = src0[2];
                        }
                        else {
                            memcpy(dst, src0, sizeof(T)*CH);
                        }
                        dst += CH;
                    }
                }
            }
        }
    }
};
