#pragma once

#include <vector>
#include <cstring>
#include <cstdint>
#include <cassert>

#if !defined PC_VER
#include <arm_neon.h>
#else
//#include "arm_neon.h"
#include "NEONvsSSE.h"
#endif

template<int COLOR_DIV_N_LOG2=4>
class JudgeCutTop {
  public:
    static const int COLOR_DIV_N = (1<<COLOR_DIV_N_LOG2);
    static const int NUM_COLOR_REGION = 256/COLOR_DIV_N;
    static const int NR = NUM_COLOR_REGION*NUM_COLOR_REGION*NUM_COLOR_REGION;
  private:
    uint8_t mask[NR];
    const std::vector<int> targetColorRegions;
    uint8_t mask_or;
    bool last_judge;

  public:
    JudgeCutTop(const std::vector<int> &targetColorRegions) :
        targetColorRegions(targetColorRegions), mask_or(0), last_judge(false) {
        memset(mask, 0, sizeof(mask));
        for (const auto &v : targetColorRegions) {
            mask[v] = 1;
        }
    }
    void init(void) {
        mask_or = 0;
    }

    template<int LSHIFT>
    __attribute__((always_inline)) inline static int calc_idx(uint8_t R, uint8_t G, uint8_t B) {
#if 0
        int ri = (R<<LSHIFT)/COLOR_DIV_N;
        int gi = (G<<LSHIFT)/COLOR_DIV_N;
        int bi = (B<<LSHIFT)/COLOR_DIV_N;
        return ri*NUM_COLOR_REGION*NUM_COLOR_REGION + gi*NUM_COLOR_REGION + bi;
#else
        R >>= (COLOR_DIV_N_LOG2-LSHIFT);
        G >>= (COLOR_DIV_N_LOG2-LSHIFT);
        B >>= (COLOR_DIV_N_LOG2-LSHIFT);
        return ((int)R<<(2*(8-COLOR_DIV_N_LOG2)) | (int)G<<(8-COLOR_DIV_N_LOG2) | (int)B);
#endif
    }
    template<int LSHIFT>
    __attribute__((always_inline)) inline void process_pixel(uint8_t R, uint8_t G, uint8_t B) {
        mask_or |= mask[calc_idx<LSHIFT>(R, G, B)];
    }
    template<int LSHIFT>
    __attribute__((always_inline)) inline void process_pixel(const uint8_t *pixels) {
        process_pixel<LSHIFT>(pixels[0], pixels[1], pixels[2]);
    }
    template<int LSHIFT>
    __attribute__((always_inline)) inline void process_pixel16(const uint8x16x3_t &pix16) {
        // calc_idx simd16
        uint8x16_t r16 = vshrq_n_u8(pix16.val[0], COLOR_DIV_N_LOG2-LSHIFT); // R >>= (COLOR_DIV_N_LOG2-LSHIFT);
        uint8x16_t g16 = vshrq_n_u8(pix16.val[1], COLOR_DIV_N_LOG2-LSHIFT); // G >>= (COLOR_DIV_N_LOG2-LSHIFT);
        uint8x16_t b16 = vshrq_n_u8(pix16.val[2], COLOR_DIV_N_LOG2-LSHIFT); // B >>= (COLOR_DIV_N_LOG2-LSHIFT);
        uint16x8_t ri16_l = vshll_n_u8(vget_low_u8(r16), (2*(8-COLOR_DIV_N_LOG2)));  // uint16_t ri = R<<(2*(8-COLOR_DIV_N_LOG2));
        uint16x8_t ri16_h = vshll_n_u8(vget_high_u8(r16), (2*(8-COLOR_DIV_N_LOG2))); // uint16_t ri = R<<(2*(8-COLOR_DIV_N_LOG2));
        uint16x8_t gi16_l = vshll_n_u8(vget_low_u8(g16), (8-COLOR_DIV_N_LOG2));      // uint16_t gi = G<<(8-COLOR_DIV_N_LOG2);
        uint16x8_t gi16_h = vshll_n_u8(vget_high_u8(g16), (8-COLOR_DIV_N_LOG2));     // uint16_t gi = G<<(8-COLOR_DIV_N_LOG2);
        uint8x8_t bi8_l = vget_low_u8(b16);  uint16x8_t bi16_l = vmovl_u8(bi8_l);    // uint16_t bi = B;
        uint8x8_t bi8_h = vget_high_u8(b16); uint16x8_t bi16_h = vmovl_u8(bi8_h);    // uint16_t bi = B;
        uint16x8_t idx_l = vorrq_u16(ri16_l, vorrq_u16(gi16_l, bi16_l));             // uint16_t idx = (ri | gi | bi);
        uint16x8_t idx_h = vorrq_u16(ri16_h, vorrq_u16(gi16_h, bi16_h));             // uint16_t idx = (ri | gi | bi);
        // mask_or |= mask[idx];
        mask_or |= (mask[vgetq_lane_u16(idx_l, 0)] |
                    mask[vgetq_lane_u16(idx_l, 1)] |
                    mask[vgetq_lane_u16(idx_l, 2)] |
                    mask[vgetq_lane_u16(idx_l, 3)] |
                    mask[vgetq_lane_u16(idx_l, 4)] |
                    mask[vgetq_lane_u16(idx_l, 5)] |
                    mask[vgetq_lane_u16(idx_l, 6)] |
                    mask[vgetq_lane_u16(idx_l, 7)] |
                    mask[vgetq_lane_u16(idx_h, 0)] |
                    mask[vgetq_lane_u16(idx_h, 1)] |
                    mask[vgetq_lane_u16(idx_h, 2)] |
                    mask[vgetq_lane_u16(idx_h, 3)] |
                    mask[vgetq_lane_u16(idx_h, 4)] |
                    mask[vgetq_lane_u16(idx_h, 5)] |
                    mask[vgetq_lane_u16(idx_h, 6)] |
                    mask[vgetq_lane_u16(idx_h, 7)]);
    }
    template<int LSHIFT>
    __attribute__((always_inline)) inline void process_pixel16(const uint8_t *pixels) {
        uint8x16x3_t pix16 = vld3q_u8(pixels);
        process_pixel16<LSHIFT>(pix16);
    }
    template<int LSHIFT>
    __attribute__((always_inline)) inline void process_pixel8(const uint8x8x3_t &pix8) {
        // calc_idx simd8
        uint8x8_t r8 = vshr_n_u8(pix8.val[0], COLOR_DIV_N_LOG2-LSHIFT); // R >>= (COLOR_DIV_N_LOG2-LSHIFT);
        uint8x8_t g8 = vshr_n_u8(pix8.val[1], COLOR_DIV_N_LOG2-LSHIFT); // G >>= (COLOR_DIV_N_LOG2-LSHIFT);
        uint8x8_t b8 = vshr_n_u8(pix8.val[2], COLOR_DIV_N_LOG2-LSHIFT); // B >>= (COLOR_DIV_N_LOG2-LSHIFT);
        uint16x8_t ri8 = vshll_n_u8(r8, (2*(8-COLOR_DIV_N_LOG2)));      // uint16_t ri = R<<(2*(8-COLOR_DIV_N_LOG2));
        uint16x8_t gi8 = vshll_n_u8(g8, (8-COLOR_DIV_N_LOG2));          // uint16_t gi = G<<(8-COLOR_DIV_N_LOG2);
        uint16x8_t bi8 = vmovl_u8(b8);                                  // uint16_t bi = B;
        uint16x8_t idx = vorrq_u16(ri8, vorrq_u16(gi8, bi8));           // uint16_t idx = (ri | gi | bi);
        // mask_or |= mask[idx];
        mask_or |= (mask[vgetq_lane_u16(idx, 0)] |
                    mask[vgetq_lane_u16(idx, 1)] |
                    mask[vgetq_lane_u16(idx, 2)] |
                    mask[vgetq_lane_u16(idx, 3)] |
                    mask[vgetq_lane_u16(idx, 4)] |
                    mask[vgetq_lane_u16(idx, 5)] |
                    mask[vgetq_lane_u16(idx, 6)] |
                    mask[vgetq_lane_u16(idx, 7)]);
    }

    template<int LSHIFT>
    void process(const uint8_t *pixels, int num_pixels) {
        int i = 0;
        int num_pixels0 = (num_pixels & 0xfffffff0); // num_pixels0 = (num_pixels/16)*16)
        for (; i < num_pixels0; i+=16) {
            process_pixel16<LSHIFT>(&pixels[3*i]);
        }
        for (; i < num_pixels; i++) {
            process_pixel<LSHIFT>(&pixels[3*i]);
        }
    }
    bool judge(void) {
        last_judge = (mask_or == 0);
        return last_judge;
    }
    bool get_last_judge(void) const { return last_judge; }
};
