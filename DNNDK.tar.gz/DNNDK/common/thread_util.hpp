#pragma once

#include <mutex>
#include <condition_variable>
#include <vector>
#include <cassert>

// channel for single thread put, single thread get
template<typename T>
class SyncChannel {
  const size_t size;
  std::vector<T> data;  // ring buffer
  size_t rp;
  size_t wp;
  bool empty_flg;
  bool full_flg;
  std::mutex mtx;
  std::condition_variable cv_full_clr;
  std::condition_variable cv_empty_clr;

public:
  SyncChannel(size_t size = 1) :
    size(size),
    data(size),
    rp(0),
    wp(0),
    empty_flg(true),
    full_flg(false)
  {
    assert(size > 0);
  }

  // blocking put
  void put(const T &d = T()) {
    // wait while full
    std::unique_lock<std::mutex> scope_lock(mtx);
    cv_full_clr.wait(scope_lock, [&]{ return !full_flg; });

    // put data
    data[wp++] = d;
    if (wp == size) {
      wp = 0;
    }

    // full check
    if (wp == rp) {
      full_flg = true;
    }
    
    // clear empty
    if (empty_flg) {
      empty_flg = false;
      cv_empty_clr.notify_one();
    }
  }

  // blocking get
  T get(void) {
    // wait while empty
    std::unique_lock<std::mutex> scope_lock(mtx);
    cv_empty_clr.wait(scope_lock, [&]{ return !empty_flg; });

    // get data
    T ret = data[rp++];
    if (rp == size) {
      rp = 0;
    }

    // empty check
    if (rp == wp) {
      empty_flg = true;
    }

    // clear full
    if (full_flg) {
      full_flg = false;
      cv_full_clr.notify_one();
    }

    return ret;
  }

  // blocking peek
  T peek(void) {
    // wait while empty
    std::unique_lock<std::mutex> scope_lock(mtx);
    cv_empty_clr.wait(scope_lock, [&]{ return !empty_flg; });

    return data[rp];
  }

  bool empty(void) const { return empty_flg; }
};

// channel for multiple threads put, single thread get
template<typename T>
class SyncChannelMPSG {
  const int num_put_threads;
  const size_t size;
  std::vector<std::vector<T> > data_v;  // ring buffer
  std::vector<size_t> rp_v;
  std::vector<size_t> wp_v;
  std::vector<int> empty_flg_v;
  std::vector<int> full_flg_v;
  bool all_empty_flg;
  std::mutex mtx;
  std::vector<std::condition_variable> cv_full_clr_v;
  std::condition_variable cv_empty_clr;

public:
  SyncChannelMPSG(int num_put_threads, size_t size_per_thread = 1) :
    num_put_threads(num_put_threads),
    size(size_per_thread),
    data_v(num_put_threads, std::vector<T>(size)),
    rp_v(num_put_threads, 0),
    wp_v(num_put_threads, 0),
    empty_flg_v(num_put_threads, true),
    full_flg_v(num_put_threads, false),
    all_empty_flg(true),
    cv_full_clr_v(num_put_threads)
  {
    assert(size > 0);
  }

  // blocking put
  void put(int tid, const T &d = T()) {
    std::vector<T> &data = data_v[tid];
    size_t &rp = rp_v[tid];
    size_t &wp = wp_v[tid];
    int &empty_flg = empty_flg_v[tid];
    int &full_flg = full_flg_v[tid];
    std::condition_variable &cv_full_clr = cv_full_clr_v[tid];

    // wait while full
    std::unique_lock<std::mutex> scope_lock(mtx);
    cv_full_clr.wait(scope_lock, [&]{ return !full_flg; });

    // put data
    data[wp++] = d;
    if (wp == size) {
      wp = 0;
    }

    // full check
    if (wp == rp) {
      full_flg = true;
    }

    // clear empty
    if (empty_flg) {
      empty_flg = false;
      if (all_empty_flg) {
          all_empty_flg = false;
          cv_empty_clr.notify_one();
      }
    }
  }

  // blocking get
  T get(const std::vector<int> &priority, int &tid) {
    // wait while empty
    std::unique_lock<std::mutex> scope_lock(mtx);
    cv_empty_clr.wait(scope_lock, [&]{ return !all_empty_flg; });

    // select
    assert((int)priority.size() == num_put_threads);
    tid = -1;
    for (int i = 0; i < num_put_threads; i++) {
        if (!empty_flg_v[i] &&
            (tid == -1 || priority[i] > priority[tid])) {
            tid = i;
        }
    }
    assert(tid != -1);
    std::vector<T> &data = data_v[tid];
    size_t &rp = rp_v[tid];
    size_t &wp = wp_v[tid];
    int &empty_flg = empty_flg_v[tid];
    int &full_flg = full_flg_v[tid];
    std::condition_variable &cv_full_clr = cv_full_clr_v[tid];

    // get data
    T ret = data[rp++];
    if (rp == size) {
      rp = 0;
    }

    // empty check
    if (rp == wp) {
      empty_flg = true;
      bool all_emp = true;
      for (int i = 0; i < num_put_threads; i++) {
          all_emp = (all_emp && empty_flg_v[i]);
      }
      all_empty_flg = all_emp;
    }

    // clear full
    if (full_flg) {
      full_flg = false;
      cv_full_clr.notify_one();
    }

    return ret;
  }
};

class ThreadBarrier {
  private:
    std::size_t num_threads;
    std::size_t counter;
    bool toggle;
    std::mutex mtx;
    std::condition_variable cv;

  public:
    explicit ThreadBarrier(std::size_t num_threads) :
        num_threads(num_threads),
        counter(num_threads),
        toggle(true)
    {
        assert(0 != num_threads);
    }

    ThreadBarrier(ThreadBarrier const&) = delete;
    ThreadBarrier &operator = (ThreadBarrier const&) = delete;

    bool wait(void) {
        std::unique_lock< std::mutex > lk(mtx);
        const bool toggle_cur = toggle;
        --counter;
        if (counter == 0) {
            toggle = !toggle;
            counter = num_threads;
            lk.unlock();
            cv.notify_all();
            return true;
        }
        cv.wait(lk, [&](){ return toggle != toggle_cur; });
        return false;
    }
};
