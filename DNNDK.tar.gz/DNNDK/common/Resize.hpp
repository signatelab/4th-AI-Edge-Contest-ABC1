#pragma once

#include "ResizeBilinear.hpp"
#include "ResizeNearest.hpp"
#include "ResizeOpenCV.hpp"

template<typename T, int CH, int INTER_POLATION, int USE_OPENCV>
class Resize {};

// opencv
template<typename T, int CH, int INTER_POLATION>
class Resize<T, CH, INTER_POLATION, 1> : public ResizeOpenCV<T, CH, INTER_POLATION> {
  public:
    Resize(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeOpenCV<T, CH, INTER_POLATION>(src_height, src_width, dst_height, dst_width) {}
};

// my resize bilinear
template<typename T, int CH>
class Resize<T, CH, cv::INTER_LINEAR, 0> : public ResizeBilinear<T, CH, 0> {
  public:
    Resize(int src_height, int src_width, int dst_height, int dst_width, double nearest_th_y = 0.0, double nearest_th_x = 0.0)
        : ResizeBilinear<T, CH, 0>(src_height, src_width, dst_height, dst_width, nearest_th_y, nearest_th_x) {}
};

// my resize nearest
template<typename T, int CH>
class Resize<T, CH, cv::INTER_NEAREST, 0> : public ResizeNearest<T, CH, 0> {
  public:
    Resize(int src_height, int src_width, int dst_height, int dst_width)
        : ResizeNearest<T, CH, 0>(src_height, src_width, dst_height, dst_width) {}
};
