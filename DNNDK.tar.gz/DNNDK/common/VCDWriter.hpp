#pragma once
#include <iostream>
#include <string>
#include <chrono>
#include <vector>
#include <sstream>
#include <fstream>
#include <map>
#include <set>
#include <cassert>
#include <ctime>
#include <algorithm>
#include <cstdlib>

template<typename T>
struct VCDTrace {
    typedef T data_type;
    std::vector<std::chrono::system_clock::time_point> times;
    std::vector<T> values;
    std::string name;

    VCDTrace(std::string name, T init_val={}) : name(name) {
        this->add(init_val);
    }

    void add(T val, std::chrono::system_clock::time_point time = std::chrono::system_clock::now()) {
        if (values.empty() || values.back() != val) {
            times.push_back(time);
            values.push_back(val);
        }
    }

    void set_name(const std::string &n) { name = n; }
    const std::string &get_name(void) const { return name; }

    enum DulationType {
        DulationRisingEdgeToFallingEdge,
        DulationFallingEdgeToRisingEdge,
        DulationAllChange
    };

    template<typename TIME_T = std::chrono::microseconds>
    std::vector<uint64_t> extract_durations(DulationType dutype = DulationRisingEdgeToFallingEdge) {
        int size = times.size();
        std::vector<uint64_t> ret;
        if (dutype == DulationAllChange) {
            for (int i = 0; i < size-1; i++) {
                ret.push_back((std::chrono::duration_cast<TIME_T>(times[i+1] - times[i])).count());
            }
        }
        else if (dutype == DulationRisingEdgeToFallingEdge) {
            for (int i = 0; i < size-2; i++) {
                bool is_zero_i0 = !values[i];
                bool is_zero_i1 = !values[i+1];
                if (is_zero_i0 && !is_zero_i1) {  // rising edge
                    bool found = false;
                    for (int j = i+1; j < size-1; j++) {
                        bool is_zero_j0 = !values[j];
                        bool is_zero_j1 = !values[j+1];
                        if (!is_zero_j0 && is_zero_j1) { // faling edge
                            ret.push_back((std::chrono::duration_cast<TIME_T>(times[j+1] - times[i+1])).count());
                            i = j;
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        break;
                    }
                }
            }
        }
        else {
            assert(dutype == DulationFallingEdgeToRisingEdge);
            for (int i = 0; i < size-2; i++) {
                bool is_zero_i0 = !values[i];
                bool is_zero_i1 = !values[i+1];
                if (!is_zero_i0 && is_zero_i1) {  // faling edge
                    bool found = false;
                    for (int j = i+1; j < size-1; j++) {
                        bool is_zero_j0 = !values[j];
                        bool is_zero_j1 = !values[j+1];
                        if (is_zero_j0 && !is_zero_j1) { // rising edge
                            ret.push_back((std::chrono::duration_cast<TIME_T>(times[j+1] - times[i+1])).count());
                            i = j;
                            found = true;
                            break;
                        }
                    }
                    if (!found) {
                        break;
                    }
                }
            }
        }
        return ret;
    }
};

template<typename T> struct VCDGetBitWidth {};
template<> struct VCDGetBitWidth<bool> { static const int val = 1; };
template<> struct VCDGetBitWidth<uint8_t> { static const int val = 8; };
template<> struct VCDGetBitWidth<uint16_t> { static const int val = 16; };
template<> struct VCDGetBitWidth<uint32_t> { static const int val = 32; };

template<typename T> struct VCDValueToStr {};
template<typename T> struct VCDValueToStrUint {
    static std::string run(T val) {
        if (val == 0) return "b0";
        std::string ret;
        while(val) {
            ret += ((val & 1) ? "1" : "0");
            val >>= 1;
        }
        std::reverse(ret.begin(), ret.end());
        return "b" + ret;
    }
};
template<> struct VCDValueToStr<bool> { static std::string run(bool val) { return (val ? "1" : "0"); } };
template<> struct VCDValueToStr<uint8_t> : public VCDValueToStrUint<uint8_t> {};
template<> struct VCDValueToStr<uint16_t> : public VCDValueToStrUint<uint16_t> {};
template<> struct VCDValueToStr<uint32_t> : public VCDValueToStrUint<uint32_t> {};

class VCDWriter {
    std::map<std::chrono::system_clock::time_point, std::vector<std::pair<std::string, std::string> > > data;
    std::map<std::string, std::string> name2id;
    std::map<std::string, int> bitwidth;
    std::string top_name;
    size_t num_traces;

    template<typename T>
    void register_trace(const VCDTrace<T> &trace) {
        if (name2id.find(trace.name) != name2id.end()) {
            std::cerr << "Error: " << __PRETTY_FUNCTION__ << ": trace '" << trace.name << "' is already registerd!!" << std::endl;
            std::exit(1);
        }
        name2id[trace.name] = calc_ascii_id(num_traces++);
        bitwidth[trace.name] = VCDGetBitWidth<T>::val;
    }

    std::string get_id(const std::string &name) {
        assert(name2id.find(name) != name2id.end());
        return name2id[name];
    }

    std::string calc_ascii_id(size_t idx) {
        static const char start_char = '!';
        static const char end_char = '~';
        static const size_t num_chars = (end_char - start_char + 1);

        int length = 1;
        size_t cur_max_idx = num_chars;
        while (idx >= cur_max_idx) {
            idx -= cur_max_idx;
            cur_max_idx *= num_chars;
            length++;
        }

        std::string ret(length, ' ');
        for (int i = 0; i < length; i++) {
            ret[length-i-1] = (char)((idx % num_chars) + start_char);
            idx /= num_chars;
        }

        return ret;
    }

    void print_header(std::ostream &os) {
        os << "$data" << std::endl;
        time_t rawtime;
        struct tm *timeinfo;
        char buffer[80];
        time(&rawtime);
        timeinfo = localtime(&rawtime);
        strftime(buffer, sizeof(buffer), "%Y-%m-%d %H:%M:%S", timeinfo);
        os << "\t" << buffer << std::endl;
        os << "$end" << std::endl;
        os << "$version" << std::endl;
        os << "\tVCD Writer" << std::endl;
        os << "$end" << std::endl;
        os << "$timescale" << std::endl;
        os << "\t1us" << std::endl;
        os << "$end" << std::endl;
    }

    std::vector<std::string> get_scope(const std::string &n) {
        std::vector<std::string> ret;
        size_t pos = 0;
        size_t last_pos = 0;
        while ((pos = n.find(".", pos)) != std::string::npos) {
            if (pos == last_pos) {
                std::cerr << "Error: empty scope found at '" << n << "'" << std::endl;
                std::exit(1);
            }
            ret.push_back(n.substr(last_pos, pos-last_pos));
            pos++;
            last_pos = pos;
        }
        return ret;
    }

    void print_change_scope(std::ostream &os, const std::vector<std::string> &cur_scope, const std::vector<std::string> &next_scope) {
        unsigned int scope_depth = cur_scope.size();
        // upscope until same scope
        while(scope_depth > 0) {
            bool ok = true;
            if (scope_depth > next_scope.size()) {
                ok = false;
            }
            else {
                for (unsigned int i = 0; i < scope_depth; i++) {
                    if (cur_scope[i] != next_scope[i]) {
                        ok = false;
                        break;
                    }
                }
            }
            if (ok) {
                break;
            }
            os << "$upscope $end" << std::endl;
            --scope_depth;
        }
        
        // downscope
        for (; scope_depth < next_scope.size(); scope_depth++) {
            os << "$scope module " << next_scope[scope_depth] << ":: $end" << std::endl;
        }
    }

    std::string remove_scope(std::string n) {
        size_t pos = n.find_last_of(".");
        if (pos == std::string::npos) {
            return n;
        }
        else {
            return n.substr(pos+1, n.length()-pos-1);
        }
    }

    void print_vardef(std::ostream &os) {
        std::set<std::string> w;
        os << "$scope module " << top_name << " $end" << std::endl;
        std::vector<std::string> cur_scope;
        for (const auto &n : name2id) {
            std::vector<std::string> scope = get_scope(n.first);
            print_change_scope(os, cur_scope, scope);
            cur_scope = scope;
            int bw = bitwidth[n.first];
            if (bw == 1) {
                os << "$var reg 1 " << n.second << " " << remove_scope(n.first) << " $end" << std::endl;
            }
            else {
                os << "$var reg " << bw << " " << n.second << " " << remove_scope(n.first) << " [" << bw-1 << ":0] $end" << std::endl;
            }
        }
        print_change_scope(os, cur_scope, std::vector<std::string>());
        os << "$upscope $end" << std::endl;
        os << "$enddefinitions $end" << std::endl;
    }

  public:
    VCDWriter(std::string name) : top_name(name), num_traces(0) {}

    template<typename T>
    void add(const VCDTrace<T> &trace) {
        register_trace(trace);
        std::string id = get_id(trace.name);
        for (int i = 0; i < (int)trace.values.size(); i++) {
            data[trace.times[i]].push_back(std::pair<std::string, std::string>{id, VCDValueToStr<T>::run(trace.values[i])});
        }
    }

    void write(std::ostream &os) {
        print_header(os);
        print_vardef(os);
        assert(!data.empty());
        static unsigned int start_offset = 10;

        std::chrono::system_clock::time_point start_time = data.begin()->first;

        os << "#0" << std::endl;
        os << "$dumpvars" << std::endl;
        for (const auto &n : name2id) {
            if (bitwidth[n.first] == 1) {
                os << "x" << n.second << std::endl;
            }
            else {
                os << "bx " << n.second << std::endl;
            }
        }
        os << "$end" << std::endl;

        auto last_duration = (std::chrono::duration_cast<std::chrono::microseconds>(start_time - start_time)).count();
        for (const auto &d : data) {
            auto duration = (std::chrono::duration_cast<std::chrono::microseconds>(d.first - start_time)).count()+start_offset;
            if (last_duration != duration) {
                last_duration = duration;
                os << "#" << duration << std::endl;
            }
            for (const auto &v : d.second) {
                if (v.second[0] == 'b') {
                    os << v.second << " " << v.first << std::endl;
                }
                else {
                    os << v.second << v.first << std::endl;
                }
            }
        }
    }

    void write_file(std::string filename) {
        std::ofstream ofs(filename);
        if (!ofs) {
            std::cerr << "Error: " << __PRETTY_FUNCTION__ << ": cannot open " << filename << std::endl;
            std::exit(1);
        }
        this->write(ofs);
    }
};
