#pragma once
#include <cstdint>
#include <cassert>

#if !defined PC_VER
#include <arm_neon.h>
#else
//#include "arm_neon.h"
#include "NEONvsSSE.h"
#endif

class BlockFloat {
  public:
    // convert u16 to block float u8 (no rounding)
    static int u16_to_u8(const uint16_t *src, uint8_t *dst, int size) {
        int size0 = (size/8)*8;

        // find max_val
        uint16_t max_val = 0;
        int i = 0;
        if (size0) {
            uint16x8_t vmax_val = vdupq_n_u16(0);
            for (i = 0; i < size0; i+=8) {
                vmax_val = vmaxq_u16(vmax_val, vld1q_u16(&src[i]));
            }
            uint16_t tmp[8];
            vst1q_u16(tmp, vmax_val);
            for (int j = 0; j < 8; j++) {
                if (tmp[j] > max_val) {
                    max_val = tmp[j];
                }
            }
        }
        for (; i < size; i++) {
            if (src[i] > max_val) {
                max_val = src[i];
            }
        }

        // calc right shift value
        static int u8_max = 255;
        int shift = 0;
        for (shift = 0; shift < 8; shift++) {
            if ((max_val>>shift) <= u8_max) {
                break;
            }
        }

        // right shift
        switch (shift) {
          case 0: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vmovn_u16(vld1q_u16(&src[i]))); } break;
          case 1: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 1)); } break;
          case 2: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 2)); } break;
          case 3: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 3)); } break;
          case 4: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 4)); } break;
          case 5: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 5)); } break;
          case 6: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 6)); } break;
          case 7: for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 7)); } break;
          default: assert(shift == 8); for (i = 0; i < size0; i+=8) { vst1_u8(&dst[i], vshrn_n_u16(vld1q_u16(&src[i]), 8)); } break;
        }
        for (; i < size; i++) {
            dst[i] = (uint8_t)(src[i]>>shift);
        }

        return shift;
    }
};
