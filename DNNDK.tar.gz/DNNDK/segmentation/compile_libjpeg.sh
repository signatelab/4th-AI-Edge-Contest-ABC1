#!/bin/bash

LIBJPEG_DIR="libjpeg-9.1.0"
LIBJPEG_TURBO_DIR="libjpeg-turbo-2.0.5"

if [ -f ${LIBJPEG_DIR}/.libs/libjpeg.a ]; then
    echo "${LIBJPEG_DIR} is already compiled"
else
    if [ -d ${LIBJPEG_DIR} ]; then
        cd ${LIBJPEG_DIR}
        ./configure
        make
        cd ..
    else
        echo "${LIBJPEG_DIR} not exists. skip compile"
    fi
fi

if [ -f ${LIBJPEG_TURBO_DIR}/build/libjpeg.a ]; then
    echo "${LIBJPEG_TURBO_DIR} is already compiled"
else
    if [ -d ${LIBJPEG_TURBO_DIR} ]; then
        cd ${LIBJPEG_TURBO_DIR}
        mkdir build
        cd build
        if [ `uname -m` = "x86_64" ]; then
            cmake .. -DWITH_JPEG8=TRUE
        else
            cmake ..
        fi
        make
        cd ../..
    else
        echo "${LIBJPEG_TURBO_DIR} not exists. skip compile"
    fi
fi
