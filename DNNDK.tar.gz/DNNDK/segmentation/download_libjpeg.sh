#!/bin/bash
if [ -d libjpeg-9.1.0 ]; then
    echo "libjpeg-9.1.0 already exists"
else
    rm -rf libjpeg-9.1.0
    wget http://www.ijg.org/files/jpegsrc.v9a.tar.gz
    tar zxf jpegsrc.v9a.tar.gz
    rm -f jpegsrc.v9a.tar.gz
    mv jpeg-9a libjpeg-9.1.0
fi
if [ -d libjpeg-turbo-2.0.5 ]; then
    echo "libjpeg-turbo-2.0.5 already exits"
else
    rm -rf libjpeg-turbo-2.0.5
    wget https://github.com/libjpeg-turbo/libjpeg-turbo/archive/2.0.5.tar.gz
    tar zxf 2.0.5.tar.gz
    rm -f 2.0.5.tar.gz
fi
