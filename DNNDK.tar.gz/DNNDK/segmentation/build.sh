#!/bin/bash

make clean
make USE_LIB_JPEG_TURBO=1
