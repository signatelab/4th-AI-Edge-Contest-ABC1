#!/bin/bash
if [ -d onnxruntime-linux-x64-1.6.0 ]; then
    echo "onnxruntime-linux-x64-1.6.0 already exists"
else
    wget https://github.com/microsoft/onnxruntime/releases/download/v1.6.0/onnxruntime-linux-x64-1.6.0.tgz
    tar zxvf onnxruntime-linux-x64-1.6.0.tgz
    rm -f onnxruntime-linux-x64-1.6.0.tgz
fi

