#pragma once

/*---- Read ----*/
static const int JPEG_SCALE_NUM = 1;
static const int JPEG_SCALE_DENOM = 1;
static const int JPEG_IMAGE_BUFFER_SIZE = 1000000;  // max jpeg filesize for USE_ROW_DECODE_JPEG
/*--------------*/

/*---- Preprocess ----*/
#define USE_INPUT_RESIZE_BILINEAR
#define USE_OPT_RESIZE_INPUT  // use optimized code for resize input
#define USE_BILINER_MERGED_TRANSPOSE
#define USE_INPUT_BILINEAR_RSHIFT
//#define USE_INPUT_RESIZE_BILINEAR_TF  // [DEBUG]: use tensorflow tf.image.resize_bilinear for input resize
//#define USE_ROW_DECODE_JPEG
/*--------------------*/

/*---- Postprocess ----*/
#define USE_OUTPUT_RESIZE_BILINEAR
#define USE_OPT_RESIZE_OUTPUT_ADD // use optimized code for resize output_add1, output_add2
#define USE_OPT_RESIZE_OUTPUT  // use optimized code for resize output_add
#define USE_BILINER_MERGED_ARGMAX
#define USE_LOGITS_RSHIFT_FOR_U8
#define NARROW_LOGITS_TO_U8
#define USE_ROW_ALL_SAME_CLASS
#define UPSAMPLE_ARGMAX_USE_FAST_CALC
#define USE_ARGMAX_RUN_LENGTH_OUTPUT
//#define UPSAMPLE_ARGMAX_COPY_LEFT_CLASS 5  // copy left class when undef class (=5)
//#define UPSAMPLE_ARGMAX_IGNORE_CLASS 5  // calculate argmax without undef class (=5)
//#define UPSAMPLE_ARGMAX_LSHIFT (16-(8+2))
/*--------------------*/

/*---- DPU ----*/
#define USE_DPU_SPLIT_IO
//#define DPU_MODEL0_TRANSPOSE
#define DPU_MODEL1_TRANSPOSE
//#define USE_DPU_GET_INPUT_PRIORITY
//#define USE_THREAD_BARRIER
//#define BLOCKING_DPU_SEGMENTATION
//#define PRINT_DPU_TASK_PARAMETER
/*---------------*/

/*---- WriteJSON ----*/
#define WRITE_JSON_USE_STRING_BUF
/*-------------------*/
