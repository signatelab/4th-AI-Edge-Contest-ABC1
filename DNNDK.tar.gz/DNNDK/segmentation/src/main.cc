#include <deque>
#include <assert.h>
#include <dirent.h>
#include <stdio.h>
#include <stdlib.h>
#include <atomic>
#include <sys/stat.h>
#include <sys/time.h>
#include <cstdio>
#include <iomanip>
#include <unistd.h>
#include <algorithm>
#include <chrono>
#include <cmath>
#include <fstream>
#include <iostream>
#include <mutex>
#include <opencv2/opencv.hpp>
#include <queue>
#include <string>
#include <thread>
#include <vector>
#include <sched.h>
#include <pthread.h>
#include <getopt.h>

#if !defined PC_VER
#include <arm_neon.h>
#else
#include "NEONvsSSE.h"
#endif

// Header files for DNNDK APIs
#if !defined PC_VER
#include <dnndk/dnndk.h>
#endif

#include "config.hpp"

#include "Resize.hpp"
#include "Argmax.hpp"
#include "UpsampleArgmax.hpp"
#include "BlockFloat.hpp"
#include "JudgeCutTop.hpp"

#include "MeasureTime.hpp"

#include "thread_util.hpp"

using namespace std;
using namespace std::chrono;
using namespace cv;

#ifdef USE_INPUT_RESIZE_BILINEAR_TF
#include "ResizeBilinearTF.hpp"
#endif

#ifdef USE_LIB_JPEG_V910
#include "../libjpeg-9.1.0/jpeglib.h"
#endif

#ifdef USE_LIB_JPEG_TURBO_V205
#include "../libjpeg-turbo-2.0.5/jpeglib.h"
#endif

#ifdef USE_ROW_DECODE_JPEG
#if !defined(USE_LIB_JPEG_V910) && !defined(USE_LIB_JPEG_TURBO_V205)
static_assert(false, "USE_LIB_JPEG_V910 or USE_LIB_JPEG_TURBO_V205 must be defined when USE_ROW_DECODE_JPEG");
#endif
#if !defined(USE_OPT_RESIZE_INPUT)
static_assert(false, "USE_OPT_RESIZE_INPUT must be defined when USE_ROW_DECODE_JPEG");
#endif
#if !defined(USE_INPUT_RESIZE_BILINEAR)
static_assert(false, "USE_INPUT_RESIZE_BILINEAR must be defined when USE_ROW_DECODE_JPEG");
#endif
#define ROW_DECODE_JPEG_UNSUPPORTED() assert(false && "USE_ROW_DECODE_JPEG is not supported")
#define ROW_DECODE_JPEG_UNSUPPORTED_S() static_assert(false, "USE_ROW_DECODE_JPEG is not supported")
#else // USE_ROW_DECODE_JPEG
#define ROW_DECODE_JPEG_UNSUPPORTED() do { } while(false)
#define ROW_DECODE_JPEG_UNSUPPORTED_S() do { } while(false)
#endif

/* ****************************************************************************************** */
#define SHOWTIME
#ifdef TIME_LEVEL
static const int TIME_LEVEL_DEFAULT = TIME_LEVEL;
#undef TIME_LEVEL
#else
static const int TIME_LEVEL_DEFAULT = 1;
#endif
int TIME_LEVEL = TIME_LEVEL_DEFAULT;
int TIME_PRINT_LEVEL = 0;
bool OUTPUT_EXTRA_VCD_TRACE = (TIME_LEVEL >= 1);

#ifdef SHOWTIME
#define _T(name, func, level) do {                                \
        MEASURE_TIME_WITH_EN(name, level<=TIME_LEVEL) {           \
            func;                                                 \
        }                                                         \
        if (level<=TIME_LEVEL && level<=TIME_PRINT_LEVEL) PRINT_MEASURE_TIME(); \
    } while (false)
#else
#define _T(name, func, level) func
#endif

#define _T0(name, func) _T(name, func, 0)
#define _T1(name, func) _T(name, func, 1)
#define _T2(name, func) _T(name, func, 2)
/* ****************************************************************************************** */

// macro function
//#define MAX(a, b) ((a)>(b)?(a):(b))
//#define MIN(a, b) ((a)<(b)?(a):(b))
#if defined(USE_LIB_JPEG_V910) || defined(USE_LIB_JPEG_TURBO_V205)
#define JPEG_SCALE(n) (JPEG_SCALE_NUM*(n)/JPEG_SCALE_DENOM)
#else
#define JPEG_SCALE(n) (n)
#endif

// dump directory (for Debug)
static const string DUMP_DIR = "dumps/";

// global variable (TODO: change to local variable)
static double INPUT_RESIZE_NEAREST_NEIGHBOR_THRESHOLD_X;
static double INPUT_RESIZE_NEAREST_NEIGHBOR_THRESHOLD_Y;
static int DPU_TASK_MODE;  // DPU Task mode (T_MODE_NORMAL or T_MODE_DEBUG or T_MODE_PROFILE)

// constant for segmentation network
#define CONV_INPUT_NODE "In_Block_In_Block_conv2d_Conv2D"
#define CONV_OUTPUT_NODE "Out_Block_Out_Block_conv2d_Conv2D"
#define CONV_OUTPUT_ADD1_NODE "Out_Add1_Out_Add1_conv2d_Conv2D"
#define CONV_OUTPUT_ADD2_NODE "Out_Add2_Out_Add2_conv2d_Conv2D"

static const int ORIG_IMAGE_WIDTH = 1936;
static const int ORIG_IMAGE_HEIGHT = 1216;
static const int ORIG_IMAGE_CHANNEL = 3;
static const int ORIG_IMAGE_SIZE = (ORIG_IMAGE_HEIGHT*ORIG_IMAGE_WIDTH*ORIG_IMAGE_CHANNEL);
static const int VALID_IMAGE_HEIGHT = 1088;
static const int VALID_IMAGE_SIZE = (VALID_IMAGE_HEIGHT*ORIG_IMAGE_WIDTH*ORIG_IMAGE_CHANNEL);
static const int LABEL_IMAGE_SIZE = (VALID_IMAGE_HEIGHT*ORIG_IMAGE_WIDTH);

static const int SCALED_ORIG_IMAGE_WIDTH = JPEG_SCALE(ORIG_IMAGE_WIDTH);
static const int SCALED_ORIG_IMAGE_HEIGHT = JPEG_SCALE(ORIG_IMAGE_HEIGHT);
static const int SCALED_ORIG_IMAGE_SIZE = (SCALED_ORIG_IMAGE_HEIGHT*SCALED_ORIG_IMAGE_WIDTH*ORIG_IMAGE_CHANNEL);
static const int SCALED_VALID_IMAGE_HEIGHT = JPEG_SCALE(VALID_IMAGE_HEIGHT);
static const int SCALED_VALID_IMAGE_SIZE = (SCALED_VALID_IMAGE_HEIGHT*SCALED_ORIG_IMAGE_WIDTH*ORIG_IMAGE_CHANNEL);

static const int NUM_CLASS = 6;
static const int NUM_VALID_CLASS = 4;
static const unsigned int IMG_IDX_INVALID = INT_MAX;

static const int NUM_NN_MODELS = 2;
static const int JUDGE_CUT_TOP_COLOR_DIV_N_LOG2 = 4;

struct UNetDPUParameterCommon {
    static const int DPU_INPUT_CHANNEL = 3;
    static const int DPU_OUTPUT_CHANNEL = NUM_CLASS;
};

struct UNetDPUParameterNormalSet {
    static const int MODEL_ID = 0;
    static const std::string KERNEL_BASE_NAME(void) { return "unet"; }
    static const bool CUT_TOP_QUARTER = false;
#ifdef DPU_MODEL0_TRANSPOSE
    static const bool DPU_TRANSPOSE_HW = true;
#else
    static const bool DPU_TRANSPOSE_HW = false;
#endif
    static const int NN_INPUT_WIDTH = 448;  // input width before transpose
    static const int NN_INPUT_HEIGHT = 256; // input height before transpose
    static const int DPU_INPUT_FIXED_Q = 7;
    static const int DPU_OUTPUT_FIXED_Q = 1;
    static const int DPU_OUTPUT_ADD1_FIXED_Q = 2;
    static const int DPU_OUTPUT_ADD2_FIXED_Q = 2;
    static_assert(MODEL_ID < NUM_NN_MODELS, "Check MODEL_ID");
};

struct UNetDPUParameterCutTopQuarterSet {
    static const int MODEL_ID = 1;
    static const std::string KERNEL_BASE_NAME(void) { return "unet_cutq"; }
    static const bool CUT_TOP_QUARTER = true;
#ifdef DPU_MODEL1_TRANSPOSE
    static const bool DPU_TRANSPOSE_HW = true;
#else
    static const bool DPU_TRANSPOSE_HW = false;
#endif
    static const int NN_INPUT_WIDTH = 448;  // input width before transpose
    static const int NN_INPUT_HEIGHT = 192; // input height before transpose
    static const int DPU_INPUT_FIXED_Q = 7;
    static const int DPU_OUTPUT_FIXED_Q = 2;
    static const int DPU_OUTPUT_ADD1_FIXED_Q = 2;
    static const int DPU_OUTPUT_ADD2_FIXED_Q = 3;
    static_assert(MODEL_ID < NUM_NN_MODELS, "Check MODEL_ID");
};

template<typename ParamSet>
struct UNetDPUParameterCalc : public UNetDPUParameterCommon, public ParamSet {
    // inline ParamSet
#define INLINE_PARAMSET(param) static const decltype(ParamSet::param) param = ParamSet::param;
    INLINE_PARAMSET(MODEL_ID);
    INLINE_PARAMSET(CUT_TOP_QUARTER);
    INLINE_PARAMSET(DPU_TRANSPOSE_HW);
    INLINE_PARAMSET(NN_INPUT_WIDTH);
    INLINE_PARAMSET(NN_INPUT_HEIGHT);
    INLINE_PARAMSET(DPU_INPUT_FIXED_Q);
    INLINE_PARAMSET(DPU_OUTPUT_FIXED_Q);
    INLINE_PARAMSET(DPU_OUTPUT_ADD1_FIXED_Q);
    INLINE_PARAMSET(DPU_OUTPUT_ADD2_FIXED_Q);
#undef INLINE_PARAMSET

    static const int NN_OUTPUT_WIDTH = NN_INPUT_WIDTH/2;
    static const int NN_OUTPUT_HEIGHT = NN_INPUT_HEIGHT/2;

    static const int DPU_INPUT_WIDTH = DPU_TRANSPOSE_HW ? NN_INPUT_HEIGHT : NN_INPUT_WIDTH;
    static const int DPU_INPUT_HEIGHT = DPU_TRANSPOSE_HW ? NN_INPUT_WIDTH : NN_INPUT_HEIGHT;
    static const int DPU_OUTPUT_WIDTH = DPU_TRANSPOSE_HW ? NN_OUTPUT_HEIGHT : NN_OUTPUT_WIDTH;
    static const int DPU_OUTPUT_HEIGHT = DPU_TRANSPOSE_HW ? NN_OUTPUT_WIDTH : NN_OUTPUT_HEIGHT;
    static const int DPU_OUTPUT_ADD1_WIDTH = DPU_OUTPUT_WIDTH/32;
    static const int DPU_OUTPUT_ADD1_HEIGHT = DPU_OUTPUT_HEIGHT/32;
    static const int DPU_OUTPUT_ADD2_WIDTH = DPU_OUTPUT_WIDTH/4;
    static const int DPU_OUTPUT_ADD2_HEIGHT = DPU_OUTPUT_HEIGHT/4;

    static const int DPU_INPUT_SIZE = (DPU_INPUT_HEIGHT*DPU_INPUT_WIDTH*DPU_INPUT_CHANNEL);
    static const int DPU_OUTPUT_SIZE = (DPU_OUTPUT_HEIGHT*DPU_OUTPUT_WIDTH*DPU_OUTPUT_CHANNEL);
    static const int DPU_OUTPUT_ADD1_SIZE = (DPU_OUTPUT_ADD1_HEIGHT*DPU_OUTPUT_ADD1_WIDTH*DPU_OUTPUT_CHANNEL);
    static const int DPU_OUTPUT_ADD2_SIZE = (DPU_OUTPUT_ADD2_HEIGHT*DPU_OUTPUT_ADD2_WIDTH*DPU_OUTPUT_CHANNEL);
    static const int DPU_OUTPUT_SIZE_ALIGN8 = ((DPU_OUTPUT_SIZE+7)/8)*8;
    static const int DPU_OUTPUT_ADD1_SIZE_ALIGN8 = ((DPU_OUTPUT_ADD1_SIZE+7)/8)*8;
    static const int DPU_OUTPUT_ADD2_SIZE_ALIGN8 = ((DPU_OUTPUT_ADD2_SIZE+7)/8)*8;
    static const int DPU_OUTPUT_TOTAL_SIZE = (DPU_OUTPUT_SIZE_ALIGN8+DPU_OUTPUT_ADD1_SIZE_ALIGN8+DPU_OUTPUT_ADD2_SIZE_ALIGN8);
    static const int DPU_INPUT_SHIFT = (8-DPU_INPUT_FIXED_Q);
    static const int DPU_INPUT_ADD_FOR_ROUND = (1<<(DPU_INPUT_SHIFT-1));

    static const int DPU_OUTPUT_MIN_FIXED_Q = MIN(MIN(DPU_OUTPUT_FIXED_Q, DPU_OUTPUT_ADD1_FIXED_Q), DPU_OUTPUT_ADD2_FIXED_Q);
    static const int DPU_OUTPUT_MAX_FIXED_Q = MAX(MAX(DPU_OUTPUT_FIXED_Q, DPU_OUTPUT_ADD1_FIXED_Q), DPU_OUTPUT_ADD2_FIXED_Q);
    static const int DPU_OUTPUT_SHIFT = (DPU_OUTPUT_MAX_FIXED_Q - DPU_OUTPUT_FIXED_Q);
    static const int DPU_OUTPUT_ADD1_SHIFT = (DPU_OUTPUT_MAX_FIXED_Q - DPU_OUTPUT_ADD1_FIXED_Q);
    static const int DPU_OUTPUT_ADD2_SHIFT = (DPU_OUTPUT_MAX_FIXED_Q - DPU_OUTPUT_ADD2_FIXED_Q);
    static const int DPU_OUTPUT_RSHIFT = (DPU_OUTPUT_FIXED_Q - DPU_OUTPUT_MIN_FIXED_Q);
    static const int DPU_OUTPUT_ADD1_RSHIFT = (DPU_OUTPUT_ADD1_FIXED_Q - DPU_OUTPUT_MIN_FIXED_Q);
    static const int DPU_OUTPUT_ADD2_RSHIFT = (DPU_OUTPUT_ADD2_FIXED_Q - DPU_OUTPUT_MIN_FIXED_Q);

    // for cut_top_quarter
    static const int VALID_IMAGE_STARTY2 = (CUT_TOP_QUARTER ? VALID_IMAGE_HEIGHT/4 : 0);
    static const int VALID_IMAGE_HEIGHT2 = (CUT_TOP_QUARTER ? (3*VALID_IMAGE_HEIGHT)/4 : VALID_IMAGE_HEIGHT);
    static const int SCALED_VALID_IMAGE_STARTY2 = JPEG_SCALE(VALID_IMAGE_STARTY2);
    static const int SCALED_VALID_IMAGE_HEIGHT2 = JPEG_SCALE(VALID_IMAGE_HEIGHT2);

    static const std::string KERNEL_NAME(bool debug_mode=false) {
        std::string ret = ParamSet::KERNEL_BASE_NAME();
        if (DPU_TRANSPOSE_HW) {
            ret += "_tr";
        }
#ifdef USE_DPU_SPLIT_IO
        ret += "_split_io";
#endif
        if (debug_mode) {
            ret += "_debug";
        }
        return ret;
    }
};

typedef UNetDPUParameterCalc<UNetDPUParameterNormalSet> UNetDPUParameterNormal;
typedef UNetDPUParameterCalc<UNetDPUParameterCutTopQuarterSet> UNetDPUParameterCutTopQuarter;

#ifdef PC_VER
#include "dnndk_dummy.inc"
#endif

struct FrameData {
    union {
#if defined(USE_LIB_JPEG_V910) || defined(USE_LIB_JPEG_TURBO_V205)
#ifdef USE_ROW_DECODE_JPEG
        uint8_t input_image[JPEG_IMAGE_BUFFER_SIZE];
#else
        uint8_t input_image[SCALED_VALID_IMAGE_SIZE];
#endif
#else
        uint8_t input_image[SCALED_ORIG_IMAGE_SIZE];
#endif
        struct {
#ifndef USE_DPU_SPLIT_IO
            int8_t dpu_output[UNetDPUParameterNormal::DPU_OUTPUT_TOTAL_SIZE];
#endif
#ifdef USE_LOGITS_RSHIFT_FOR_U8
            uint8_t logitsAdd1_u8[UNetDPUParameterNormal::DPU_OUTPUT_ADD1_SIZE];
            uint8_t logitsAdd_u8[UNetDPUParameterNormal::DPU_OUTPUT_ADD2_SIZE];
#else
            uint16_t logitsAdd1_u16[UNetDPUParameterNormal::DPU_OUTPUT_ADD1_SIZE];
            uint16_t logitsAdd_u16[UNetDPUParameterNormal::DPU_OUTPUT_ADD2_SIZE];
            uint16_t logitsOut_u16[UNetDPUParameterNormal::DPU_OUTPUT_SIZE];
#endif
            uint8_t logitsOut_u8[UNetDPUParameterNormal::DPU_OUTPUT_SIZE];
            uint16_t logitsOutTr[UNetDPUParameterNormal::DPU_OUTPUT_SIZE];
            uint8_t label_image[LABEL_IMAGE_SIZE];
        };
    };
#ifdef USE_DPU_SPLIT_IO
    int8_t *dpu_input;
    int8_t *dpu_output;
#else
    int8_t dpu_input[UNetDPUParameterNormal::DPU_INPUT_SIZE];
#endif
};

struct UNetBuffers {
    FrameData * const frameData;
    unsigned int * const modelSelectResult;
    size_t * const labelSize;

    UNetBuffers(int num_images)
        : frameData(new FrameData[num_images]),
          modelSelectResult(new unsigned int[num_images]),
          labelSize(new size_t[num_images])
    {
    }

    ~UNetBuffers(void) {
        delete [] frameData;
        delete [] modelSelectResult;
        delete [] labelSize;
    }
};

void set_thread_affinity(pthread_t pid, int cpu_id) {
    // check cpu_id
    int num_cores = std::thread::hardware_concurrency();
    if (cpu_id >= num_cores) {
        std::cerr << "Warning: set_thread_affinity: cpu_id(=" << cpu_id << ") exceeds number_of_cpus(=" << num_cores << "). set cpu_id = " << cpu_id%num_cores << " instead" << endl;
        cpu_id = cpu_id % num_cores;
    }
    // Create a cpu_set_t object representing a set of CPUs. Clear it and mark only CPU cpu_id as set.
    cpu_set_t cpuset;
    CPU_ZERO(&cpuset);
    CPU_SET(cpu_id, &cpuset);
    int rc = pthread_setaffinity_np(pid, sizeof(cpu_set_t), &cpuset);
    if (rc != 0) {
        std::cerr << "Error calling pthread_setaffinity_np: " << rc << "\n";
        std::exit(1);
    }
}

void set_thread_schedparam(pthread_t pid, int policy, int priority) {
    struct sched_param param;
    param.sched_priority = priority;
    int rc = pthread_setschedparam(pid, policy, &param);
    if (rc != 0) {
        std::cerr << "Error calling pthread_setschedparam: " << rc << "\n";
        std::exit(1);
    }
}

#ifdef USE_DPU_SPLIT_IO
typedef struct {
    int8_t *addrVirt;  /* virtural address of DPU input/output memory buffer */
    int8_t *addrPhy;   /* pysical address of DPU input/output memory buffer */
    int size;          /* byte size of DPU input/output memory buffer */
} dpuBufferInfo;
#endif

class UNetDPUTasksInterface {
  public:
    virtual void initializeMemory(void) = 0;
    virtual void run(int tid) = 0;
#ifdef USE_DPU_SPLIT_IO
    virtual void bindIO(int tid, const dpuBufferInfo &inBufferInfo, const dpuBufferInfo &outBufferInfo) = 0;
#else
    virtual int8_t *getDPUInputAddr(int tid) = 0;
    virtual int8_t *getDPUOutputAddr(int tid) = 0;
#endif
    virtual ~UNetDPUTasksInterface() {}
};

template<typename UNET_DPU_PARAM_T>
struct UNetDPUTasks : public UNetDPUTasksInterface {
    typedef UNET_DPU_PARAM_T P;

    const int num_tasks;
    DPUKernel *kernel_conv;
    vector<DPUTask *> task;
    vector<int8_t *> dpuInputAddr;
    vector<int8_t *> dpuOutputAddr;
    vector<int8_t *> dpuOutputAdd1Addr;
    vector<int8_t *> dpuOutputAdd2Addr;

    UNetDPUTasks(int num_tasks) :
        num_tasks(num_tasks),
        task(num_tasks),
        dpuInputAddr(num_tasks),
        dpuOutputAddr(num_tasks),
        dpuOutputAdd1Addr(num_tasks),
        dpuOutputAdd2Addr(num_tasks)
    {
        // Create DPU Kernels and Tasks for CONV Nodes
        kernel_conv = dpuLoadKernel(P::KERNEL_NAME(::DPU_TASK_MODE != 0).c_str());

        for (int tid = 0; tid < num_tasks; tid++) {
            task[tid] = dpuCreateTask(kernel_conv, ::DPU_TASK_MODE);

            // get parameter
            const int inputHeight = dpuGetInputTensorHeight(task[tid], CONV_INPUT_NODE, 0);
            const int inputWidth = dpuGetInputTensorWidth(task[tid], CONV_INPUT_NODE, 0);
            const int inputChannel = dpuGetInputTensorChannel(task[tid], CONV_INPUT_NODE, 0);
            const float inputScale = dpuGetInputTensorScale(task[tid], CONV_INPUT_NODE, 0);
            const int outputHeight = dpuGetOutputTensorHeight(task[tid], CONV_OUTPUT_NODE, 0);
            const int outputWidth = dpuGetOutputTensorWidth(task[tid], CONV_OUTPUT_NODE, 0);
            const int outputChannel = dpuGetOutputTensorChannel(task[tid], CONV_OUTPUT_NODE, 0);
            const float outputScale = dpuGetOutputTensorScale(task[tid], CONV_OUTPUT_NODE, 0);
            const int outputAdd1Height = dpuGetOutputTensorHeight(task[tid], CONV_OUTPUT_ADD1_NODE, 0);
            const int outputAdd1Width = dpuGetOutputTensorWidth(task[tid], CONV_OUTPUT_ADD1_NODE, 0);
            const int outputAdd1Channel = dpuGetOutputTensorChannel(task[tid], CONV_OUTPUT_ADD1_NODE, 0);
            const float outputAdd1Scale = dpuGetOutputTensorScale(task[tid], CONV_OUTPUT_ADD1_NODE, 0);
            const int outputAdd2Height = dpuGetOutputTensorHeight(task[tid], CONV_OUTPUT_ADD2_NODE, 0);
            const int outputAdd2Width = dpuGetOutputTensorWidth(task[tid], CONV_OUTPUT_ADD2_NODE, 0);
            const int outputAdd2Channel = dpuGetOutputTensorChannel(task[tid], CONV_OUTPUT_ADD2_NODE, 0);
            const float outputAdd2Scale = dpuGetOutputTensorScale(task[tid], CONV_OUTPUT_ADD2_NODE, 0);
            const int outputFixedQ = -log2(outputScale);
            const int outputAdd1FixedQ = -log2(outputAdd1Scale);
            const int outputAdd2FixedQ = -log2(outputAdd2Scale);
            const int outputMinFixedQ = std::min(std::min(outputFixedQ, outputAdd1FixedQ), outputAdd2FixedQ);
            const int outputMaxFixedQ = std::max(std::max(outputFixedQ, outputAdd1FixedQ), outputAdd2FixedQ);
            const int outputShift = outputMaxFixedQ - outputFixedQ;
            const int outputAdd1Shift = outputMaxFixedQ - outputAdd1FixedQ;
            const int outputAdd2Shift = outputMaxFixedQ - outputAdd2FixedQ;
            const int outputRshift = outputFixedQ - outputMinFixedQ;
            const int outputAdd1Rshift = outputAdd1FixedQ - outputMinFixedQ;
            const int outputAdd2Rshift = outputAdd2FixedQ - outputMinFixedQ;

#ifdef PRINT_DPU_TASK_PARAMETER
            // print shape
            cout << "Input Shape[" << tid << "] = (" << inputHeight << ", " << inputWidth << ", " << inputChannel << ")" << endl;
            cout << "Output Shape[" << tid << "] = (" << outputHeight << ", " << outputWidth << ", " << outputChannel << ")" << endl;
            cout << "Output Add1 Shape[" << tid << "] = (" << outputAdd1Height << ", " << outputAdd1Width << ", " << outputAdd1Channel << ")" << endl;
            cout << "Output Add2 Shape[" << tid << "] = (" << outputAdd2Height << ", " << outputAdd2Width << ", " << outputAdd2Channel << ")" << endl;

            // print scale
            cout << "Input Scale[" << tid << "] = " << inputScale << " (Q" << log2(inputScale) << ")" << endl;
            cout << "Output Scale[" << tid << "] = " << outputScale << " (Q" << outputFixedQ << ")" << endl;
            cout << "Output Add1 Scale[" << tid << "] = " << outputAdd1Scale << " (Q" << outputAdd1FixedQ << ")" << endl;
            cout << "Output Add2 Scale[" << tid << "] = " << outputAdd2Scale << " (Q" << outputAdd2FixedQ << ")" << endl;

            // print output shift
#ifdef USE_LOGITS_RSHIFT_FOR_U8
            cout << "Output Right Shift[" << tid << "] = " << outputRshift << endl;
            cout << "Output Add1 Right Shift[" << tid << "] = " << outputAdd1Rshift << endl;
            cout << "Output Add2 Right Shift[" << tid << "] = " << outputAdd2Rshift << endl;
#else
            cout << "Output Left Shift[" << tid << "] = " << outputShift << endl;
            cout << "Output Add1 Left Shift[" << tid << "] = " << outputAdd1Shift << endl;
            cout << "Output Add2 Left Shift[" << tid << "] = " << outputAdd2Shift << endl;
#endif

            // print size
#ifdef USE_DPU_SPLIT_IO
            cout << "Input Total Size = " << dpuGetInputTotalSize(task[tid]) << endl;
            cout << "Output Total Size = " << dpuGetOutputTotalSize(task[tid]) << endl;
#endif
#endif // PRINT_DPU_TASK_PARAMETER

            // check parameter
            assert(inputHeight == P::DPU_INPUT_HEIGHT);
            assert(inputWidth == P::DPU_INPUT_WIDTH);
            assert(inputChannel == P::DPU_INPUT_CHANNEL);
            assert(inputScale == pow(2.0, P::DPU_INPUT_FIXED_Q));
            assert(outputHeight == P::DPU_OUTPUT_HEIGHT);
            assert(outputWidth == P::DPU_OUTPUT_WIDTH);
            assert(outputChannel == P::DPU_OUTPUT_CHANNEL);
            assert(outputScale == pow(2.0, -P::DPU_OUTPUT_FIXED_Q));
            assert(outputAdd1Height == P::DPU_OUTPUT_ADD1_HEIGHT);
            assert(outputAdd1Width == P::DPU_OUTPUT_ADD1_WIDTH);
            assert(outputAdd1Channel == P::DPU_OUTPUT_CHANNEL);
            assert(outputAdd1Scale == pow(2.0, -P::DPU_OUTPUT_ADD1_FIXED_Q));
            assert(outputAdd2Height == P::DPU_OUTPUT_ADD2_HEIGHT);
            assert(outputAdd2Width == P::DPU_OUTPUT_ADD2_WIDTH);
            assert(outputAdd2Channel == P::DPU_OUTPUT_CHANNEL);
            assert(outputAdd2Scale == pow(2.0, -P::DPU_OUTPUT_ADD2_FIXED_Q));
            assert(outputShift == P::DPU_OUTPUT_SHIFT);
            assert(outputAdd1Shift == P::DPU_OUTPUT_ADD1_SHIFT);
            assert(outputAdd2Shift == P::DPU_OUTPUT_ADD2_SHIFT);
            assert(outputRshift == P::DPU_OUTPUT_RSHIFT);
            assert(outputAdd1Rshift == P::DPU_OUTPUT_ADD1_RSHIFT);
            assert(outputAdd2Rshift == P::DPU_OUTPUT_ADD2_RSHIFT);
#ifdef USE_DPU_SPLIT_IO
            assert(P::DPU_INPUT_SIZE == dpuGetInputTotalSize(task[tid]));
            assert(P::DPU_OUTPUT_TOTAL_SIZE == dpuGetOutputTotalSize(task[tid]));
#endif
        }
    }

    void initializeMemory(void) {
        for (int tid = 0; tid < num_tasks; tid++) {
            // get addr
            dpuInputAddr[tid] = dpuGetInputTensorAddress(task[tid], CONV_INPUT_NODE);
            dpuOutputAddr[tid] = dpuGetOutputTensorAddress(task[tid], CONV_OUTPUT_NODE);
            dpuOutputAdd1Addr[tid] = dpuGetOutputTensorAddress(task[tid], CONV_OUTPUT_ADD1_NODE);
            dpuOutputAdd2Addr[tid] = dpuGetOutputTensorAddress(task[tid], CONV_OUTPUT_ADD2_NODE);
#ifdef PRINT_DPU_TASK_PARAMETER
            // print addr
            cout << "DPU Input Addr[" << tid << "] = " << (uintptr_t)dpuInputAddr[tid] << endl;
            cout << "DPU Output Addr[" << tid << "] = " << (uintptr_t)dpuOutputAddr[tid] << endl;
            cout << "DPU Output_Add1 Addr[" << tid << "] = " << (uintptr_t)dpuOutputAdd1Addr[tid] << endl;
            cout << "DPU Output_Add2 Addr[" << tid << "] = " << (uintptr_t)dpuOutputAdd2Addr[tid] << endl;
#endif
            // check address offset
            assert((uintptr_t)dpuOutputAdd2Addr[tid]-(uintptr_t)dpuOutputAdd1Addr[tid] == (uintptr_t)P::DPU_OUTPUT_ADD1_SIZE_ALIGN8);
            assert((uintptr_t)dpuOutputAddr[tid]-(uintptr_t)dpuOutputAdd2Addr[tid] == (uintptr_t)P::DPU_OUTPUT_ADD2_SIZE_ALIGN8);
        }
    }

    void run(int tid) {
        assert(tid < num_tasks);
        dpuRunTask(task[tid]);
    }

#ifdef USE_DPU_SPLIT_IO
    /* Bind input/output memory buffer to Task */
    void bindIO(int tid, const dpuBufferInfo &inBufferInfo, const dpuBufferInfo &outBufferInfo) {
        assert(tid < num_tasks);
        dpuBindInputTensorBaseAddress(task[tid], inBufferInfo.addrVirt, inBufferInfo.addrPhy);
        dpuBindOutputTensorBaseAddress(task[tid], outBufferInfo.addrVirt, outBufferInfo.addrPhy);
    }
#else
    virtual int8_t *getDPUInputAddr(int tid) { assert(tid < num_tasks); return dpuInputAddr[tid]; }
    virtual int8_t *getDPUOutputAddr(int tid) { assert(tid < num_tasks); return dpuOutputAdd1Addr[tid]; }
#endif

    ~UNetDPUTasks(void) {
        // Destroy DPU Tasks and Kernels and free resources
        for (int tid = 0; tid < num_tasks; tid++) {
            dpuDestroyTask(task[tid]);
        }
        dpuDestroyKernel(kernel_conv);
    }
};

class UNetDPUManager {
  public:
    UNetDPUTasksInterface *task[NUM_NN_MODELS];

  private:
    const std::string name;
    const int num_unet_threads;
    const int num_image_buffers;
    FrameData * const frameData;
    std::thread *unet_dpu_thread;
    volatile bool is_end;
    int num_unet_instances;
    SyncChannel<int> ch_num_images;
    VCDTrace<uint8_t> cpu_id_trace;
    vector<VCDTrace<uint16_t> *> num_left_images_trace;

#ifdef USE_DPU_SPLIT_IO
    /* Handle for DPU input/output buffer */
    const int num_dpu_io_buffer;
    vector<void *> inBufferHandle;
    vector<void *> outBufferHandle;
    vector<dpuBufferInfo> inBufferInfo;
    vector<dpuBufferInfo> outBufferInfo;
#endif // USE_DPU_SPLIT_IO

#ifdef USE_DPU_GET_INPUT_PRIORITY
    SyncChannelMPSG<std::pair<unsigned int, unsigned int> > ch_input_queue; // input queue
#else
    vector<SyncChannel<std::pair<unsigned int, unsigned int> > *> ch_input_queue; // input queue
#endif
    vector<SyncChannel<unsigned int> *> ch_output_queue; // output queue
    SyncChannel<bool> ch_initialize_end;

    void initializeDPU(void) {
        // Create DPU Task
        task[UNetDPUParameterNormal::MODEL_ID] = new UNetDPUTasks<UNetDPUParameterNormal>(num_unet_threads);
        task[UNetDPUParameterCutTopQuarter::MODEL_ID] = new UNetDPUTasks<UNetDPUParameterCutTopQuarter>(num_unet_threads);

#ifdef USE_DPU_SPLIT_IO
        // allocate buffer for split_io
        for (int img_idx = 0; img_idx < num_image_buffers; img_idx++) {
            if (img_idx < num_dpu_io_buffer) {
                inBufferInfo[img_idx].size = UNetDPUParameterNormal::DPU_INPUT_SIZE;
                outBufferInfo[img_idx].size = UNetDPUParameterNormal::DPU_OUTPUT_TOTAL_SIZE;
                inBufferHandle[img_idx] = dpuAllocMem(inBufferInfo[img_idx].size,
                                                        inBufferInfo[img_idx].addrVirt, inBufferInfo[img_idx].addrPhy);
                outBufferHandle[img_idx] = dpuAllocMem(outBufferInfo[img_idx].size,
                                                         outBufferInfo[img_idx].addrVirt, outBufferInfo[img_idx].addrPhy);
            }
            frameData[img_idx].dpu_input = inBufferInfo[img_idx % num_dpu_io_buffer].addrVirt;
            frameData[img_idx].dpu_output = outBufferInfo[img_idx % num_dpu_io_buffer].addrVirt;
        }
#endif // USE_DPU_SPLIT_IO

        // set task memorya address
        for (int i = 0; i < NUM_NN_MODELS; i++) {
            task[i]->initializeMemory();
#ifdef USE_DPU_SPLIT_IO
#if defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER)
            for (int tid = 0; tid < num_unet_threads; tid++) {
                task[i]->bindIO(tid, inBufferInfo[tid], outBufferInfo[tid]);
            }
#endif
#endif
        }

        // notify initialization end
        ch_initialize_end.put();
    }

    void finalizeDPU(void) {
        // Destroy DPU Tasks and Kernels and free resources
        for (int i = 0; i < NUM_NN_MODELS; i++) {
            delete task[i];
        }

#ifdef USE_DPU_SPLIT_IO
        /* Free input/output memory buffers */
        for (int buf_idx = 0; buf_idx < num_dpu_io_buffer; buf_idx++) {
            dpuFreeMem(inBufferHandle[buf_idx]);
            dpuFreeMem(outBufferHandle[buf_idx]);
        }
#endif
    }

    void UNetDPUThread(void) {
        MeasureTimeThreadData::set_name(get_name());

        _T1(initializeDPU, initializeDPU());

        _T1(runSegmentationDPU, runSegmentation());

        _T1(finalizeDPU, finalizeDPU());
    }

#if defined(USE_DPU_SPLIT_IO) && !(defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER))
    template<typename P>
    void dpuBindIO(unsigned int id, unsigned int img_idx) {
        /* Bind input/output memory buffer to Task */
        task[P::MODEL_ID]->bindIO(id, inBufferInfo[img_idx % num_dpu_io_buffer], outBufferInfo[img_idx % num_dpu_io_buffer]);
    }
#endif

    template<typename P>
    void dpuSetInput(unsigned int id, unsigned int img_idx) {
        // Set image into CONV Task
#ifdef USE_DPU_SPLIT_IO
        dpuSyncMemToDev(inBufferHandle[img_idx % num_dpu_io_buffer], 0, P::DPU_INPUT_SIZE);
#else
#if defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER)
        // no need memcpy
#else
        memcpy(task[P::MODEL_ID]->getDPUInputAddr(id), frameData[img_idx].dpu_input, P::DPU_INPUT_SIZE);
#endif
#endif
    }

    template<typename P>
    void dpuGetOutput(unsigned int id, unsigned int img_idx) {
        // get output
#ifdef USE_DPU_SPLIT_IO
        dpuSyncDevToMem(outBufferHandle[img_idx % num_dpu_io_buffer], 0, P::DPU_OUTPUT_TOTAL_SIZE);
#else
#if defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER)
        // no need memcpy
#else
        memcpy(frameData[img_idx].dpu_output, task[P::MODEL_ID]->getDPUOutputAddr(id), P::DPU_OUTPUT_TOTAL_SIZE);
#endif
#endif
    }

    /**
     * @brief entry routine of segmentation, and put image into write queue
     *
     * @return none
     */
    void runSegmentation(void) {
        // Run detection for images in preprocess queue
        vector<int> num_left_images(num_unet_threads);
        while (true) {
            int num_images = ch_num_images.get();
            if (num_images == -1)
                break;
            for (int id = 0; id < num_unet_threads; id++) {
                num_left_images[id] = (num_images/num_unet_threads) + (id <= (num_images%num_unet_threads - 1) ? 1 : 0);
                if (OUTPUT_EXTRA_VCD_TRACE) num_left_images_trace[id]->add(num_left_images[id]);
            }
            for (int i = 0; i < num_images; i++) {
                // Get an image from preprocess queue
#ifdef USE_DPU_GET_INPUT_PRIORITY
                // use num_left_images as priority
                int id;
                std::pair<unsigned int, unsigned int> v = ch_input_queue.get(num_left_images, id);
#else
                // round robin
                int id = i%num_unet_threads;
                std::pair<unsigned int, unsigned int> v = ch_input_queue[id]->get();
#endif

                --num_left_images[id];
                unsigned int img_idx = v.first;
                unsigned int model_id = v.second;
                assert(img_idx != IMG_IDX_INVALID);

                if (OUTPUT_EXTRA_VCD_TRACE) cpu_id_trace.add(sched_getcpu());

                // Run CONV Task on DPU
#ifdef PC_VER
                dpuRunTask_img_idx_offset = img_idx;
#endif
                _T1(dpuRunTask, task[model_id]->run(id));

                // update stat
                stat.num_processed++;
                stat.model_select_count[model_id]++;

                // Put image into segout queue
                ch_output_queue[id]->put(img_idx);

                if (OUTPUT_EXTRA_VCD_TRACE) num_left_images_trace[id]->add(num_left_images[id]);
            }
            // check num_left_images all 0
            for (int tid = 0; tid < num_unet_threads; tid++) {
                assert(num_left_images[tid] == 0);
            }
        }
    }

  public:
    struct Stat {
        int num_processed;
        vector<int> model_select_count;
        Stat(void) : num_processed(0), model_select_count(NUM_NN_MODELS, 0) {}
    } stat;

    UNetDPUManager(std::string name, int num_unet_threads, int cpu_id,
                   int num_image_buffers, FrameData *frameData)
        : name(name), num_unet_threads(num_unet_threads),
          num_image_buffers(num_image_buffers), frameData(frameData),
          unet_dpu_thread(nullptr), is_end(false), num_unet_instances(0),
          cpu_id_trace(name + ".cpu_id", sched_getcpu()),
          num_left_images_trace(num_unet_threads, nullptr),
#ifdef USE_DPU_SPLIT_IO
#if defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER)
          num_dpu_io_buffer(num_unet_threads),
#else
          num_dpu_io_buffer(num_image_buffers),
#endif
          inBufferHandle(num_dpu_io_buffer), outBufferHandle(num_dpu_io_buffer), inBufferInfo(num_dpu_io_buffer), outBufferInfo(num_dpu_io_buffer),
#endif
          ch_input_queue(num_unet_threads), ch_output_queue(num_unet_threads)
    {
        for (int i = 0; i < num_unet_threads; i++) {
#ifndef USE_DPU_GET_INPUT_PRIORITY
            ch_input_queue[i] = new SyncChannel<std::pair<unsigned int, unsigned int> >(1);
#endif
            ch_output_queue[i] = new SyncChannel<unsigned int>(1);
            if (OUTPUT_EXTRA_VCD_TRACE) {
                ostringstream oss; oss << name << ".num_left_images_" << i;
                num_left_images_trace[i] = new VCDTrace<uint16_t>(oss.str(), 0);
            }
        }
        start(cpu_id);
    }

    ~UNetDPUManager(void) {
        stop();
        for (int i = 0; i < num_unet_threads; i++) {
#ifndef USE_DPU_GET_INPUT_PRIORITY
            delete ch_input_queue[i];
#endif
            delete ch_output_queue[i];
        }
    }

    UNetDPUManager(const UNetDPUManager&) = delete;
    UNetDPUManager& operator=(const UNetDPUManager&) = delete;
    UNetDPUManager(UNetDPUManager&&) = delete;
    UNetDPUManager& operator=(UNetDPUManager&&) = delete;

    const string &get_name(void) const { return name; }

    void start(int cpu_id = -1) {
        assert(unet_dpu_thread == nullptr);
        unet_dpu_thread = new std::thread(&UNetDPUManager::UNetDPUThread, this);
        if (cpu_id != -1) {
            set_thread_affinity(unet_dpu_thread->native_handle(), cpu_id);
        }
        set_thread_schedparam(unet_dpu_thread->native_handle(), SCHED_FIFO, sched_get_priority_max(SCHED_FIFO));  // high priority

        // wait until initialization end
        ch_initialize_end.get();
    }

    void set_num_images(unsigned int num_images) {
        ch_num_images.put(num_images);
    }

    void stop(void) {
        ch_num_images.put(-1);
        unet_dpu_thread->join();
        delete unet_dpu_thread;
        unet_dpu_thread = nullptr;
        if (OUTPUT_EXTRA_VCD_TRACE) {
            MeasureTime::add_trace(cpu_id_trace);
            for (int i = 0; i < num_unet_threads; i++) {
                MeasureTime::add_trace(*num_left_images_trace[i]);
                delete num_left_images_trace[i];
            }
        }
    }

    unsigned int allocate(void) {
        return num_unet_instances++;
    }

    template<typename P>
    void put_input(unsigned int id, unsigned int img_idx) {
#if defined(USE_DPU_SPLIT_IO) && !(defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER))
        // Bind Input/Output Buffer to Task
        _T1(dpuBindIO, dpuBindIO<P>(id, img_idx));
#endif
        // Set image into CONV Task
        _T1(dpuSetInput, dpuSetInput<P>(id, img_idx));
#ifdef USE_DPU_GET_INPUT_PRIORITY
        ch_input_queue.put(id, {img_idx, (unsigned int)P::MODEL_ID});
#else
        ch_input_queue[id]->put({img_idx, (unsigned int)P::MODEL_ID});
#endif
    }

    template<typename P>
    unsigned int get_output(unsigned int id) {
        unsigned int img_idx = ch_output_queue[id]->get();
        // get output
        _T1(dpuGetOutput, dpuGetOutput<P>(id, img_idx));
        return img_idx;
    }

    template<typename P>
    bool get_output_nb(unsigned int id, unsigned int &img_idx) {
        if (ch_output_queue[id]->empty())
            return false;
        img_idx = get_output<P>(id);
        return true;
    }

    const Stat &get_stat(void) const {
        return stat;
    }
};

class UNetCalcInterface {
  public:
    virtual void Preprocess(RowDecoderInterface<uint8_t> &input, FrameData *frame, int in_height, int in_width, int in_channels, JudgeCutTop<JUDGE_CUT_TOP_COLOR_DIV_N_LOG2> *jct) = 0;
#if defined(BLOCKING_DPU_SEGMENTATION) || defined(USE_THREAD_BARRIER)
    virtual void runSegmentation(unsigned int unet_id, unsigned int img_idx) = 0;
#else
    virtual void startSegmentation(unsigned int unet_id, unsigned int img_idx) = 0;
    virtual bool checkEndSegmentation(unsigned int unet_id, unsigned int &img_idx) = 0;
    virtual void waitSegmentation(unsigned int unet_id, unsigned int &img_idx) = 0;
#endif
    virtual size_t Postprocess(FrameData *frame) = 0;
    virtual unsigned int getLabelImageStartY(void) = 0;
    virtual ~UNetCalcInterface() {}
};

template<typename UNET_DPU_PARAM_T>
class UNetCalc : public UNetCalcInterface {
  public:
    typedef UNET_DPU_PARAM_T P;

  private:
    UNetDPUManager * const unet_dpu_manager;
    const unsigned int unet_id;

    Resize<uint8_t, 3
#ifdef USE_INPUT_RESIZE_BILINEAR
           , cv::INTER_LINEAR
#else
           , cv::INTER_NEAREST
#endif
#if !defined(USE_OPT_RESIZE_INPUT)
           , 1  // USE_OPENCV
#else
           , 0
#endif
           > rb_input;

    ResizeBilinear<
#ifdef USE_LOGITS_RSHIFT_FOR_U8
                   uint8_t
#else
                   uint16_t
#endif
                   , P::DPU_OUTPUT_CHANNEL
#if !defined(USE_OPT_RESIZE_OUTPUT_ADD)
                   , 1  // USE_OPENCV
#endif
                   > rb_logits_add1;

    ResizeBilinear<
#ifdef USE_LOGITS_RSHIFT_FOR_U8
                    uint8_t
#else
                    uint16_t
#endif
                   , P::DPU_OUTPUT_CHANNEL
#if !defined(USE_OPT_RESIZE_OUTPUT_ADD)
                   , 1  // USE_OPENCV
#endif
                   > rb_logits_add;

#ifdef NARROW_LOGITS_TO_U8
#define UPSAMPLE_ARGMAX_INPUT_TYPE uint8_t
#else
#define UPSAMPLE_ARGMAX_INPUT_TYPE uint16_t
#endif
#ifdef USE_OUTPUT_RESIZE_BILINEAR
#define UPSAMPLE_ARGMAX_INTER_POLATION cv::INTER_LINEAR
#else
#define UPSAMPLE_ARGMAX_INTER_POLATION cv::INTER_NEAREST
#endif
#ifdef USE_OPT_RESIZE_OUTPUT
static const int UPSAMPLE_ARGMAX_OPENCV = 0;
#else
static const int UPSAMPLE_ARGMAX_OPENCV = 1;
#endif
#ifndef UPSAMPLE_ARGMAX_LSHIFT
static const int UPSAMPLE_ARGMAX_LSHIFT = 0;
#endif
#ifdef USE_BILINER_MERGED_ARGMAX
static const int UPSAMPLE_ARGMAX_MERGEOP = 1;
#else
static const int UPSAMPLE_ARGMAX_MERGEOP = 0;
#endif
#ifdef USE_ARGMAX_RUN_LENGTH_OUTPUT
#define UPSAMPLE_ARGMAX_RUN_LENGTH_OUTPUT true
#else
#define UPSAMPLE_ARGMAX_RUN_LENGTH_OUTPUT false
#endif
    UpsampleArgmax<UPSAMPLE_ARGMAX_INPUT_TYPE, P::DPU_OUTPUT_CHANNEL, UPSAMPLE_ARGMAX_INTER_POLATION, UPSAMPLE_ARGMAX_OPENCV, UPSAMPLE_ARGMAX_MERGEOP> ua;

    template<int CH>
    void transpose_u8_cv(uint8_t *input, uint8_t *output, int height, int width) {
        cv::Mat in(cv::Size(width, height), CV_MAKE_TYPE(CV_8U, CH), input);
        cv::Mat out(cv::Size(height, width), CV_MAKE_TYPE(CV_8U, CH), output);
        cv::transpose(in, out);
    }

    template<int CH, typename T>
    void calc_row_all_same_class(const T *data, int rows, int cols, uint8_t *argmax, int *output) {
        Argmax<T, CH> am;
        am(data, argmax, rows*cols);
        for (int i = 0; i < rows; i++) {
            bool all_same = true;
            uint8_t *row = &argmax[i*cols];
            for (int j = 1; j < cols; j++) {
                if (row[0] != row[j]) {
                    all_same = false;
                    break;
                }
            }
            output[i] = (all_same ? (int)row[0] : -1);
        }
    }

    template<int CH>
    void calc_row_all_same_class(const cv::Mat &data, uint8_t *argmax, int *output) {
        if (data.type() == CV_MAKETYPE(CV_8U, CH)) {
            calc_row_all_same_class<CH>((const uint8_t *)data.data, data.rows, data.cols, argmax, output);
        }
        else if (data.type() == CV_MAKETYPE(CV_16U, CH)) {
            calc_row_all_same_class<CH>((const uint16_t *)data.data, data.rows, data.cols, argmax, output);
        }
        else {
            assert(false);
        }
    }

    template<typename T, int SRC_HEIGHT, int SRC_WIDTH, int NUM_CH>
    void transpose_c3(const T *src, T *dst) {
        static_assert(NUM_CH == 3, "NUM_CH == 3");
        static const int TGT_HEIGHT = SRC_WIDTH;
        static const int TGT_WIDTH = SRC_HEIGHT;
        const T (&s)[SRC_HEIGHT][SRC_WIDTH][NUM_CH] = reinterpret_cast<const T (&)[SRC_HEIGHT][SRC_WIDTH][NUM_CH]>(*src);
        T (&d)[TGT_HEIGHT][TGT_WIDTH][NUM_CH] = reinterpret_cast<T (&)[TGT_HEIGHT][TGT_WIDTH][NUM_CH]>(*dst);
        for (int y = 0; y < SRC_HEIGHT; y++) {
            for (int x = 0; x < SRC_WIDTH; x++) {
                const T *s0 = s[y][x];
                T *d0 = d[x][y];
                d0[0] = s0[0];
                d0[1] = s0[1];
                d0[2] = s0[2];
            }
        }
    }

    void setImageWithShift(const uint8_t *imageData, int8_t *output) {
        // convert uint to fixed value
        static uint8_t overflow_th = 255 - P::DPU_INPUT_ADD_FOR_ROUND;
        static uint8_t max_val = 127;
        if (P::DPU_TRANSPOSE_HW) {
            int i = 0;
            for (int y = 0; y < P::NN_INPUT_HEIGHT; y++) {
                for (int x = 0; x < P::NN_INPUT_WIDTH; x++) {
                    int tr_idx0 = x*P::DPU_INPUT_WIDTH*P::DPU_INPUT_CHANNEL + y*P::DPU_INPUT_CHANNEL;
                    uint8_t val0 = imageData[i+0];
                    uint8_t val1 = imageData[i+1];
                    uint8_t val2 = imageData[i+2];
                    output[tr_idx0+0] = (val0 > overflow_th ? max_val : ((val0+(uint8_t)P::DPU_INPUT_ADD_FOR_ROUND)>>P::DPU_INPUT_SHIFT));
                    output[tr_idx0+1] = (val1 > overflow_th ? max_val : ((val1+(uint8_t)P::DPU_INPUT_ADD_FOR_ROUND)>>P::DPU_INPUT_SHIFT));
                    output[tr_idx0+2] = (val2 > overflow_th ? max_val : ((val2+(uint8_t)P::DPU_INPUT_ADD_FOR_ROUND)>>P::DPU_INPUT_SHIFT));
                    i+=3;
                }
            }
        }
        else {
            assert(P::DPU_INPUT_SIZE % 48 == 0);
            const uint8_t *in_ptr = imageData;
            int8_t *out_ptr = output;
            for (int i = 0; i < P::DPU_INPUT_SIZE; i+=48) {
#if 0 /* no neon code */
                for (int j = 0; j < 48; j+=3) {
                    uint8_t val0 = in_ptr[0];
                    uint8_t val1 = in_ptr[1];
                    uint8_t val2 = in_ptr[2];
                    out_ptr[0] = (val0 > overflow_th ? max_val : ((val0+(uint8_t)P::DPU_INPUT_ADD_FOR_ROUND)>>P::DPU_INPUT_SHIFT));
                    out_ptr[1] = (val1 > overflow_th ? max_val : ((val1+(uint8_t)P::DPU_INPUT_ADD_FOR_ROUND)>>P::DPU_INPUT_SHIFT));
                    out_ptr[2] = (val2 > overflow_th ? max_val : ((val2+(uint8_t)P::DPU_INPUT_ADD_FOR_ROUND)>>P::DPU_INPUT_SHIFT));
                    out_ptr += 3;
                    in_ptr += 3;
                }
#else /* neon code */
                uint8x16x3_t val = vld3q_u8(in_ptr);
                val.val[0] = vshrq_n_u8(vqaddq_u8(val.val[0], vdupq_n_u8(P::DPU_INPUT_ADD_FOR_ROUND)), P::DPU_INPUT_SHIFT);
                val.val[1] = vshrq_n_u8(vqaddq_u8(val.val[1], vdupq_n_u8(P::DPU_INPUT_ADD_FOR_ROUND)), P::DPU_INPUT_SHIFT);
                val.val[2] = vshrq_n_u8(vqaddq_u8(val.val[2], vdupq_n_u8(P::DPU_INPUT_ADD_FOR_ROUND)), P::DPU_INPUT_SHIFT);
                vst3q_u8((uint8_t *)out_ptr, val);
                out_ptr += 48;
                in_ptr += 48;
#endif
            }
        }
    }

    template<int LSHIFT, int SIZE, int OFFSET=128>
    void vec_i8_to_u16(const int8_t *src, uint16_t *dst) {
        static const int SIZE0 = (SIZE/8)*8;
        int16_t *dst_s16 = reinterpret_cast<int16_t *>(dst);
        int16x8_t voffset = vdupq_n_s16(OFFSET<<LSHIFT);
        for (int i = 0; i < SIZE0; i+=8) {
            // dst[i] = (int16_t)src[i]<<LSHIFT + (OFFSET<<LSHIFT)
            vst1q_s16(&dst_s16[i], vaddq_s16(vshll_n_s8(vld1_s8(&src[i]), LSHIFT), voffset));
        }
        for (int i = SIZE0; i < SIZE; i++) {
            uint16_t a = src[i];
            a = (a+OFFSET)<<LSHIFT;
            dst[i] = a;
        }
    }

    template<int RSHIFT, int SIZE, int OFFSET=128>
    void vec_i8_to_u8(const int8_t *src, uint8_t *dst) {
        static const int SIZE0 = (SIZE/16)*16;
        const uint8_t *src_u8 = reinterpret_cast<const uint8_t *>(src);
        {
            uint8x16_t voffset = vdupq_n_u8(OFFSET);
            for (int i = 0; i < SIZE0; i+=16) {
                // dst[i] = min(255, (uint8_t)(src[i]+OFFSET)+(1<<(RSHIFT-1))>>RSHIFT)
                uint8x16_t aval = vaddq_u8(vld1q_u8(&src_u8[i]), voffset);
                if (RSHIFT > 0) {
                    aval = vrshrq_n_u8(aval, RSHIFT);
                }
                vst1q_u8(&dst[i], aval);
            }
        }
        if (SIZE - SIZE0 == 8) {
            uint8x8_t voffset = vdup_n_u8(OFFSET);
            // dst[i] = min(255, (uint8_t)(src[i]+OFFSET)+(1<<(RSHIFT-1))>>RSHIFT)
            uint8x8_t aval = vadd_u8(vld1_u8(&src_u8[SIZE0]), voffset);
            if (RSHIFT > 0) {
                aval = vrshr_n_u8(aval, RSHIFT);
            }
            vst1_u8(&dst[SIZE0], aval);
        }
        else {
            for (int i = SIZE0; i < SIZE; i++) {
                uint8_t a = src[i];
                a += OFFSET;
                if (RSHIFT > 0) {
                    static const int ROUND_ADD = (RSHIFT == 0 ? 0 : (1<<(RSHIFT-1)));
                    a = std::min(255, (a+ROUND_ADD)>>RSHIFT);
                }
                dst[i] = a;
            }
        }
    }

    template<int SIZE>
    void vec_add_u16(const uint16_t *src, uint16_t *dst) {
        static const int SIZE0 = (SIZE/8)*8;
        for (int i = 0; i < SIZE0; i+=8) {
            // dst[i] += src[i]
            vst1q_u16(&dst[i], vaddq_u16(vld1q_u16(&dst[i]), vld1q_u16(&src[i])));
        }
        for (int i = SIZE0; i < SIZE; i++) {
            dst[i] += src[i];
        }
    }

    template<int LSHIFT, int SIZE, int OFFSET=128>
    void vec_add_i8_u16(const int8_t *src, uint16_t *dst) {
        static const int SIZE0 = (SIZE/8)*8;
        int16_t *dst_s16 = reinterpret_cast<int16_t *>(dst);
        int16x8_t voffset = vdupq_n_s16(OFFSET<<LSHIFT);
        for (int i = 0; i < SIZE0; i+=8) {
            // dst[i] += (uint16_t)(src[i]+OFFSET)<<LSHIFT
            int16x8_t src_u16 = vaddq_s16(vshll_n_s8(vld1_s8(&src[i]), LSHIFT), voffset);
            vst1q_s16(&dst_s16[i], vaddq_s16(vld1q_s16(&dst_s16[i]), src_u16));
        }
        for (int i = SIZE0; i < SIZE; i++) {
            uint16_t a = src[i];
            a = (a+OFFSET)<<LSHIFT;
            uint16_t b = dst[i] + a;
            dst[i] = b;
        }
    }

    template<int RSHIFT, int SIZE, int OFFSET=128>
    void vec_add_i8_u8(const int8_t *src, uint8_t *dst) {
        static const int SIZE0 = (SIZE/16)*16;
        const uint8_t *src_u8 = reinterpret_cast<const uint8_t *>(src);
        uint8x16_t voffset = vdupq_n_u8(OFFSET);
        for (int i = 0; i < SIZE0; i+=16) {
            // aval = min(255, (uint8_t)(src[i]+OFFSET)+(1<<(RSHIFT-1))>>RSHIFT)
            uint8x16_t aval = vaddq_u8(vld1q_u8(&src_u8[i]), voffset);
            if (RSHIFT > 0) {
                aval = vrshrq_n_u8(aval, RSHIFT);
            }
            // dst[i] = (dst[i]+aval+1)>>1
            vst1q_u8(&dst[i], vrhaddq_u8(vld1q_u8(&dst[i]), aval));
        }
        for (int i = SIZE0; i < SIZE; i++) {
            uint8_t a = src[i];
            a += OFFSET;
            if (RSHIFT > 0) {
                static const int ROUND_ADD = (RSHIFT == 0 ? 0 : (1<<(RSHIFT-1)));
                a = std::min(255, (a+ROUND_ADD)>>RSHIFT);
            }
            uint8_t b = ((unsigned int)dst[i] + a + 1)>>1;
            dst[i] = b;
        }
    }

    template<int SRC_HEIGHT, int SRC_WIDTH, int NUM_CH>
    void transpose_u8_c6(const uint8_t *src, uint8_t *dst) {
        static_assert(NUM_CH == 6, "NUM_CH == 6");
        assert((uintptr_t)src % 2 == 0);  // check 2byte (uint16_t) align
        assert((uintptr_t)dst % 2 == 0);  // check 2byte (uint16_t) align
        transpose_c3<uint16_t, SRC_HEIGHT, SRC_WIDTH, NUM_CH/2>(reinterpret_cast<const uint16_t*>(src), reinterpret_cast<uint16_t*>(dst));
    }

    template<int SRC_HEIGHT, int SRC_WIDTH, int NUM_CH>
    void transpose_u16_c6(const uint16_t *src, uint16_t *dst) {
        static_assert(NUM_CH == 6, "NUM_CH == 6");
        assert((uintptr_t)src % 4 == 0);  // check 4byte (uint32_t) align
        assert((uintptr_t)dst % 4 == 0);  // check 4byte (uint32_t) align
        transpose_c3<uint32_t, SRC_HEIGHT, SRC_WIDTH, NUM_CH/2>(reinterpret_cast<const uint32_t*>(src), reinterpret_cast<uint32_t*>(dst));
    }

  public:
    UNetCalc(UNetDPUManager *unet_dpu_manager, int unet_id) :
        unet_dpu_manager(unet_dpu_manager),
        unet_id(unet_id),
        rb_input(P::SCALED_VALID_IMAGE_HEIGHT2, SCALED_ORIG_IMAGE_WIDTH, P::NN_INPUT_HEIGHT, P::NN_INPUT_WIDTH
#if defined(USE_INPUT_RESIZE_BILINEAR) && defined(USE_OPT_RESIZE_INPUT)
                 , ::INPUT_RESIZE_NEAREST_NEIGHBOR_THRESHOLD_Y, ::INPUT_RESIZE_NEAREST_NEIGHBOR_THRESHOLD_X
#endif
            ),
        rb_logits_add1(P::DPU_OUTPUT_ADD1_HEIGHT, P::DPU_OUTPUT_ADD1_WIDTH, P::DPU_OUTPUT_ADD2_HEIGHT, P::DPU_OUTPUT_ADD2_WIDTH),
        rb_logits_add(P::DPU_OUTPUT_ADD2_HEIGHT, P::DPU_OUTPUT_ADD2_WIDTH, P::DPU_OUTPUT_HEIGHT, P::DPU_OUTPUT_WIDTH),
        ua(P::NN_OUTPUT_HEIGHT, P::NN_OUTPUT_WIDTH, P::VALID_IMAGE_HEIGHT2, ORIG_IMAGE_WIDTH)
    {
    }

    void Preprocess(RowDecoderInterface<uint8_t> &input, FrameData *frame, int in_height, int in_width, int in_channels, JudgeCutTop<JUDGE_CUT_TOP_COLOR_DIV_N_LOG2> *jct)
    {
        static_assert(P::DPU_INPUT_CHANNEL == 3, "input must be RGB image");
        assert(in_channels == 3);

#if !defined(USE_DPU_SPLIT_IO) && defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER)
        int8_t *dpu_input = unet_dpu_manager->task[P::MODEL_ID]->getDPUInputAddr(unet_id); // write to dpu input directly
#else
        int8_t *dpu_input = frame->dpu_input;
#endif

        // resize
        if (in_height == P::NN_INPUT_HEIGHT && in_width == P::NN_INPUT_WIDTH) {  // same as NN input (for Debug)
            ROW_DECODE_JPEG_UNSUPPORTED();
            assert(!jct);  // not implemented
            // convert uint to fixed value
            _T1(setImageWithShift, setImageWithShift(frame->input_image, dpu_input));
        } else {
            assert(in_height == SCALED_ORIG_IMAGE_HEIGHT && in_width == SCALED_ORIG_IMAGE_WIDTH);
            RowDecoderOffsetYWrapper<uint8_t, P::SCALED_VALID_IMAGE_STARTY2> row_decoder(input);
#if !defined(USE_OPT_RESIZE_INPUT) || !defined(USE_INPUT_RESIZE_BILINEAR) || defined(USE_INPUT_RESIZE_BILINEAR_TF)
            ROW_DECODE_JPEG_UNSUPPORTED_S();
            assert(!jct);  // not implemented
            uint8_t *input_image = &frame->input_image[P::SCALED_VALID_IMAGE_STARTY2*in_width*in_channels];
            uint8_t resized_image[P::DPU_INPUT_SIZE];
#ifdef USE_INPUT_RESIZE_BILINEAR_TF
            cv::Mat image_crop(P::SCALED_VALID_IMAGE_HEIGHT2, SCALED_ORIG_IMAGE_WIDTH, CV_MAKETYPE(CV_8U, P::DPU_INPUT_CHANNEL), input_image);
            float *tmp_buf0 = new float[image_crop.rows*image_crop.cols*image_crop.channels()];
            float *tmp_buf1 = new float[P::DPU_INPUT_SIZE];
            for (int i = 0; i < image_crop.rows*image_crop.cols*image_crop.channels(); i++) {
                tmp_buf0[i] = ((uint8_t*)image_crop.data)[i];
            }
            ResizeBilinearTF(tmp_buf0,
                             1, image_crop.rows,
                             image_crop.cols, P::NN_INPUT_HEIGHT,
                             P::NN_INPUT_WIDTH, P::DPU_INPUT_CHANNEL,
                             tmp_buf1);
            for (int i = 0; i < P::DPU_INPUT_SIZE; i++) {
                resized_image[i] = (uint8_t)(std::max(0.0f, std::min(tmp_buf1[i], 254.0f)));
            }
            delete [] tmp_buf0;
            delete [] tmp_buf1;
#else
            _T1(rb_input, rb_input(input_image, (uint8_t *)resized_image));
#endif
            _T1(setImageWithShift, setImageWithShift(resized_image, dpu_input));
#else
#ifdef USE_INPUT_BILINEAR_RSHIFT
            uint8_t *resize_out;
#ifdef USE_BILINER_MERGED_TRANSPOSE
            static const bool TRANS = P::DPU_TRANSPOSE_HW;
            resize_out = (uint8_t *)dpu_input;
#else // USE_BILINER_MERGED_TRANSPOSE
#ifdef USE_ROW_DECODE_JPEG
            uint8_t resized_image[P::DPU_INPUT_SIZE];
#endif
            static const bool TRANS = false;
            resize_out = (P::DPU_TRANSPOSE_HW ?
#ifdef USE_ROW_DECODE_JPEG
                          resized_image :
#else
                          (uint8_t *)frame->input_image :
#endif
                          (uint8_t *)dpu_input);
#endif // USE_BILINER_MERGED_TRANSPOSE
            _T1(rb_input, (rb_input.template operator()<0, P::DPU_INPUT_SHIFT, TRANS, P::NN_INPUT_HEIGHT, JudgeCutTop<JUDGE_CUT_TOP_COLOR_DIV_N_LOG2> >(row_decoder, resize_out, jct)));
#ifdef USE_BILINER_MERGED_TRANSPOSE
            // do nothing
#else // USE_BILINER_MERGED_TRANSPOSE
            if (P::DPU_TRANSPOSE_HW && (!jct || !jct->get_last_judge())) {
                _T1(transpose_input, transpose_u8_cv<P::DPU_INPUT_CHANNEL>(resize_out, (uint8_t *)dpu_input, P::NN_INPUT_HEIGHT, P::NN_INPUT_WIDTH));
            }
#endif // USE_BILINER_MERGED_TRANSPOSE
#else // USE_INPUT_BILINEAR_RSHIFT
            assert(!jct);  // not implemented
            uint8_t resized_image[P::DPU_INPUT_SIZE];
            _T1(rb_input, rb_input(row_decoder, (uint8_t *)resized_image));
            _T1(setImageWithShift, setImageWithShift(resized_image, dpu_input));
#endif
#endif
        }
    }

#if defined(BLOCKING_DPU_SEGMENTATION) || defined(USE_THREAD_BARRIER)
    void runSegmentation(unsigned int unet_id, unsigned int img_idx) {
        unet_dpu_manager->put_input<P>(unet_id, img_idx);
        unsigned int out = unet_dpu_manager->get_output<P>(unet_id);
        assert(out == img_idx);
    }
#else
    void startSegmentation(unsigned int unet_id, unsigned int img_idx) {
        unet_dpu_manager->put_input<P>(unet_id, img_idx);
    }
    bool checkEndSegmentation(unsigned int unet_id, unsigned int &img_idx) {
        return unet_dpu_manager->get_output_nb<P>(unet_id, img_idx);
    }
    void waitSegmentation(unsigned int unet_id, unsigned int &img_idx) {
        img_idx = unet_dpu_manager->get_output<P>(unet_id);
    }
#endif

    size_t Postprocess(FrameData *frame) {
        // Run postprocess for images in segout queue
#ifdef USE_ROW_ALL_SAME_CLASS
        int row_all_same_class[P::NN_OUTPUT_HEIGHT];
        uint8_t argmax[P::DPU_OUTPUT_HEIGHT*P::DPU_OUTPUT_WIDTH];
#else
        int *row_all_same_class = nullptr;
#endif

#if !defined(USE_DPU_SPLIT_IO) && defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER)
        int8_t *dpu_output_add1 = unet_dpu_manager->task[P::MODEL_ID]->getDPUOutputAddr(unet_id); // read from dpu output directly
#else
        int8_t *dpu_output_add1 = frame->dpu_output;
#endif
        int8_t *dpu_output_add2 = dpu_output_add1 + P::DPU_OUTPUT_ADD1_SIZE_ALIGN8;
        int8_t *dpu_output = dpu_output_add2 + P::DPU_OUTPUT_ADD2_SIZE_ALIGN8;

#ifdef USE_LOGITS_RSHIFT_FOR_U8
        uint8_t *logitsAdd1_u8 = frame->logitsAdd1_u8;
        uint8_t *logitsAdd_u8 = frame->logitsAdd_u8;
        uint8_t *logitsOut_u8 = frame->logitsOut_u8;

        // logits_add1 = round_saturate_rshift_u8(logits_add1+128, rshift);
        _T1(logitsAdd1_i8_to_u8, (vec_i8_to_u8<P::DPU_OUTPUT_ADD1_RSHIFT, P::DPU_OUTPUT_ADD1_SIZE>(dpu_output_add1, logitsAdd1_u8)));

        // logits_add = (resize(logits_add1) + round_saturate_rshift_u8(logits_add1+128, rshift)+1)>>1
        _T1(rb_logits_add1, rb_logits_add1(logitsAdd1_u8, logitsAdd_u8));
        _T1(logitsAdd_add, (vec_add_i8_u8<P::DPU_OUTPUT_ADD2_RSHIFT, P::DPU_OUTPUT_ADD2_SIZE>(dpu_output_add2, logitsAdd_u8)));

        // logits_out = (resize(logits_add) + round_saturate_rshift_u8(logits+128, rshift)+1)>>1
        _T1(rb_logits_add, rb_logits_add(logitsAdd_u8, logitsOut_u8));
        _T1(logitsOut_add, (vec_add_i8_u8<P::DPU_OUTPUT_RSHIFT, P::DPU_OUTPUT_SIZE>(dpu_output, logitsOut_u8)));

        cv::Mat logitsOutMat(P::DPU_OUTPUT_HEIGHT, P::DPU_OUTPUT_WIDTH, CV_MAKETYPE(CV_8U, P::DPU_OUTPUT_CHANNEL), logitsOut_u8);
#else // USE_LOGITS_RSHIFT_FOR_U8
        uint16_t *logitsAdd1_u16 = frame->logitsAdd1_u16;
        uint16_t *logitsAdd_u16 = frame->logitsAdd_u16;
        uint16_t *logitsOut_u16 = frame->logitsOut_u16;

        // logits_add1 = (uint16_t)(logits_add1+128)<<shift;
        _T1(logitsAdd1_i8_to_i16, (vec_i8_to_u16<P::DPU_OUTPUT_ADD1_SHIFT, P::DPU_OUTPUT_ADD1_SIZE>(dpu_output_add1, logitsAdd1_u16)));

        // logits_add = resize(logits_add1) + (uint16_t)(logits+128)<<shift
        _T1(rb_logits_add1, rb_logits_add1(logitsAdd1_u16, logitsAdd_u16));
        _T1(logitsAdd_add, (vec_add_i8_u16<P::DPU_OUTPUT_ADD2_SHIFT, P::DPU_OUTPUT_ADD2_SIZE>(dpu_output_add2, logitsAdd_u16)));

        // logits_out = resize(logits_add) + (uint16_t)(logits+128)<<shift
        _T1(rb_logits_add, rb_logits_add(logitsAdd_u16, logitsOut_u16));
        _T1(logitsOut_add, (vec_add_i8_u16<P::DPU_OUTPUT_SHIFT, P::DPU_OUTPUT_SIZE>(dpu_output, logitsOut_u16)));

#ifdef NARROW_LOGITS_TO_U8
        uint8_t *logitsOut_u8 = frame->logitsOut_u8;
        _T1(logitsOut_u16_to_u8, BlockFloat::u16_to_u8(logitsOut_u16, logitsOut_u8, P::DPU_OUTPUT_SIZE));
        cv::Mat logitsOutMat(P::DPU_OUTPUT_HEIGHT, P::DPU_OUTPUT_WIDTH, CV_MAKETYPE(CV_8U, P::DPU_OUTPUT_CHANNEL), logitsOut_u8);
#else
        cv::Mat logitsOutMat(P::DPU_OUTPUT_HEIGHT, P::DPU_OUTPUT_WIDTH, CV_MAKETYPE(CV_16U, P::DPU_OUTPUT_CHANNEL), logitsOut_u16);
#endif
#endif // #else USE_LOGITS_RSHIFT_FOR_U8

        // transpose output (TODO: merge to add logits loop)
        if (P::DPU_TRANSPOSE_HW) {
            uint16_t *logitsOutTr = frame->logitsOutTr;
            cv::Mat logitsOutTrMat(P::NN_OUTPUT_HEIGHT, P::NN_OUTPUT_WIDTH, logitsOutMat.type(), logitsOutTr);
            //_T1(logitsOut_Transpose, cv::transpose(logitsOutMat, logitsOutTrMat));
#if defined(NARROW_LOGITS_TO_U8) || defined(USE_LOGITS_RSHIFT_FOR_U8)
            _T1(logitsOut_Transpose, (transpose_u8_c6<P::DPU_OUTPUT_HEIGHT, P::DPU_OUTPUT_WIDTH, P::DPU_OUTPUT_CHANNEL>((uint8_t *)logitsOutMat.data, (uint8_t *)logitsOutTrMat.data)));
#else
            _T1(logitsOut_Transpose, (transpose_u16_c6<P::DPU_OUTPUT_HEIGHT, P::DPU_OUTPUT_WIDTH, P::DPU_OUTPUT_CHANNEL>((uint16_t *)logitsOutMat.data, (uint16_t *)logitsOutTrMat.data)));
#endif
            logitsOutMat = logitsOutTrMat;
            assert(logitsOutMat.rows == P::NN_OUTPUT_HEIGHT);
            assert(logitsOutMat.cols == P::NN_OUTPUT_WIDTH);
            assert(logitsOutMat.data == (void *)logitsOutTr);
        }

#ifdef UPSAMPLE_ARGMAX_IGNORE_CLASS
#if defined(NARROW_LOGITS_TO_U8) || defined(USE_LOGITS_RSHIFT_FOR_U8)
        uint8_t *data = (uint8_t *)logitsOutMat.data;
#else
        uint16_t *data = (uint16_t *)logitsOutMat.data;
#endif
        for (int i = UPSAMPLE_ARGMAX_IGNORE_CLASS; i < P::DPU_OUTPUT_SIZE; i += P::DPU_OUTPUT_CHANNEL) {
            data[i] = 0;
        }
#endif // UPSAMPLE_ARGMAX_IGNORE_CLASS

#ifdef USE_ROW_ALL_SAME_CLASS
        _T1(calc_row_all_same_class, calc_row_all_same_class<P::DPU_OUTPUT_CHANNEL>(logitsOutMat, argmax, row_all_same_class));
#endif

        // upsample & calculate class
        size_t write_bytes = 0;
        _T1(UpsampleArgmax, (write_bytes = ua.template operator()<UPSAMPLE_ARGMAX_LSHIFT, UPSAMPLE_ARGMAX_RUN_LENGTH_OUTPUT>((UPSAMPLE_ARGMAX_INPUT_TYPE *)logitsOutMat.data, frame->label_image, row_all_same_class)));
        assert(write_bytes <= sizeof(frame->label_image));

        return write_bytes;
    }

    unsigned int getLabelImageStartY(void) { return P::VALID_IMAGE_STARTY2; }
};

#ifdef USE_LIB_JPEG_V910
// jpeg_skip_scanlines is not exists in libjpeg. use jpeg_read_scanlines instead
JDIMENSION jpeg_skip_scanlines(j_decompress_ptr cinfo, JDIMENSION num_lines) {
    thread_local std::vector<uint8_t> buf;
    buf.resize(cinfo->image_width * cinfo->num_components);
    uint8_t *out = buf.data();
    for (JDIMENSION i = 0; i < num_lines; i++) {
        JDIMENSION n = jpeg_read_scanlines(cinfo, &out, 1);
        assert(n == 1);
    }
    return num_lines;
}
#endif

#if defined(USE_LIB_JPEG_V910) || defined(USE_LIB_JPEG_TURBO_V205)
// Row Decoder for Jpeg
class RowDecoderJpeg : public RowDecoderInterface<uint8_t> {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;
    vector<vector<uint8_t> > row_buffer;  // circular buffer
    int buf_idx;
    int height;
    int width;
    unsigned int y_ptr;

  public:
    RowDecoderJpeg(int num_buf) {
        /* Setup decompression context */
        cinfo.err = jpeg_std_error(&jerr);
        jpeg_create_decompress(&cinfo);

        /* initialize buffer */
        row_buffer.resize(num_buf);
    }

    ~RowDecoderJpeg(void) {
        /* Clean up */
        jpeg_destroy_decompress(&cinfo);
    }

    void open(uint8_t *jpeg_data, size_t num_bytes) {
        /* Specify data source for decompression */
        jpeg_mem_src(&cinfo, jpeg_data, num_bytes);

        /* Read JPEG header */
        jpeg_read_header(&cinfo, TRUE);
        height = cinfo.image_height;
        width  = cinfo.image_width;

        /* scale */
        cinfo.scale_num = JPEG_SCALE_NUM;
        cinfo.scale_denom = JPEG_SCALE_DENOM;
        height = JPEG_SCALE(height);
        width = JPEG_SCALE(width);

        /* Start JPEG decode */
        jpeg_start_decompress(&cinfo);

        /* allocate buffer */
        for (auto &b : row_buffer) {
            b.resize(width * cinfo.num_components);
        }

        /* reset y_ptr, buf_idx */
        y_ptr = 0;
        buf_idx = 0;
    }

    const uint8_t *getRow(unsigned int y) {
        if (y == y_ptr-1) { // same as last row
            return (buf_idx == 0 ? row_buffer.back().data() : row_buffer[buf_idx-1].data());
        }
        assert(y >= y_ptr);
        assert(y < getHeight());

        // skip lines if need
        int num_skip_lines = y-y_ptr;
        if (num_skip_lines > 0) {
            jpeg_skip_scanlines(&cinfo, num_skip_lines);
            y_ptr += num_skip_lines;
        }

        // decode one line
        assert(y == y_ptr);
        uint8_t *out = row_buffer[buf_idx].data();
        JDIMENSION n = jpeg_read_scanlines(&cinfo, &out, 1);
        assert(n == 1);
        y_ptr++;

        // update buf_idx
        buf_idx++;
        if (buf_idx == (int)row_buffer.size()) {
            buf_idx = 0;
        }

        return out;
    }

    void close(void) {
        /* Skip lines until end */
        int num_skip_lines = getHeight()-y_ptr;
        if (num_skip_lines > 0) {
            jpeg_skip_scanlines(&cinfo, num_skip_lines);
        }

        /* finish decompress */
        jpeg_finish_decompress(&cinfo);
    }

    unsigned int getHeight(void) const { return height; }
    unsigned int getWidth(void) const { return width; }
    unsigned int getChannels(void) const { return cinfo.num_components; }
    J_COLOR_SPACE getColorSpace(void) const { return cinfo.out_color_space; }
};
#endif

class UNet {
  public:
    enum ModelSelectMode {
        ModelSelectNormal = 0,
        ModelSelectCutTopQuarter = 1,
        ModelSelectAdaptive = 2,
        ModelSelectOracle = 3
    };

  private:
    UNetDPUManager * const unet_dpu_manager;
    FrameData * const frameData;  // frameData[num_images]
    unsigned int * const modelSelectResult;  // modelSelectResult[num_images]
    size_t * const labelSize;  // labelSize[num_images]
    const string name;
    const unsigned int unet_id;
    const ModelSelectMode model_select_mode;
    ThreadBarrier &barrier;
    queue<pair<unsigned int, cv::Mat> > &input_queue;
    queue<pair<unsigned int, unsigned int> > &output_queue;
    queue<std::pair<unsigned int, unsigned int> > preprocess_queue; // preprocess queue
    queue<std::pair<unsigned int, unsigned int> > dpu_queue;
    queue<std::pair<unsigned int, unsigned int> > segout_queue;     // segout queue
    UNetCalcInterface *unet_calc[NUM_NN_MODELS];
#ifdef USE_ROW_DECODE_JPEG
    RowDecoderJpeg row_decoder_jpeg;
#endif
    JudgeCutTop<JUDGE_CUT_TOP_COLOR_DIV_N_LOG2> *judge_cut_top;
    VCDTrace<uint8_t> cpu_id_trace;
    VCDTrace<uint8_t> preprocess_img_idx_trace;
    VCDTrace<uint8_t> segmentation_start_img_idx_trace;
    VCDTrace<uint8_t> segmentation_end_img_idx_trace;
    VCDTrace<uint8_t> postprocess_img_idx_trace;

    #include "createJudgeCutTop.inc"

    bool is_end(void) {
        if (preprocess_queue.empty() &&
            dpu_queue.empty() &&
            segout_queue.empty() &&
            input_queue.empty()) {
            return true;
        }
        return false;
    }

    /**
     * @brief entry routine of preprocess
     *
     * @return none
     */
    void Preprocess(int batch_size) {
        // Run preprocess for images in input queue
        for (int bidx = 0; bidx < batch_size; bidx++) {
            // Get an image from input queue
            unsigned int img_idx;
            Mat mat;
            if (input_queue.empty()) {
                break;
            } else {
                img_idx = input_queue.front().first;
                mat = input_queue.front().second;
                input_queue.pop();
            }

            // trace
            if (OUTPUT_EXTRA_VCD_TRACE) preprocess_img_idx_trace.add(img_idx);

            unsigned int model_id = 0;
            if (img_idx != IMG_IDX_INVALID) {
#ifdef USE_ROW_DECODE_JPEG
                row_decoder_jpeg.open(frameData[img_idx].input_image, JPEG_IMAGE_BUFFER_SIZE);
                RowDecoderJpeg &row_decoder = row_decoder_jpeg;
#else
                RowDecoderRawImage<uint8_t> row_decoder(frameData[img_idx].input_image, SCALED_ORIG_IMAGE_WIDTH*ORIG_IMAGE_CHANNEL);
#endif

                // selet model
                if (model_select_mode == ModelSelectNormal) {
                    model_id = 0;
                }
                else if (model_select_mode == ModelSelectCutTopQuarter) {
                    model_id = 1;
                }
                else if (model_select_mode == ModelSelectAdaptive) {
                    model_id = 0;  // 0 start
                }
                else if (model_select_mode == ModelSelectOracle) {
                    model_id = modelSelectResult[img_idx];
                }
                else {
                    assert(false); // TODO
                }

                // preprocess
                assert(mat.data == (void *)&frameData[img_idx]);
                for (; model_id < NUM_NN_MODELS; model_id++) {
                    JudgeCutTop<JUDGE_CUT_TOP_COLOR_DIV_N_LOG2> *jct = (model_id < NUM_NN_MODELS-1 ? judge_cut_top : nullptr);
                    unet_calc[model_id]->Preprocess(row_decoder, &frameData[img_idx], mat.rows, mat.cols, mat.channels(), jct);
                    if (!jct || !jct->get_last_judge()) {
                        break;
                    }
                }
                assert(model_id < NUM_NN_MODELS);

#ifdef USE_ROW_DECODE_JPEG
                row_decoder_jpeg.close();
#endif

                // memo model select result
                modelSelectResult[img_idx] = model_id;
            }

            // Put image into preprocess queue
            preprocess_queue.push({img_idx, model_id});
        }
    }

    /**
     * @brief entry routine of segmentation, and put image into write queue
     *
     * @return none
     */
    void runSegmentation(int batch_size) {
#if !(defined(BLOCKING_DPU_SEGMENTATION) || defined(USE_THREAD_BARRIER))
        // check segmentation output
        while(!dpu_queue.empty()) {
            unsigned int img_idx = dpu_queue.front().first;
            unsigned int model_id = dpu_queue.front().second;
            assert(img_idx != IMG_IDX_INVALID);
            unsigned int img_idx_out = IMG_IDX_INVALID;
            bool ok;
            if (input_queue.empty()) {  // force wait DPU end if preprocess end
                _T1(waitSegmentation, unet_calc[model_id]->waitSegmentation(unet_id, img_idx_out));
                ok = true;
            }
            else {
                ok = unet_calc[model_id]->checkEndSegmentation(unet_id, img_idx_out);
            }
            if (ok) {
                assert(img_idx_out == img_idx);
                // Remove image from dpu queue
                dpu_queue.pop();
                // Put image into segout queue
                segout_queue.push({img_idx, model_id});
                // trace
                if (OUTPUT_EXTRA_VCD_TRACE) segmentation_end_img_idx_trace.add(img_idx);
            }
            else {
                return;
            }
        }
#endif
        assert(dpu_queue.empty());

        // Run detection for images in preprocess queue
        for (int bidx = 0; bidx < batch_size; bidx++) {
            // Get an image from preprocess queue
            unsigned int img_idx;
            unsigned int model_id;
            if (preprocess_queue.empty()) {
                break;
            } else {
                img_idx = preprocess_queue.front().first;
                model_id = preprocess_queue.front().second;
                preprocess_queue.pop();
            }

            // trace
            if (OUTPUT_EXTRA_VCD_TRACE) segmentation_start_img_idx_trace.add(img_idx);

#if defined(BLOCKING_DPU_SEGMENTATION) || defined(USE_THREAD_BARRIER)
#ifdef USE_THREAD_BARRIER
            barrier.wait();
#endif
            if (img_idx != IMG_IDX_INVALID) {
                unet_calc[model_id]->runSegmentation(unet_id, img_idx);
            }
#ifdef USE_THREAD_BARRIER
            barrier.wait();
#endif
            // Put image into segout queue
            segout_queue.push({img_idx, model_id});
            // trace
            if (OUTPUT_EXTRA_VCD_TRACE) segmentation_end_img_idx_trace.add(img_idx);
#else
            if (img_idx == IMG_IDX_INVALID) {
                // skip dpu
                segout_queue.push({img_idx, model_id});
                // trace
                if (OUTPUT_EXTRA_VCD_TRACE) segmentation_end_img_idx_trace.add(img_idx);
            }
            else {
                // start dpu segmentation
                unet_calc[model_id]->startSegmentation(unet_id, img_idx);
                // Put image into dpu queue
                dpu_queue.push({img_idx, model_id});
            }
#endif
        }
    }

    /**
     * @brief entry routine of postprocess
     *
     * @return none
     */
    void Postprocess(int batch_size) {
        // Run postprocess for images in segout queue
        for (int bidx = 0; bidx < batch_size; bidx++) {
            // Get an image from segout queue
            unsigned int img_idx;
            unsigned int model_id;
            if (segout_queue.empty()) {
                break;
            } else {
                img_idx = segout_queue.front().first;
                model_id = segout_queue.front().second;
                segout_queue.pop();
            }

            // trace
            if (OUTPUT_EXTRA_VCD_TRACE) postprocess_img_idx_trace.add(img_idx);

            if (img_idx != IMG_IDX_INVALID) {
                size_t write_bytes = unet_calc[model_id]->Postprocess(&frameData[img_idx]);
                labelSize[img_idx] = write_bytes;
            }

            // Put image into output queue
            output_queue.push({img_idx, unet_calc[model_id]->getLabelImageStartY()});
        }
    }

  public:
    UNet(string name, UNetDPUManager *unet_dpu_manager, UNetBuffers *unet_buffers, ModelSelectMode model_select_mode, double target_reduction,
         ThreadBarrier &barrier, queue<pair<unsigned int, cv::Mat> > &input_queue, queue<pair<unsigned int, unsigned int> > &output_queue) :
        unet_dpu_manager(unet_dpu_manager),
        frameData(unet_buffers->frameData),
        modelSelectResult(unet_buffers->modelSelectResult),
        labelSize(unet_buffers->labelSize),
        name(name),
        unet_id(unet_dpu_manager->allocate()),
        model_select_mode(model_select_mode),
        barrier(barrier),
        input_queue(input_queue),
        output_queue(output_queue),
#ifdef USE_ROW_DECODE_JPEG
        row_decoder_jpeg(2),
#endif
        cpu_id_trace(name + ".cpu_id", sched_getcpu()),
        preprocess_img_idx_trace(name + ".preprocess_img_idx", 0xff),
        segmentation_start_img_idx_trace(name + ".segmentation_start_img_idx", 0xff),
        segmentation_end_img_idx_trace(name + ".segmentation_end_img_idx", 0xff),
        postprocess_img_idx_trace(name + ".postprocess_img_idx", 0xff)
    {
        unet_calc[UNetDPUParameterNormal::MODEL_ID] = new UNetCalc<UNetDPUParameterNormal>(unet_dpu_manager, unet_id);
        unet_calc[UNetDPUParameterCutTopQuarter::MODEL_ID] = new UNetCalc<UNetDPUParameterCutTopQuarter>(unet_dpu_manager, unet_id);
        if (model_select_mode == ModelSelectAdaptive) {
            judge_cut_top = createJudgeCutTop<JUDGE_CUT_TOP_COLOR_DIV_N_LOG2>(target_reduction);
        }
        else {
            judge_cut_top = nullptr;
        }
    }

    ~UNet(void) {
        // destroy
        for (int i = 0; i < NUM_NN_MODELS; i++) {
            delete unet_calc[i];
        }
        delete judge_cut_top;

        // add trace to MeasureTime data
        if (OUTPUT_EXTRA_VCD_TRACE) {
            MeasureTime::add_trace(cpu_id_trace);
            MeasureTime::add_trace(preprocess_img_idx_trace);
            MeasureTime::add_trace(segmentation_start_img_idx_trace);
            MeasureTime::add_trace(segmentation_end_img_idx_trace);
            MeasureTime::add_trace(postprocess_img_idx_trace);
        }
    }

    int get_id(void) const { return unet_id; }

    const string &get_name(void) const { return name; }

    void run(int batch_size) {
        while (!is_end()) {
            if (OUTPUT_EXTRA_VCD_TRACE) cpu_id_trace.add(sched_getcpu());
            if (!input_queue.empty()) _T1(Preprocess, Preprocess(batch_size));
            if (!preprocess_queue.empty() || !dpu_queue.empty()) runSegmentation(batch_size);
            if (!segout_queue.empty()) _T1(Postprocess, Postprocess(batch_size));
        }
    }
};

/**
 * @brief put image names to a vector
 *
 * @param path - path of the image direcotry
 * @param images - the vector of image name
 *
 * @return none
 */
void ListImages(string const &path, vector<string> &images) {
    images.clear();
    struct dirent *entry;

    /*Check if path is a valid directory path. */
    struct stat s;
    lstat(path.c_str(), &s);
    if (!S_ISDIR(s.st_mode)) {
        cerr << "\nError: " << path << " is not a valid directory!" << endl;
        exit(1);
    }

    DIR *dir = opendir(path.c_str());
    if (dir == nullptr) {
        cerr << "\nError: Open " << path << " path failed." << endl;
        exit(1);
    }

    while ((entry = readdir(dir)) != nullptr) {
        if (entry->d_type == DT_REG || entry->d_type == DT_UNKNOWN) {
            string name = entry->d_name;
            string ext = name.substr(name.find_last_of(".") + 1);
            if ((ext == "JPEG") || (ext == "jpeg") || (ext == "JPG") || (ext == "jpg") ||
                (ext == "PNG") || (ext == "png")) {
                images.push_back(name);
            }
        }
    }

    sort(images.begin(), images.end());

    closedir(dir);
}

/**
 * @brief get input & output images list
 *
 * @param input_image_names - input image list
 * @param output_image_names - output image list
 *
 * @return none
 */
void GetImageList(const string &input_dir, vector<string> &input_image_names, vector<string> &output_image_names) {
    cout <<"Reading Images from " + input_dir << endl;
    input_image_names.clear();
    ListImages(input_dir, input_image_names);
    if (input_image_names.size() == 0) {
        cerr << "\nError: No images exist in " << input_dir << endl;
        exit(1);
    } else {
        cout << "total input images : " << input_image_names.size() << endl;
    }

    string img_result_name;
    output_image_names.clear();
    for (unsigned int img_idx=0; img_idx<input_image_names.size(); img_idx++) {
        const string &filename = input_image_names.at(img_idx);
        img_result_name = filename.substr(0, filename.find_last_of(".")) + ".png";
        output_image_names.push_back(img_result_name);
    }
}

#if defined(USE_LIB_JPEG_V910) || defined(USE_LIB_JPEG_TURBO_V205)
// Read jpeg RGB image & store RGB format (not BGR!!)
class JpegDecoder {
    struct jpeg_decompress_struct cinfo;
    struct jpeg_error_mgr jerr;

  public:
    JpegDecoder(void) {
        /* Setup decompression context */
        cinfo.err = jpeg_std_error(&jerr);
        jpeg_create_decompress(&cinfo);
    }

    ~JpegDecoder(void) {
        /* Clean up */
        jpeg_destroy_decompress(&cinfo);
    }

    void read_header(const std::string &filename, int &height, int &width, int &ch) {
        FILE *fp = fopen(filename.c_str(), "rb");
        if (fp == nullptr) {
            std::cerr << "Error: cannot open " << filename << std::endl;
            std::exit(1);
        }

        /* Specify data source for decompression */
        jpeg_stdio_src(&cinfo, fp);

        /* Read JPEG header */
        jpeg_read_header(&cinfo, TRUE);
        height = cinfo.image_height;
        width  = cinfo.image_width;
        ch     = cinfo.num_components;
        assert(cinfo.out_color_space == JCS_RGB);
        assert(ch == 3);

        /* scale */
        cinfo.scale_num = 1;
        cinfo.scale_denom = JPEG_SCALE_DENOM;
        height = JPEG_SCALE(height);
        width = JPEG_SCALE(width);

        /* Start JPEG decode */
        jpeg_start_decompress(&cinfo);

        /* skip all row */
        if (height > 0) {
            jpeg_skip_scanlines(&cinfo, height);
        }

        /* finish decompress */
        jpeg_finish_decompress(&cinfo);

        /* close file */
        fclose(fp);
    }

    void read(const std::string &filename, uint8_t *out, int max_read_height, int &height, int &width, int &ch) {
        FILE *fp = fopen(filename.c_str(), "rb");
        if (fp == nullptr) {
            std::cerr << "Error: cannot open " << filename << std::endl;
            std::exit(1);
        }

        /* Specify data source for decompression */
        jpeg_stdio_src(&cinfo, fp);

        /* Read JPEG header */
        jpeg_read_header(&cinfo, TRUE);
        height = cinfo.image_height;
        width  = cinfo.image_width;
        ch     = cinfo.num_components;
        assert(cinfo.out_color_space == JCS_RGB);
        assert(ch == 3);

        /* scale */
        cinfo.scale_num = 1;
        cinfo.scale_denom = JPEG_SCALE_DENOM;
        height = JPEG_SCALE(height);
        width = JPEG_SCALE(width);

        /* Set things up for decompression (this processes the entire
           file if necessary to return data line by line) */
        jpeg_start_decompress(&cinfo);

        /* Decompress */
        uint8_t *buf_ptr = out;
        int read_height = std::min(max_read_height, height);
        for (int y = 0; y < read_height; y++) {
            JDIMENSION n = jpeg_read_scanlines(&cinfo, &buf_ptr, 1);
            assert(n == 1);
            buf_ptr += (width * ch);
        }
        int num_skip_lines = height-read_height;
        if (num_skip_lines > 0) {
            jpeg_skip_scanlines(&cinfo, num_skip_lines);
        }

        /* finish decompress */
        jpeg_finish_decompress(&cinfo);

        /* close file */
        fclose(fp);
    }
};
#endif

bool isJpegFile(const std::string &filename) {
    string ext = filename.substr(filename.find_last_of(".") + 1);
    return (ext == "JPEG") || (ext == "jpeg") || (ext == "JPG") || (ext == "jpg");
}

void checkInputImageShape(const std::string &filename, int height, int width, int channels) {
    int error = 0;
    if (!(height == SCALED_ORIG_IMAGE_HEIGHT && width == SCALED_ORIG_IMAGE_WIDTH) &&
        !(height == UNetDPUParameterNormal::NN_INPUT_HEIGHT && width == UNetDPUParameterNormal::NN_INPUT_WIDTH) &&
        !(height == UNetDPUParameterCutTopQuarter::NN_INPUT_HEIGHT && width == UNetDPUParameterCutTopQuarter::NN_INPUT_WIDTH)) {
        cerr << "Error: " << filename << ": invalid image size " << width << "x" << height << ". expect " << ORIG_IMAGE_WIDTH << "x" << ORIG_IMAGE_HEIGHT << endl;
        error++;
    }
    if (channels != ORIG_IMAGE_CHANNEL) {
        cerr << "Error: " << filename << ": invalid image channels(=" << channels << "). expect " << ORIG_IMAGE_CHANNEL << endl;
        error++;
    }
    if (error) {
        std::exit(1);
    }
}

/**
 * @brief Read images into read queue
 *
 * @return none
 */
void Read(const string &input_dir, const vector<string> &images, vector<queue<pair<unsigned int, cv::Mat> > > &read_queue, FrameData *frameData) {
    const int num_threads = read_queue.size();
    size_t image_size_align = ((images.size() + num_threads - 1) / num_threads) * num_threads;
    auto read_thread_func = [&](int tid) {
#if defined(USE_LIB_JPEG_V910) || defined(USE_LIB_JPEG_TURBO_V205)
        JpegDecoder jd;
#endif
        for (size_t img_idx=tid; img_idx<image_size_align; img_idx+=num_threads) {
            if (img_idx >= images.size()) {
                read_queue[tid].push({IMG_IDX_INVALID, cv::Mat()});
            }
            else {
                uint8_t *input_image_buf = frameData[img_idx].input_image;
                const string &filename = images.at(img_idx);
                //cout << filename << endl;
#if defined(USE_LIB_JPEG_V910) || defined(USE_LIB_JPEG_TURBO_V205)
                int height, width, ch;
                if (!isJpegFile(filename)) {
                    cerr << "Error: " << input_dir + filename << " is not jpeg file." << endl;
                    std::exit(1);
                }
#ifdef USE_ROW_DECODE_JPEG
                jd.read_header(input_dir + filename, height, width, ch);
                FILE *fp = fopen((input_dir + filename).c_str(), "rb");
                assert(fp);
                size_t n = fread(input_image_buf, 1, JPEG_IMAGE_BUFFER_SIZE, fp);
                assert(n > 0);
                if (!feof(fp)) {
                    cerr << "Error: " << input_dir + filename << " is too large jpeg file. JPEG_IMAGE_BUFFER_SIZE = " << JPEG_IMAGE_BUFFER_SIZE << " bytes" << endl;
                    std::exit(1);
                }
                fclose(fp);
#else
                jd.read(input_dir + filename, input_image_buf, SCALED_VALID_IMAGE_HEIGHT, height, width, ch);
#endif
                checkInputImageShape(input_dir + filename, height, width, ch);
                cv::Mat imgOut(height, width, CV_8UC3, input_image_buf);
#else
                cv::Mat img = imread(input_dir + filename);
                if (img.empty()) {
                    cerr << "Error: cannot read " << input_dir + filename << endl;
                    std::exit(1);
                }
                checkInputImageShape(input_dir + filename, img.rows, img.cols, img.channels());
                cv::Mat imgOut(img.rows, img.cols, CV_8UC3, input_image_buf);
                cv::cvtColor(img, imgOut,  CV_BGR2RGB);
#endif
                read_queue[tid].push({img_idx, imgOut});
            }
        }
    };
    vector<thread> threads;
    for (int tid = 0; tid < num_threads; ++tid) {
        if (tid == num_threads-1) read_thread_func(tid);
        else threads.push_back(thread(read_thread_func, tid));
    }
    for (auto &th : threads) { th.join(); }
    cout << "Finish reading images." << endl;
}

void ReadModelSelectOracle(const vector<string> &images, const string &model_select_oracle_file, unsigned int *modelSelectResult) {
    ifstream ifs(model_select_oracle_file);
    if (!ifs) {
        std::cerr << "Error: cannot open " << model_select_oracle_file << std::endl;
        std::exit(1);
    }
    std::map<string, unsigned int> w;
    string name;
    unsigned int model_id;
    while (ifs >> name >> model_id) {
        assert(model_id < (unsigned int)NUM_NN_MODELS);
        w[name] = model_id;
    }
    for (size_t i = 0; i < images.size(); i++) {
        const auto &image = images[i];
        if (w.count(image) == 0) {
            std::cerr << "Error: " << image << " is not found in " << model_select_oracle_file << std::endl;
            std::exit(1);
        }
        modelSelectResult[i] = w[image];
    }
}

void SetModelSelectRandom(double select_model1_rate, int num_images, unsigned int *modelSelectResult) {
    auto drand = [](void) { return (double)rand()/((double)RAND_MAX+1.0); };
    for (int i = 0; i < num_images; i++) {
        modelSelectResult[i] = (drand() <= select_model1_rate ? 1 : 0);
    }
}

//                                        car, pedestrian, lane, signal, others, unlabeled
static const uint8_t colorR[NUM_CLASS] = {  0,        255,   69,    255,     81,         0};
static const uint8_t colorG[NUM_CLASS] = {  0,          0,   47,    255,     99,         0};
static const uint8_t colorB[NUM_CLASS] = {255,          0,  142,      0,      0,         0};
static const std::string class_name[NUM_CLASS] = {"car", "pedestrian", "lane", "signal", "others", "unlabeled"};

/**
 * @brief create output image from label_image
 *
 * @param img - output image. data_type = uint8, shape = [ORIG_IMAGE_HEIGHT, ORIG_IMAGE_WIDTH, 3]
 * @param posits - posits. data_type = uint8, shape = [VALID_IMAGE_HEIGHT, ORIG_IMAGE_WIDTH]
 *
 * @return none
 */
void createOutputImage(cv::Mat &img, const uint8_t *posits, int label_image_start) {
    int row = 0;
    // fill invalid area
    for (; row < label_image_start; row++) {
        for (int col = 0; col < ORIG_IMAGE_WIDTH; col++) {
            int posit = NUM_CLASS-1;
            img.at<Vec3b>(row, col) = Vec3b(colorB[posit], colorG[posit], colorR[posit]);
        }
    }
    // main
    for (; row < VALID_IMAGE_HEIGHT; row++) {
        for (int col = 0; col < ORIG_IMAGE_WIDTH; col++) {
            int posit = *(posits++);
            img.at<Vec3b>(row, col) = Vec3b(colorB[posit], colorG[posit], colorR[posit]);
        }
    }
    // fill invalid area
    for (; row < ORIG_IMAGE_HEIGHT; row++) {
        for (int col = 0; col < ORIG_IMAGE_WIDTH; col++) {
            int posit = NUM_CLASS-1;
            img.at<Vec3b>(row, col) = Vec3b(colorB[posit], colorG[posit], colorR[posit]);
        }
    }
}

/**
 * @brief create output image from run_length encoded label image
 *
 * @param img - output image. data_type = uint8, shape = [ORIG_IMAGE_HEIGHT, ORIG_IMAGE_WIDTH, 3]
 * @param label_rl - run_length encoded label image. data_type = uint16, decoded shape = [VALID_IMAGE_HEIGHT, ORIG_IMAGE_WIDTH]
 *
 * @return none
 */
void createOutputImageFromRunLengthData(cv::Mat &img, const uint16_t *label_rl, int label_image_start) {
    int row = 0;
    // fill invalid area
    for (; row < label_image_start; row++) {
        for (int col = 0; col < ORIG_IMAGE_WIDTH; col++) {
            int posit = NUM_CLASS-1;
            img.at<Vec3b>(row, col) = Vec3b(colorB[posit], colorG[posit], colorR[posit]);
        }
    }
    // main
    for (; row < VALID_IMAGE_HEIGHT; row++) {
        int col = 0;
        while (col != ORIG_IMAGE_WIDTH) {
            assert(col < ORIG_IMAGE_WIDTH);
            uint16_t len;
            uint8_t posit;
            UPSAMPLE_ARGMAX_RUNLENGTH_DECODE(len, posit, *label_rl++);
            assert(len > 0);
            for (int dc = 0; dc < len; dc++) {
                img.at<Vec3b>(row, col+dc) = Vec3b(colorB[posit], colorG[posit], colorR[posit]);
            }
            col += len;
        }
    }
    // fill invalid area
    for (; row < ORIG_IMAGE_HEIGHT; row++) {
        for (int col = 0; col < ORIG_IMAGE_WIDTH; col++) {
            int posit = NUM_CLASS-1;
            img.at<Vec3b>(row, col) = Vec3b(colorB[posit], colorG[posit], colorR[posit]);
        }
    }
}

// class for writing json file of segmentation result
class JSONWriter {
  public:
    typedef std::map<uint16_t, std::vector<std::pair<uint16_t, uint16_t> > > range_map_t[NUM_VALID_CLASS];

  private:
    FILE *fp;
    bool first_image;

    struct LabelDecodeRaw {
        typedef uint8_t data_t;
        inline void operator()(const data_t &val, uint16_t &len, uint8_t &class_id) const {
            len = 1;
            class_id = val;
        }
    };

    struct LabelDecodeRunLength {
        typedef uint16_t data_t;
        inline void operator()(const data_t &val, uint16_t &len, uint8_t &class_id) const {
            UPSAMPLE_ARGMAX_RUNLENGTH_DECODE(len, class_id, val);
        }
    };

    template<typename DECODER_T>
    static void calcRangeTemp(const DECODER_T &dec, const typename DECODER_T::data_t *label_data, int height, int width, int starty, JSONWriter::range_map_t &range) {
        // clear
        for (int cid = 0; cid < NUM_VALID_CLASS; cid++) {
            range[cid].clear();
        }

        // calc
        const typename DECODER_T::data_t *p = label_data;
        for (int row = starty; row < height; row++) {
            int col = 0;
            int start_pos = -1;
            uint8_t last_class = (uint8_t)-1;
            vector<pair<uint16_t, uint16_t> > range_row[NUM_CLASS];
            while (col != width) {
                assert(col < width);
                uint16_t len;
                uint8_t posit;
                dec(*p++, len, posit);
                if (posit != last_class) {
                    if (last_class < NUM_VALID_CLASS) {
                        range_row[last_class].push_back({start_pos, col-1});
                    }
                    start_pos = col;
                }
                last_class = posit;
                col += len;
            }
            if (last_class < NUM_VALID_CLASS) {
                range_row[last_class].push_back({start_pos, width-1});
            }
            for (int c = 0; c < NUM_VALID_CLASS; c++) {
                if (!range_row[c].empty()) {
                    range[c][row] = std::move(range_row[c]);
                }
            }
        }
    }

  public:
    JSONWriter(void) : fp(nullptr), first_image(true) {}
    JSONWriter(const std::string &filename) : fp(nullptr), first_image(true) {
        open(filename);
    }
    ~JSONWriter() {
        if (fp) {
            close();
        }
    }

    void open(const std::string &filename) {
        assert(!fp);
        fp = fopen(filename.c_str(), "w");
        if (!fp) {
            cerr << "Error: cannot open " << filename << endl;
            std::exit(1);
        }
        first_image = true;
        fputc('{', fp);
    }

    void close(void) {
        fputc('}', fp);
        fclose(fp);
        fp = nullptr;
    }

#ifdef WRITE_JSON_USE_STRING_BUF
    size_t write(const std::string &image_name, const std::map<uint16_t, std::vector<std::pair<uint16_t, uint16_t> > > (&range)[NUM_VALID_CLASS], char *buf) const {
        const uint8_t print_class_order[NUM_VALID_CLASS] = {0/*car*/, 2/*lane*/, 1/*pedestrian*/, 3/*signal*/};
        char * const buf_start = buf;
#define SPUTC(c) *(buf++)=(c)
#define SPRINTF(...) do { int n_ = sprintf(buf, __VA_ARGS__); buf += n_; } while(false)
        SPRINTF("\"%s\":{", image_name.c_str());
        bool first = true;
        for (auto cid : print_class_order) {
            if (!range[cid].empty()) {
                if (!first) SPUTC(',');
                first = false;
                SPRINTF("\"%s\":{", class_name[cid].c_str());
                bool first_row = true;
                for (const auto &p : range[cid]) {
                    if (!first_row) SPUTC(',');
                    first_row = false;
                    int row = p.first;
                    SPRINTF("\"%d\":[", row);
                    bool first_range = true;
                    for (const auto &r : p.second) {
                        if (!first_range) SPUTC(',');
                        first_range = false;
                        SPRINTF("[%d,%d]", (int)r.first, (int)r.second);
                    }
                    SPUTC(']');
                }
                SPUTC('}');
            }
        }
        SPUTC('}');
#undef SPUTC
#undef SPRINTF
        return (uintptr_t)buf - (uintptr_t)buf_start;
    }

    void write(char *buf, size_t size) {
        if (!first_image) fputc(',', fp);
        first_image = false;
        size_t write_size = fwrite(buf, 1, size, fp);
        assert(write_size == size);
    }
#else
    void write(const std::string &image_name, const std::map<uint16_t, std::vector<std::pair<uint16_t, uint16_t> > > (&range)[NUM_VALID_CLASS]) {
        const uint8_t print_class_order[NUM_VALID_CLASS] = {0/*car*/, 2/*lane*/, 1/*pedestrian*/, 3/*signal*/};
        if (!first_image) fputc(',', fp);
        first_image = false;
        fprintf(fp, "\"%s\":{", image_name.c_str());
        bool first = true;
        for (auto cid : print_class_order) {
            if (!range[cid].empty()) {
                if (!first) fputc(',', fp);
                first = false;
                fprintf(fp, "\"%s\":{", class_name[cid].c_str());
                bool first_row = true;
                for (const auto &p : range[cid]) {
                    if (!first_row) fputc(',', fp);
                    first_row = false;
                    int row = p.first;
                    fprintf(fp, "\"%d\":[", row);
                    bool first_range = true;
                    for (const auto &r : p.second) {
                        if (!first_range) fputc(',', fp);
                        first_range = false;
                        fprintf(fp, "[%d,%d]", (int)r.first, (int)r.second);
                    }
                    fputc(']', fp);
                }
                fputc('}', fp);
            }
        }
        fputc('}', fp);
    }
#endif

    static void calcRange(const uint8_t *label_image, int height, int width, int starty, JSONWriter::range_map_t &range) {
        JSONWriter::calcRangeTemp(JSONWriter::LabelDecodeRaw(), label_image, height, width, starty, range);
    }

    static void calcRangeFromRunLengthData(const uint16_t *label_data, int height, int width, int starty, JSONWriter::range_map_t &range) {
        JSONWriter::calcRangeTemp(JSONWriter::LabelDecodeRunLength(), label_data, height, width, starty, range);
    }
};

/**
 * @brief Write Segmentation Result into JSON file (frameData.label_image is destroyed when WRITE_JSON_USE_STRING_BUF is enabled)
 *
 * @return none
 */
void WriteJSON(const vector<string> &images, JSONWriter &jw, vector<queue<pair<unsigned int, unsigned int> > > &label_queue, const FrameData *frameData) {
    const int num_threads = label_queue.size();
    SyncChannel<bool> sch[num_threads];

    // Run write for images in label queue
    auto write_thread_func = [&](int tid) {
        JSONWriter::range_map_t rm;
        SyncChannel<bool> &prev = sch[tid];
        SyncChannel<bool> &next = sch[(tid+1)%num_threads];
        while (!label_queue[tid].empty()) {
            // Get an image from label queue
            unsigned int img_idx = label_queue[tid].front().first;
            unsigned int label_image_start = label_queue[tid].front().second;
            label_queue[tid].pop();

            // calc range
            if (img_idx < images.size()) {
                if (UPSAMPLE_ARGMAX_RUN_LENGTH_OUTPUT) {
                    assert((uintptr_t)frameData[img_idx].label_image % 2 == 0);
                    assert(UpsampleArgmaxRunLengthCheck(reinterpret_cast<const uint16_t *>(frameData[img_idx].label_image), VALID_IMAGE_HEIGHT-label_image_start, ORIG_IMAGE_WIDTH, NUM_CLASS-1));
                    _T2(calcRange, JSONWriter::calcRangeFromRunLengthData(reinterpret_cast<const uint16_t *>(frameData[img_idx].label_image), VALID_IMAGE_HEIGHT, ORIG_IMAGE_WIDTH, label_image_start, rm));
                }
                else {
                    _T2(calcRange, JSONWriter::calcRange(frameData[img_idx].label_image, VALID_IMAGE_HEIGHT, ORIG_IMAGE_WIDTH, label_image_start, rm));
                }
            }

#ifdef WRITE_JSON_USE_STRING_BUF
            // reuse label_image memory for json string memory (frameData[img_idx].label_image is destroyed)
            char * const buf = (char *)(frameData[img_idx].label_image);
            static const size_t buf_capacity = sizeof(frameData[img_idx].label_image);
            size_t buf_size = 0;
            if (img_idx < images.size()) {
                _T2(jsonWriteStr, (buf_size = jw.write(images[img_idx], rm, buf)));
                if (buf_size > buf_capacity) {
                    cerr << "Error: WriteJSON: buffer overflow" << endl;
                    std::exit(1);
                }
            }
#endif

            // wait prev write end
            prev.get();

            // write to file
            if (img_idx < images.size()) {
#ifdef WRITE_JSON_USE_STRING_BUF
                _T2(jsonWriteFile, jw.write(buf, buf_size));
#else
                _T2(jsonWrite, jw.write(images[img_idx], rm));
#endif
            }

            // notify write end to next
            next.put(true);
        }
    };

    // Launch threads
    vector<thread> threads;
    sch[0].put(true);
    for (int tid = 0; tid < num_threads; ++tid) {
        if (tid == num_threads-1) write_thread_func(tid);
        else threads.push_back(thread(write_thread_func, tid));
    }
    for (auto &th : threads) { th.join(); }
    sch[0].get();

    cout << "Finish writing JSON file." << endl;
}

/**
 * @brief make directory if directory does not exists
 *
 * @return none
 */
void try_make_directory(const string &dir) {
    struct stat statBuf;
    if (stat(dir.c_str(), &statBuf) == 0) {
        return;  // already exists
    }
    int error = mkdir(dir.c_str(), 0777);
    if (error) {
        cerr << "Error: cannot make directory '" << dir << "'" << endl;
        std::exit(1);
    }
}

/**
 * @brief Write images into file
 *
 * @return none
 */
void Write(const string &output_dir, const vector<string> &image_result_names, vector<queue<pair<unsigned int, unsigned int> > > &label_queue, const FrameData *frameData) {
    const int num_threads = label_queue.size();
    try_make_directory(output_dir);
    // Run write for images in label queue
    auto write_thread_func = [&](int tid) {
        while (!label_queue[tid].empty()) {
            // Get an image from label queue
            unsigned int img_idx = label_queue[tid].front().first;
            unsigned int label_image_start = label_queue[tid].front().second;
            label_queue[tid].pop();

            if (img_idx >= image_result_names.size()) {
                continue;
            }

            // output to file
            cv::Mat outImg(ORIG_IMAGE_HEIGHT, ORIG_IMAGE_WIDTH, CV_8UC3);
            if (UPSAMPLE_ARGMAX_RUN_LENGTH_OUTPUT) {
                assert(UpsampleArgmaxRunLengthCheck(reinterpret_cast<const uint16_t *>(frameData[img_idx].label_image), VALID_IMAGE_HEIGHT-label_image_start, ORIG_IMAGE_WIDTH, NUM_CLASS-1));
                _T2(createOutputImageFromRunLengthData, createOutputImageFromRunLengthData(outImg, reinterpret_cast<const uint16_t *>(frameData[img_idx].label_image), label_image_start));
            }
            else {
                _T2(createOutputImage, createOutputImage(outImg, frameData[img_idx].label_image, label_image_start));
            }
            _T2(imwrite, imwrite(output_dir + image_result_names[img_idx], outImg));
        }
    };

    // Launch threads
    vector<thread> threads;
    for (int tid = 0; tid < num_threads; ++tid) {
        if (tid == num_threads-1) write_thread_func(tid);
        else threads.push_back(thread(write_thread_func, tid));
    }
    for (auto &th : threads) { th.join(); }

    cout << "Finish writing images." << endl;
}

template<typename P>
void DumpDPUFrame(const string &dump_dir, int idx, const FrameData &frame) {
    ostringstream oss; oss << std::setw(5) << std::setfill('0') << idx;
    // dump input
    {
        static const size_t input_size = P::DPU_INPUT_SIZE;
        string fname = dump_dir + "dpu_input_" + oss.str() + ".bin";
        FILE *fp = fopen(fname.c_str(), "wb");
        if (!fp) {
            cerr << "Error: cannot open " << fname << endl;
            std::exit(1);
        }
        size_t write_size = fwrite(frame.dpu_input, 1, input_size, fp);
        assert(write_size == input_size);
        fclose(fp);
    }
    // dump input as png image
    {
        cv::Mat img(P::DPU_INPUT_HEIGHT, P::DPU_INPUT_WIDTH, CV_8UC3);
        uint8_t *img_data = (uint8_t *)img.data;
        for (int i = 0; i < P::DPU_INPUT_SIZE; i++) {
            img_data[i] = std::min((unsigned int)frame.dpu_input[i]<<P::DPU_INPUT_SHIFT, 255U);
        }
        cv::cvtColor(img, img,  CV_RGB2BGR);
        cv::imwrite(dump_dir + "dpu_input_" + oss.str() +".png", img);
    }
    // dump output
    {
        static const size_t output_size = P::DPU_OUTPUT_TOTAL_SIZE;
        string fname = dump_dir + "dpu_output_" + oss.str() + ".bin";
        FILE *fp = fopen(fname.c_str(), "wb");
        if (!fp) {
            cerr << "Error: cannot open " << fname << endl;
            std::exit(1);
        }
        size_t write_size = fwrite(frame.dpu_output, 1, output_size, fp);
        assert(write_size == output_size);
        fclose(fp);
    }
}

/**
 * @brief Dump DPU Input/Output
 *
 * @return none
 */
void DumpDPU(const string &dump_dir, int start_idx, int num_images, const FrameData *frameData, const unsigned int *modelSelectResult) {
#if !defined(USE_DPU_SPLIT_IO) || (defined(BLOCKING_DPU_SEGMENTATION) && !defined(USE_THREAD_BARRIER))
    cout << "Warning: cannot use dump feature. dump skipped." << endl;
    return;
#else
    try_make_directory(dump_dir);
    for (int i = 0; i < num_images; i++) {
        int model_id = modelSelectResult[i];
        switch (model_id) {
          case 0: DumpDPUFrame<UNetDPUParameterNormal       >(dump_dir, start_idx+i, frameData[i]); break;
          case 1: DumpDPUFrame<UNetDPUParameterCutTopQuarter>(dump_dir, start_idx+i, frameData[i]); break;
          default: assert(false);
        }
    }
#endif
}

class UNetRunner {
    const int num_threads;
    const int num_image_buffers;
    UNetBuffers * const unet_buffers;
    UNetDPUManager * const unet_dpu_manager;
    ThreadBarrier barrier;
    const int batch_size;
    vector<UNet *> unets;
    vector<thread> threads;
    vector<SyncChannel<int> > ch_start_unet;
    vector<SyncChannel<bool> > ch_end_unet;
    vector<queue<pair<unsigned int, cv::Mat> > > input_queue_;  // pair<img_idx, image> input_queue[num_threads]
    vector<queue<pair<unsigned int, unsigned int> > > output_queue_; // pair<img_idx, start_y> output_queue[num_threads}

    std::chrono::system_clock::duration last_duration_time;

    static void threadBody(UNet *unet, int batch_size, SyncChannel<int> &ch_start, SyncChannel<bool> &ch_end) {
        MeasureTimeThreadData::set_name(unet->get_name());
        while (true) {
            int num_images = ch_start.get();
            if (num_images == -1) {  // end
                break;
            }
            unet->run(batch_size);
            ch_end.put();
        }
    }

  public:
    UNetRunner(int num_threads, int num_image_buffers,
               string unet_dpu_manager_name, int unet_dpu_manager_cpu_id,
               string unet_name, UNet::ModelSelectMode model_select_mode, double target_reduction, int batch_size)
        : num_threads(num_threads),
          num_image_buffers(num_image_buffers),
          unet_buffers(new UNetBuffers(num_image_buffers)),
          unet_dpu_manager(new UNetDPUManager(unet_dpu_manager_name, num_threads, unet_dpu_manager_cpu_id, num_image_buffers, unet_buffers->frameData)),
          barrier(num_threads),
          batch_size(batch_size),
          ch_start_unet(num_threads),
          ch_end_unet(num_threads),
          input_queue_(num_threads),
          output_queue_(num_threads)
    {
        assert(num_threads > 0);

        // create UNet
        for (int i = 0; i < num_threads; i++) {
            ostringstream oss; oss << i;
            unets.push_back(new UNet(unet_name+oss.str(), unet_dpu_manager, unet_buffers, model_select_mode, target_reduction, barrier, input_queue_[i], output_queue_[i]));
        }

        // start threads
        for (int i = 0; i < num_threads; ++i) {
            threads.push_back(std::thread(UNetRunner::threadBody, unets[i], batch_size, std::ref(ch_start_unet[i]), std::ref(ch_end_unet[i])));
            set_thread_affinity(threads[i].native_handle(), i);
        }
    }

    ~UNetRunner(void) {
        // stop threads
        for (int i = 0; i < num_threads; i++) {
            ch_start_unet[i].put(-1);
            threads[i].join();
        }

        // Destroy unet
        for (int i = 0; i < num_threads; i++) {
            delete unets[i];
        }

        // delete dpu manager
        delete unet_dpu_manager;

        // delete buffer
        delete unet_buffers;
    }

    void run(int num_images) {
        std::chrono::system_clock::time_point start_time = std::chrono::system_clock::now();

        // start dpu thread
        assert(num_images <= num_image_buffers);
        unet_dpu_manager->set_num_images(num_images);

        // start unet threads
        int num_images_per_thread = (num_images+num_threads-1)/num_threads;
        for (int i = 0; i < num_threads; ++i) {
            ch_start_unet[i].put(num_images_per_thread);
        }

        // wait unet threads end
        for (int i = 0; i < num_threads; ++i) {
            ch_end_unet[i].get();
        }

        std::chrono::system_clock::time_point end_time = std::chrono::system_clock::now();
        last_duration_time = end_time - start_time;
    }

    uint64_t get_last_duration_time_in_us(void) const { return (uint64_t)std::chrono::duration_cast<std::chrono::microseconds>(last_duration_time).count(); }

    const UNetDPUManager::Stat &get_stat(void) const { return unet_dpu_manager->get_stat(); }

    vector<queue<pair<unsigned int, cv::Mat> > > &input_queue(void) { return input_queue_; }
    vector<queue<pair<unsigned int, unsigned int> > > &output_queue(void) { return output_queue_; }
    FrameData *frameData(void) { return unet_buffers->frameData; }
    unsigned int *modelSelectResult(void) { return unet_buffers->modelSelectResult; }
    size_t *labelSize(void) { return unet_buffers->labelSize; }
};

struct CommandLineOptions {
    enum OutputFormat {
        OutputFormatPNG,
        OutputFormatJSON
    };

    static const int max_num_threads = 16;  // max num_threads value for safe
    static const int max_num_image_buffers = 500;  // max num_image_buffers value for safe

#if defined(USE_LIB_JPEG_V910) || defined(USE_LIB_JPEG_TURBO_V205)
#ifdef USE_ROW_DECODE_JPEG
    static const int num_image_buffers_default = 500;
#else
    static const int num_image_buffers_default = 200;
#endif
#else
    static const int num_image_buffers_default = 100;
#endif

    string input_dir;
    string output_dir;
    string output_file;
    OutputFormat output_format;
    int num_threads;
    int num_image_buffers;
    double resize_nn_threshold_x;
    double resize_nn_threshold_y;
    string model_select;
    int time_level;
    int dpu_task_mode;
    bool output_wave;
    bool output_model_select_result;
    bool output_label_size;
    bool dump_dpu_input_output;

    // fixed value
    const string output_model_select_file;
    const string output_label_size_file;

    // calculated from model_select
    UNet::ModelSelectMode model_select_mode;
    double select_model1_rate;
    string model_select_file;

    CommandLineOptions(void)
        : output_model_select_file("model_select_out.txt"),
          output_label_size_file("label_size_out.txt")
    {
        // set default
        input_dir = "inputs/";
        output_dir = "outputs/";
        output_file = "seg_out.json";
        output_format = OutputFormatJSON;
        num_threads = 4;
        num_image_buffers = num_image_buffers_default;
        resize_nn_threshold_x = 0.0;
        resize_nn_threshold_y = 0.0;
        model_select = "adaptive:0.925";
        time_level = TIME_LEVEL_DEFAULT;
        dpu_task_mode = T_MODE_NORMAL;
        output_wave = false;
        output_model_select_result = false;
        output_label_size = false;
        dump_dpu_input_output = false;
        int error = setModelSelectMode();
        assert(error == 0);
    }

    void usage(const string &command_name) {
        cout << "usage: " << command_name << " [OPTION]" << endl;
        cout << "   -h                     print this usage and exit" << endl;
        cout << "   -i <input_dir>         input image directory (default: inputs/)" << endl;
        cout << "   -f <output_format>     output format. png or json (default: json)" << endl;
        cout << "   -o <output_dir/file>   output directory (for png) or file (for json) (default: outputs/ or seg_out.json)" << endl;
        cout << "   -n <num_threads>       number of threads (default: 4)" << endl;
        cout << "   -b <num_image_buffers> number of image buffers (default: " << num_image_buffers_default << ")" << endl;
        cout << "   -x <threshold>         nearest_neighbor_threshold_x for input resize (default: 0.0)" << endl;
        cout << "   -y <threshold>         nearest_neighbor_threshold_y for input resize (default: 0.0)" << endl;
        cout << "   -m <model_select>      model selection method (default: adaptive:0.925)" << endl;
        cout << "                           - model0                        use model0 only" << endl;
        cout << "                           - model1                        use model1 only" << endl;
        cout << "                           - adaptive:<model1_select_rate> select adaptively" << endl;
        cout << "                           - random:<model1_select_rate>   select randomly" << endl;
        cout << "                           - oracle:<file>                 read from model select file" << endl;
        cout << "   -t <level>             time measurement level (default: " << TIME_LEVEL_DEFAULT << ")" << endl;
        cout << "   -p <dpu_task_mode>     dpu_task_mode. normal or debug or profile (default: normal)" << endl;
        cout << "   -w                     enable time measurement waveform (measure_time.vcd) output" << endl;
        cout << "   -s                     output model selection result to '" << output_model_select_file << "'" << endl;
        cout << "   -l                     output label size to '" << output_label_size_file << "'" << endl;
        cout << "   -d                     dump DPU input/output to '" << DUMP_DIR << "' directory" << endl;
    }

    int parse(int argc, char **argv) {
        string opt_with_argument = "iofnbxymtp";
        string opt_without_argument = "swldh";
        string optstring;
        for (char c : opt_with_argument) { optstring += c; optstring += ':'; }
        for (char c : opt_without_argument) { optstring += c; }

        // non-option or end of argument list or error('?')
        int c;
        while ((c = getopt(argc, argv, optstring.c_str())) != -1) {
            if (c == 'i') {
                input_dir = string(optarg);
                // change name for directory
                if (!input_dir.empty() && input_dir.back() != '/') {
                    input_dir += '/';
                }
            } else if (c == 'o') {
                output_dir = string(optarg);
                output_file = string(optarg);
                // change name for directory
                if (!output_dir.empty() && output_dir.back() != '/') {
                    output_dir += '/';
                }
                // change name for json file
                if (output_file.back() == '/') {
                    output_file += "seg_out.json";
                }
                if (output_file.size() < 5 || output_file.substr(output_file.size()-5) != ".json") {
                    output_file += ".json";
                }
            } else if (c == 'f') {
                string s = string(optarg);
                if (s == "png" || s == "PNG") {
                    output_format = OutputFormatPNG;
                }
                else if (s == "json" || s == "JSON") {
                    output_format = OutputFormatJSON;
                }
                else {
                    cerr << argv[0] << ": Invalid output format '" << s << "'" << endl;
                    return 1;
                }
            } else if (c == 'm') {
                model_select = string(optarg);
                int error = setModelSelectMode();
                if (error) return error;
            } else if (c == 'n') {
                istringstream iss(optarg);
                iss >> num_threads;
                if (iss.fail() || num_threads < 1 || num_threads > max_num_threads) {
                    cerr << argv[0] << ": num_threads=" << optarg << " is invalid setting" << endl;
                    return 1;
                }
            } else if (c == 'b') {
                istringstream iss(optarg);
                iss >> num_image_buffers;
                if (iss.fail() || num_image_buffers < 1 || num_image_buffers > max_num_image_buffers) {
                    cerr << argv[0] << ": num_image_buffers=" << optarg << " is invalid setting" << endl;
                    return 1;
                }
            } else if (c == 'x') {
                istringstream iss(optarg);
                iss >> resize_nn_threshold_x;
                if (iss.fail() || resize_nn_threshold_x < 0.0 || resize_nn_threshold_x > 0.5) {
                    cerr << argv[0] << ": resize_nn_threshold_x=" << optarg << " is invalid setting. must be between 0.0 and 0.5" << endl;
                    return 1;
                }
            } else if (c == 'y') {
                istringstream iss(optarg);
                iss >> resize_nn_threshold_y;
                if (iss.fail() || resize_nn_threshold_y < 0.0 || resize_nn_threshold_y > 0.5) {
                    cerr << argv[0] << ": resize_nn_threshold_y=" << optarg << " is invalid setting. must be between 0.0 and 0.5" << endl;
                    return 1;
                }
            } else if (c == 't') {
                istringstream iss(optarg);
                iss >> time_level;
                if (iss.fail()) {
                    cerr << argv[0] << ": time_level=" << optarg << " is invalid setting" << endl;
                    return 1;
                }
            } else if (c == 'p') {
                string s = string(optarg);
                if (s == "normal" || s == "NORMAL" || s == "T_MODE_NORMAL") {
                    dpu_task_mode = T_MODE_NORMAL;
                }
                else if (s == "profile" || s == "PROFILE" || s == "T_MODE_PROFILE") {
                    dpu_task_mode = T_MODE_PROFILE;
                }
                else if (s == "debug" || s == "DEBUG" || s == "T_MODE_DEBUG") {
                    dpu_task_mode = T_MODE_DEBUG;
                }
                else {
                    cerr << argv[0] << ": Invalid dpu_task_mode '" << s << "'" << endl;
                    return 1;
                }
            } else if (c == 'w') {
                output_wave = true;
            } else if (c == 's') {
                output_model_select_result = true;
            } else if (c == 'l') {
                output_label_size = true;
            } else if (c == 'd') {
                dump_dpu_input_output = true;
            } else if (c == 'h') {
                usage(argv[0]);
                return 1;
            } else {
                // '?'
                if (opt_with_argument.find(optopt) != string::npos) {
                    // no option argument
                } else {
                    assert(opt_without_argument.find(optopt) == string::npos);
                    // unknown option character
                }
                return 1; // error
            }
        }

        // non-option or end of argument list
        if (optind < argc) {
            do {
                cerr << argv[0] << ": non-option argument '" << argv[optind] << "'" << endl;
                optind++;
            } while (optind < argc);
            return 1; // error
        }

        return 0;
    }

    void print(ostream &os) {
        os << "input_dir = " << input_dir << endl;
        if (output_format == OutputFormatPNG) {
            os << "output_dir = " << output_dir << endl;
            os << "output_format = png" << endl;
        }
        else {
            os << "output_file = " << output_file << endl;
            os << "output_format = json" << endl;
        }
        os << "num_threads = " << num_threads << endl;
        os << "num_image_buffers = " << num_image_buffers << endl;
        os << "resize_nn_threshold_x = " << resize_nn_threshold_x << endl;
        os << "resize_nn_threshold_y = " << resize_nn_threshold_y << endl;
        os << "model_select = " << model_select << endl;
        os << "time_level = " << time_level << endl;
        switch (dpu_task_mode) {
          case T_MODE_NORMAL: os << "dpu_task_mode = normal" << endl; break;
          case T_MODE_PROFILE: os << "dpu_task_mode = debug" << endl; break;
          case T_MODE_DEBUG: os << "dpu_task_mode = profile" << endl; break;
          default: assert(false);
        }
        os << "output_wave = " << (output_wave ? "enabled" : "disabled") << endl;
        os << "output_model_select_result = " << (output_model_select_result ? "enabled" : "disabled") << endl;
        os << "output_label_size = " << (output_label_size ? "enabled" : "disabled") << endl;
        os << "dump_dpu_input_output = " << (dump_dpu_input_output ? "enabled" : "disabled") << endl;
    }

    int setModelSelectMode(void) {
        select_model1_rate = 0;
        model_select_file = "";

        const string &s = model_select;
        if (s == "model0") {
            model_select_mode = UNet::ModelSelectNormal;
        }
        else if (s == "model1") {
            model_select_mode = UNet::ModelSelectCutTopQuarter;
        }
        else {
            if (s.find(":") == string::npos) {
                cerr << "Error: Invalid model select string '" << s << "'" << endl;
                return 1;
            }
            std::string mode = s.substr(0, s.find(":"));
            std::string option = s.substr(s.find(":")+1);
            if (mode == "adaptive" || mode == "random") {
                istringstream iss(option);
                iss >> select_model1_rate;
                if (select_model1_rate < 0.0 || select_model1_rate > 1.0) {
                    cerr << "Error: Invalid model select string '" << s << "'. select_model1_rate(=" << select_model1_rate << ") must be between 0.0 and 1.0" << endl;
                    return 1;
                }
                if (mode == "adaptive") {
                    model_select_mode = UNet::ModelSelectAdaptive;
                }
                else {
                    assert(mode == "random");
                    model_select_mode = UNet::ModelSelectOracle;
                }
            }
            else if (mode == "oracle") {
                model_select_mode = UNet::ModelSelectOracle;
                model_select_file = option;
                if (model_select_file.empty()) {
                    cerr << "Error: Invalid model select string '" << s << "'. model_select_file is not specified." << endl;
                    return 1;
                }
            }
            else {
                if (s.find(":") == string::npos) {
                    cerr << "Error: Invalid model select string '" << s << "'" << endl;
                    return 1;
                }
            }
        }
        return 0;
    }
};

/**
 * @brief Entry for runing Segmentation neural network
 *
 * @arg file_name[string] - path to file for detection
 *
 */
int main(int argc, char **argv) {
    MeasureTimeThreadData::set_name("main");

    // parse command line option
    CommandLineOptions options;
    int parse_error = options.parse(argc, argv);
    if (parse_error) return parse_error;

    // set global variable (TODO: change to local variable)
    ::INPUT_RESIZE_NEAREST_NEIGHBOR_THRESHOLD_X = options.resize_nn_threshold_x;
    ::INPUT_RESIZE_NEAREST_NEIGHBOR_THRESHOLD_Y = options.resize_nn_threshold_y;
    ::DPU_TASK_MODE = options.dpu_task_mode;

    // configure time measurement
    TIME_LEVEL = options.time_level;
    if (TIME_LEVEL < 0) MeasureTime::disable_measure_time_output();
    if (TIME_LEVEL < 1) MeasureTime::disable_measure_time_flat_output();
    OUTPUT_EXTRA_VCD_TRACE = (TIME_LEVEL >= 1);
    if (!options.output_wave) {
        MeasureTime::disable_vcd_output();
        OUTPUT_EXTRA_VCD_TRACE = false;
    }

    const int num_threads = options.num_threads;
    const int num_image_buffers = options.num_image_buffers;
#ifdef USE_THREAD_BARRIER
    const int batch_size = (num_image_buffers+options.num_threads-1)/num_threads;
#else
    const int batch_size = 1;
#endif
    bool output_png = (options.output_format == CommandLineOptions::OutputFormatPNG);
    bool output_json = (options.output_format == CommandLineOptions::OutputFormatJSON);

    // Attach to DPU driver and prepare for runing
    dpuOpen();

    // get number of cores
    int num_cores = std::thread::hardware_concurrency();

    // start dpu thread, unet threads and initialize
    UNetRunner *runner = nullptr;
    _T0(InitializeUnet, (runner = new UNetRunner(num_threads, num_image_buffers, "dpu", num_cores-1, "unet", options.model_select_mode, options.select_model1_rate, batch_size)));

    // print options
    cout << "number of cores = " << num_cores << endl;
    options.print(cout);

    JSONWriter jw;
    if (output_json) {
        jw.open(options.output_file);
    }

    FILE *fp_model_select = nullptr;
    if (options.output_model_select_result) {
        fp_model_select = fopen(options.output_model_select_file.c_str(), "w");
        if (!fp_model_select) {
            std::cerr << "Error: cannot open " << options.output_model_select_file << std::endl;
            std::exit(1);
        }
    }

    FILE *fp_label_size = nullptr;
    if (options.output_label_size) {
        fp_label_size = fopen(options.output_label_size_file.c_str(), "w");
        if (!fp_label_size) {
            std::cerr << "Error: cannot open " << options.output_label_size_file << std::endl;
            std::exit(1);
        }
    }

    uint64_t total_inference_time_in_us = 0;
    vector<string> input_images;
    vector<string> output_images;
    _T0(GetImageList, GetImageList(options.input_dir, input_images, output_images));
    for (size_t img_idx = 0; img_idx < input_images.size(); img_idx += num_image_buffers) {
        size_t end_img_idx = std::min(img_idx+num_image_buffers, input_images.size());
        size_t num_process_imgs = end_img_idx - img_idx;
        size_t num_process_imgs_per_thread = (num_process_imgs+num_threads-1)/num_threads;

        cout << "---- Processing images[" << img_idx << ":" << end_img_idx << "]" << endl;

#ifdef PC_VER
        dpuRunTask_img_idx_base = img_idx;
#endif

        // Load input images
        _T0(Read, Read(options.input_dir, vector<string>(input_images.begin()+img_idx, input_images.begin()+end_img_idx), runner->input_queue(), runner->frameData()));

        // Read model select oracle file
        if (options.model_select_mode == UNet::ModelSelectOracle) {
            if (options.model_select_file.empty()) {
                _T0(ModelSelectRandom, SetModelSelectRandom(options.select_model1_rate, num_process_imgs, runner->modelSelectResult()));
            }
            else {
                _T0(ModelSelectOracle, ReadModelSelectOracle(vector<string>(input_images.begin()+img_idx, input_images.begin()+end_img_idx), options.model_select_file, runner->modelSelectResult()));
            }
        }

        // check not processed
        for (int tid = 0; tid < num_threads; tid++) {
            assert(runner->input_queue()[tid].size() == num_process_imgs_per_thread);
            assert(runner->output_queue()[tid].size() == 0);
        }

        // run segmentation
        _T0(Run, runner->run(num_process_imgs));
        total_inference_time_in_us += runner->get_last_duration_time_in_us();

        // check all processed
        for (int tid = 0; tid < num_threads; tid++) {
            assert(runner->input_queue()[tid].size() == 0);
            assert(runner->output_queue()[tid].size() == num_process_imgs_per_thread);
        }

        if (output_json) {
            // Write output as JSON
            _T0(WriteJSON, WriteJSON(vector<string>(input_images.begin()+img_idx, input_images.begin()+end_img_idx), jw, runner->output_queue(), runner->frameData()));
        }
        if (output_png) {
            // Write output images
            _T0(Write, Write(options.output_dir, vector<string>(output_images.begin()+img_idx, output_images.begin()+end_img_idx), runner->output_queue(), runner->frameData()));
        }

        // Write model select result
        if (options.output_model_select_result) {
            for (size_t i = 0; i < num_process_imgs; i++) {
                fprintf(fp_model_select, "%s %u\n", input_images[img_idx+i].c_str(), runner->modelSelectResult()[i]);
            }
        }

        // Write label size
        if (options.output_label_size) {
            for (size_t i = 0; i < num_process_imgs; i++) {
                fprintf(fp_label_size, "%s %u\n", input_images[img_idx+i].c_str(), (unsigned int)runner->labelSize()[i]);
            }
        }

        if (options.dump_dpu_input_output) {
            // Dump DPU Input/Output
            _T0(DumpDPU, DumpDPU(DUMP_DIR, img_idx, num_process_imgs, runner->frameData(), runner->modelSelectResult()));
        }
    }
    cout << "evaluation completed!" << std::endl;

    // print stat
    const auto &stat = runner->get_stat();
    for (int i = 0; i < NUM_NN_MODELS; i++) {
        printf("model%d inference count = %d/%d (%.2f %%)\n", i, stat.model_select_count[i], stat.num_processed, 100.0*stat.model_select_count[i]/stat.num_processed);
    }

    // Destroy runner
    delete runner;

    // Detach from DPU driver and release resources
    dpuClose();

    // print output file info
    if (output_json) {
        cout << "inference result is writed to '" << options.output_file << "' file" << endl;
        jw.close();
    }
    if (output_png) {
        cout << "inference results are stored in '" << options.output_dir << "' directory" << endl;
    }
    if (options.output_model_select_result) {
        cout << "model selection result is writed to '" << options.output_model_select_file << "' file" << endl;
        fclose(fp_model_select);
    }
    if (options.output_label_size) {
        cout << "label size is writed to '" << options.output_label_size_file << "' file" << endl;
        fclose(fp_label_size);
    }

    // print process time
    double total_time_in_sec = (double)total_inference_time_in_us / 1000000.0;
    double time_per_img_ms = (double)total_inference_time_in_us / input_images.size() / 1000.0;
    double frame_per_second = 1000.0 / time_per_img_ms;
    printf("Total inference time            : %.3f sec\n", total_time_in_sec);
    printf("Average inference time per image: %.3f msec (%.2f fps)\n", time_per_img_ms, frame_per_second);

    return 0;
}
