# 1. What
	This zynqmp_dpu_optimize.sh would execute following functions on target board:

	1. fine-tune QoS/Outstanding settings for DPU case to achieve a better performance

# 2. How

1. How to use these scripts?   

	run ./zynqmp-dpu-optimize.sh   

	->./zynqmp_dpu_optimize.sh   
	Start QoS optimize ...[✔]   
	Congratulations, done!   

2. Init script

	As QoS and irps5401 settings would be recovered when board power off, so user
	could add this script as init-script to run:

	Eg:

```shell
	cd <dpu_sw_optimize\zynqmp>
 	echo $(readlink -f zynqmp_dpu_optimize.sh) > /etc/init.d/dpu-config.sh
	chmod +x /etc/init.d/dpu-optimize.sh
	(cd /etc/rc5.d; ln -s ../init.d/dpu-optimize.sh S99dpu-config)
```
