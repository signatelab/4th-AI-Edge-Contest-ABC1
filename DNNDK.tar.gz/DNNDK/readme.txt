■SDカードの準備
以下のリンクからプリビルド済みのSDカードイメージをダウンロードして、SDカードに書き込む
 http://avnet.me/avnet-ultra96v2-vitis-ai-1.1-image (MD5SUM = 7f54ceed152a0c704f5da18c4738b3fc)

 参考: https://www.hackster.io/AlbertaBeef/vitis-ai-1-1-flow-for-avnet-vitis-platforms-part-2-f18be4

以下のリンクからDNNDK v1.1をダウンロード、SDカードのBOOTパーティション直下にコピー
 https://www.xilinx.com/bin/public/openDownload?filename=vitis-ai_v1.1_dnndk.tar.gz

 参考: https://github.com/Xilinx/Vitis-AI/tree/v1.1/mpsoc

アプリケーション実行用ファイルの準備
事前にsegmentation/modelディレクトリにはDPUモデルを格納しておく（生成方法は学習用環境参照)
segmentationディレクトリに入り、libjpegのダウンロードおよび入力画像(test画像649枚)のコピーを行う
その後、DNNDKディレクトリをDNNDK.tar.gzとして固める
 $ cd segmentation
 $ ./download_libjpeg.sh
 $ cp -rfv <データ格納ディレクトリ>/seg_test_images inputs
 $ cd ../..
 $ tar zcvf DNNDK.tar.gz DNNDK

DNNDK.tar.gzは、SDカードのBOOTパーティション直下にコピー

■ultra96ボードでの作業(初回)
作成したSDカードでultra96をブートし、DNNDK v1.1のインストールを行う
 $ cd /mnt
 $ tar -xzvf vitis-ai_v1.1_dnndk.tar.gz
 $ cd vitis-ai_v1.1_dnndk
 $ ./install.sh
※ tarで解凍時のタイムスタンプのエラー(xxx in the future)は無視してOK

DNNDK.tar.gzを/home/rootに解凍しDNNDKに入る
 $ cd /home/root
 $ tar -xzvf /mnt/DNNDK.tar.gz
 $ cd DNNDK

解凍時にタイムスタンプのエラー(xxx in the future)が出る場合は以下でタイムスタンプを更新しておく
(これをやっておかないとlibjpeg, libjpeg-turboのコンパイルでエラーする)
 $ touch `find .`

DDRのQoS改善のスクリプトを実行
 $ dpu_sw_optimize/zynqmp/zynqmp_dpu_optimize.sh

segmentationディレクトリに入る
 $ cd segmentation

libjpeg, libjpeg-turboのコンパイル
 $ ./compile_libjpeg.sh

アプリケーションのビルド
 $ ./build_release.sh

アプリケーションの実行(inputsディレクトリ内のtest画像649枚の推論)
 $ ./segmentation

実行後、seg_out.jsonに推論結果が出力される。正常に推論できていればmd5sumの値は以下と同じになるはず。
 $ md5sum seg_out.json
 cda5709b1d56a7384fc759d014abd5b3  seg_out.json

推論処理時間および画像1枚あたりの平均推論処理時間はアプリケーション実行の最後に以下のように表示される
 Total inference time            : 6.347 sec
 Average inference time per image: 9.779 msec (102.26 fps)

その他の処理時間の確認は measure_time_hier.csv の total_time(us) の列で行う。
以下、各項目についての説明を記載する(括弧の中には実際の計測値を記載. だいたいコレくらいの値になっているはず)

 main                 全体の実行時間 (20.91 sec)
 main.GetImageList    画像ファイルリストの取得 (0.002 sec)
 main.InitializeUnet  初期化処理 (0.2 sec)
 main.Read            画像ファイル読み込み (13.03 sec)
 main.Run             推論処理 (6.35 sec)
 main.WriteJSON       推論結果のJSON形式化＆ファイルへの書き込み (0.68 sec)

シャットダウン
 $ shutdown -h now

■ultra96ボードでの作業(初回以降)
初回以降はDDRのQoS改善スクリプトの実行を行ってから、アプリケーションを実行すればOK
※ QoS改善スクリプトは毎回実行する必要あり

 $ cd DNNDK
 $ dpu_sw_optimize/zynqmp/zynqmp_dpu_optimize.sh
 $ cd segmentation
 $ ./segmentation

■入力画像ファイルを変更したい場合
入力画像ファイルを変更したい場合はinputsディレクトリの内容を変更する。
ただし、サポートしている画像ファイルは今回のコンテストで使用されている形式のみ。
※ 具体的には幅:1936px、高さ:1216px、RGB、jpegファイル

■ifdefについて
基本的に src/config.hpp で制御するようにしている。ただし、一部はmake時のオプションで指定(USE_LIBJPEG*関連、後述)。
以下 src/config.hpp 記載分についての説明

・画像ロード
JPEG_SCALE_NUM: jpeg decode時のscale_numの設定(※1)
JPEG_SCALE_DENOM: jpeg decode時のscale_denomの設定(※1)
JPEG_IMAGE_BUFFER_SIZE: jpeg画像格納用のバッファサイズ[byte](USE_ROW_DECODE_JPEG有効時のみ使用)
※1 元のサイズに「scale_num/scale_denom」をかけたサイズにデコードされる.
    例えばscale_num=1, scale_denom=2なら元のサイズの1/2の画像にデコードされる(元のサイズが1936x1216 なら 968x608にデコード)
    (DCT係数の高周波成分を使わないことで効率よくデコードしているらしいので処理速度は速い)
    Jpegデコードの際に小さな画像にデコードすることでjpegデコード時間もDPU入力用のリサイズ処理も速度が速くなる。（ただし、認識精度は多少低下）

・前処理関連
USE_INPUT_RESIZE_BILINEAR: 入力のリサイズにbilinearを使う。指定しない場合はnearest neighborが使用される
USE_OPT_RESIZE_INPUT: 入力のリサイズに自前で最適化した処理(ResizeBilinear.hpp/ResizeNearest.hpp)を使う。指定しない場合はOpenCVのリサイズ処理を使用
USE_BILINER_MERGED_TRANSPOSE: 入力のリサイズと転置処理をマージ（同一ループ内で処理）する。USE_OPT_RESIZE_INPUTの指定が必要
USE_INPUT_BILINEAR_RSHIFT: 入力のリサイズ時と同時にQ値合わせも行う（同一ループ内で処理)。USE_OPT_RESIZE_INPUTの指定が必要
USE_INPUT_RESIZE_BILINEAR_TF: 入力のリサイズにtensorflowのresize_bilinear(align_corner=False, half_pixel_center=True)と同じ処理(ResizeBilinearTF.hpp)を使用
USE_ROW_DECODE_JPEG: 入力のリサイズ時にJPEGデコードを行う（Bilinearリサイズに必要な行だけデコードするので画像読み込みも含めた全体の処理時間が短くなる)。

・後処理関連
USE_OUTPUT_RESIZE_BILINEAR: 出力のリサイズにbilinearを使う。指定しない場合はnearest neighborが使用される
USE_OPT_RESIZE_OUTPUT_ADD: output_add1, output_add2のリサイズに自前で最適化した処理(ResizeBilinear.hpp/ResizeNearest.hpp)を使う。
USE_OPT_RESIZE_OUTPUT: output_addのリサイズに自前で最適化した処理(ResizeBilinear.hpp/ResizeNearest.hpp)を使う。
USE_BILINER_MERGED_ARGMAX: 出力のリサイズ(Bilinear)とargmax処理をマージ(UpsampleArgmax.hpp)して実行
USE_LOGITS_RSHIFT_FOR_U8: 後処理関連を全て8bitで実行。無効の場合は3つの出力の加算までは16bit精度で行われる。その後のbit精度はNARROW_LOGITS_TO_U8の設定次第。
NARROW_LOGITS_TO_U8: USE_LOGITS_RSHIFT_FOR_U8が無効の場合に、3つの出力の加算後はブロックフローティング処理で8bit化して、その後は8bit精度で行う。無効の場合は16bit精度で行う（後処理全体が16bit精度処理となる)
USE_ROW_ALL_SAME_CLASS: UpsampleArgmax処理前に各行が全て同じクラスであるかをチェックし、その結果を使ってUpsampleArgmax処理では処理スキップを行う。(全て同じクラスの行がない場合はスキップできないので逆に処理速度は増加してしまう)
UPSAMPLE_ARGMAX_USE_FAST_CALC: UpsampleArgmax処理での近似処理を有効にする(詳細はUpsampleArgmax.hpp参照)
USE_ARGMAX_RUN_LENGTH_OUTPUT: UpsampleArgmax処理結果をランレングス符号化する。結果が圧縮されるのでメモリアクセスが減って処理速度向上が期待できる。推論結果のjsonファイル作成処理も簡単になるのでそちらも処理速度が向上する。UPSAMPLE_ARGMAX_COPY_LEFT_CLASS 5: 推論結果で未定義クラス(=5)が現れた時に単純に未定義クラスとするのではなく、左の位置のクラスをコピーする(未定義クラスが左端の場合は右の位置のクラスをコピー、1行分すべて未定義クラスなら未定義クラスのまま)。
UPSAMPLE_ARGMAX_IGNORE_CLASS 5: Argmax処理で未定義クラス(=5)を除いてArgmax処理を行う
UPSAMPLE_ARGMAX_LSHIFT (16-(8+2)): UpsampleArgmaxの途中処理結果を指定した値分左シフトして精度を上げる(詳細はUpsampleArgmax.hpp)。上位ビットに余裕がある(左シフトしてもオーバーフローしない)16bit精度で処理する場合に使用することを想定

・DPU関連
USE_DPU_SPLIT_IO: split_ioモードを使用
DPU_MODEL0_TRANSPOSE: model0では転置して処理
DPU_MODEL1_TRANSPOSE: model1では転置して処理
USE_DPU_GET_INPUT_PRIORITY: DPUへ投入する画像の順序に影響。無効の場合は各スレッドからの画像をラウンドロビンで処理。有効の場合は毎回どのスレッドからの画像を処理するかを優先度づけして選択する。優先度は残りの処理画像枚数としている。ラウンドロビンで処理する場合、あるスレッドが遅れてしまうとDPU処理が待ち状態になってしまう。これを有効にすることで遅れたスレッドの画像は後回しにして先に準備ができた違うスレッドからの画像を処理することができる。遅れたスレッドに関しては残りの処理画像枚数が多くなるため優先度が高くなり、後に処理が間に合ってきた時に遅れ分を取り返すことができる。
USE_THREAD_BARRIER: CPUとDPU処理が同時に実行されないようにする。CPU処理がない場合のDPU処理時間測定用(CPU処理が同時に走っているとDDRアクセスで競合するためDPU処理は遅くなる、この影響がない場合のDPU処理時間の測定)
BLOCKING_DPU_SEGMENTATION: 有効の場合は各スレッドはDPU実行時にブロッキングする。結果的に各画像をin-order(前の画像の処理がすべて完了しないと次の画像を処理しない)で処理する動作となる。DPU入力/出力バッファは複数持つ必要はなくなるので1つになる
PRINT_DPU_TASK_PARAMETER: 実行時にDPUTaskのパラメータを表示

・JSONファイル出力関連
WRITE_JSON_USE_STRING_BUF: 出力jsonファイルにfprintf等で直接書き込むのではなく、一旦sprintf等でjsonファイルの内容を文字列バッファに書き込んだ後にfwriteで一気に出力する

■make時のオプションについて
RELEASE=1: デバッグ関連の機能をOFF(assertを無効にする(-DNDEBUG)、時間測定はデフォルト最小限にする(-DTIME_LEVEL=0))
USE_LIB_JPEG_TURBO=1: 画像の読み込みにlibjpeg-turboを使用する。指定しない場合はOpenCVのimreadを使用。imreadよりもlibjpeg-turboの方が高速。読込結果は完全一致する
USE_LIB_JPEG=1: 画像の読み込みにlibjpegを使用する。指定しない場合はOpenCVのimreadを使用。読み込み結果が微妙にlibjpeg-turbo/imreadと違う。学習時やVitis-AI環境での画像読み込みはこちらと完全一致する。デバッグ用途での使用を想定(vai_q_tensorflowでの量子化モデル実行結果と完全一致を見る場合など）

例1: 最速で処理できるようにデバッグ機能はOFF、libjpeg-turboを使用する場合(build_release.shの内容と同じ)
 $ make USE_LIB_JPEG_TURBO=1 RELEASE=1
例2: 動作確認のためassertや時間測定をONにする場合(build.shの内容と同じ)
 $ make USE_LIB_JPEG_TURBO=1
例3: 入力画像ファイルがpngの場合(OpenCVのimreadを使用する場合)かつデバッグ機能OFF
 $ make RELEASE=1
例4: vai_q_tensorflowでの量子化モデル実行結果と完全位置を見る場合
 $ make USE_LIB_JPEG=1
 ※ 入力のリサイズ方式も合わせないと完全一致しないので src/config.hpp の USE_INPUT_RESIZE_BILINEAR_TF を有効にする必要あり

■コマンドラインオプションについて
以下の用に-hオプションをつけて実行するとヘルプが表示されてオプションの確認が可能
 $ ./segmentation -h

例1: 入力ディレクトリをsample_input、出力jsonファイルをseg_result.jsonにして出力
 $ ./segmentation -i sample_input -o seg_result.json
例2: 入力ディレクトリをsample_input、出力をpng画像にしてsample_outputディレクトリへ出力
 $ ./segmentation -i sample_input -f png -o sample_output
例3: model0のみで推論
 $ ./segmentation -m model0
例4: 3スレッドで実行
 $ ./segmentation -n 3
例5: 時間測定の詳細レベルを最高の2かつ時間測定の波形出力(measure_time.vcd)を有効にして実行
 $ ./segmentation -t 2 -w
例6: 時間測定を無効(time_level=-1)にして実行
 $ ./segmentation -t -1
例7: DPUの入出力のダンプを有効にして実行（結果はdumpsディレクトリ配下に格納される)
 $ ./segmentation -d

■PCでの実行について
アプリケーションはPCでも実行できるようにしている。DPU以外の処理をPC上でデバッグしたい場合に使うことを想定。
事前にONNXモデルをsegmentation/modelディレクトリに格納しておく（生成方法は学習用環境参照)
ビルドは実機でのビルドと同様にまずはcompile_libjpeg.shでlibjpeg関連をビルドする。
さらにPC用ではONNX runtimeを使うのでdownload_onnxruntime.shで取得する。
その後にmakeを実行すればOK。
PCでmakeを実行するとPC_VERのマクロが有効になり、PC用のソースがコンパイルされる。
実行する際はONNX runtime libraryを使うので、LD_LIBRARY_PATH に onnxruntime-linux-x64-1.6.0/lib を追加する必要あり
PC実行時のDPU処理は以下の動作となる ※ DPUの入出力のダンプは実機実行時に-dオプションで取得可能
 dumpsディレクトリにDPUの入力のダンプがある場合はその値と入力を比較する（比較結果の要素あたりの平均/最大誤差が最後に出力される)
 dumpsディレクトリにDPUの出力のダンプがある場合はその値を出力する。ない場合はONNXモデルを使用した推論が実行される
DPU入力の比較結果は以下のように出力される。
 [DNNDK_DUMMY] unet_split_io            : model_miss_match = 3, avg_input_diff = 0.601161, max_input_diff = 30
 [DNNDK_DUMMY] unet_cutq_tr_split_io    : model_miss_match = 10, avg_input_diff = 0.619112, max_input_diff = 40
※ unet_split_io/unet_cutq_tr_split_ioはそれぞれmodel0/model1のこと。
※ model_miss_match はモデルの選択が違っている個数。違っている場合は入力の比較は行われない
